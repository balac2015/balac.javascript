<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>微信安全支付</title>
</head>
<body>
	</br></br>
	<div >
		<ul>
			<h1><a href="./demo/micropay_call.php" >1.被扫支付demo(手动输入刷卡界面的一维码)</a></h1>
			<h1><a href="./demo/order_query.php" >2.支付查询接口demo</a></h1>
			<h1><a href="./demo/download_bill.php" >3.对账单接口demo</a></h1>
			<h1><a href="./demo/refund.php" >4.退款接口demo</a></h1>
			<h1><a href="./demo/refund_query.php" >5.退款查询接口demo</a></h1>
			<h1><a href="./demo/reverse.php" >6.冲正接口demo</a></h1>
		</ul>
	</div>
</body>
</html>
