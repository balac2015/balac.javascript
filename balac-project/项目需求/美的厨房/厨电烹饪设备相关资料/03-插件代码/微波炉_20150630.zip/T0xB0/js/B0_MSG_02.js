(function (mdSmart) {
    // var bDebug = true;
    var bDebug = false;
    mdSmart.B0_P02 = mdSmart.B0_P02 || {};
	mdSmart.B0_COM = mdSmart.B0_COM || {};
    $(document).on('pageinit', 'div[id="B0_P02"]', function (event) {
        console.log('#B0_P02 pageinit.');
		mdSmart.B0_P02.message = mdSmart.B0_COM.message = mdSmart.B0_COM.message == undefined?(new mdSmart.msg0xB0()):mdSmart.B0_COM.message;
		
        $(document).bind('recieveMessage', {}, function (event, message) {
            mdSmart.B0_P02.showStatus("", message);
        });
    });

    $(document).on('pageshow', 'div[id="B0_P02"]', function (event) {
        console.log('#B0_P02 pageshow.');
		//国际化
		mdSmart.B0_P02.pageTextInit();
        mdSmart.B0_P02.prepareAndShow();
		//TODO
        $("#B0_P02_ChildLock").bind('tap', {}, mdSmart.B0_P02.eventChildLock);
		if (bDebug == true) {
			$("#B0_P02_Pause").bind('tap', {}, mdSmart.B0_P02.setFunctionWorkStateWork);
		}
    });

    $(document).on('pagehide', 'div[id="B0_P02"]', function (event) {
        console.log('#B0_P02 pagehide.');
        //TODO
		//$("#B0_P02_ChildLock").unbind('tap');
		
		$("#B0_P02_ChildLock").removeClass("ricecooker_05_waiting");
		mdSmart.common.isCartBtnLockControl(false);
    });
    mdSmart.B0_P02.pageTextInit=function(){
	    console.log("mdSmart.B0_P02.prepareAndShow");
		$("#B0_P02_TEXT_STANDBY").html(mdSmart.i18n.WAITING);//省电
		$("#B0_P02_Pause").html(mdSmart.i18n.PAUSE_FUNCTION);//暂停
		$("#B0_P02_Cancel").html(mdSmart.i18n.CANCEL_FUNCTION);//取消
		$("#B0_P02_ChildLock").html(mdSmart.i18n.CHILDLOCK_FUNCTION);//童锁
	};
    mdSmart.B0_P02.prepareAndShow = function () {
        console.log("mdSmart.B0_P02.prepareAndShow");
		mdSmart.B0_P02.cmdRequestStatus();
        bridge.getCardTitle(function (message) {
            $("#B0_P02_TITLE").html(message);
        });
        // For Debug
        if (bDebug == true) {
            var title = JSON.stringify({
                messageBody: mdSmart.i18n.APP_NAME
            });
            bridge.setCardTitle(title);
        }
    };
    // 查询按钮
    mdSmart.B0_P02.cmdRequestStatus = function () {
        console.log("function:mdSmart.B0_P02.cmdRequestStatus");
		var cmdBytes = mdSmart.B0_P02.message.cmdRequestStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P02.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P02.afterControlProcess(cmdId, cmdBytes);
    };
	//童锁
    mdSmart.B0_P02.eventChildLock=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
        if(mdSmart.B0_P02.workState!=null)
		{
			if(mdSmart.B0_P02.workState == 0x05){
				//解锁
				mdSmart.B0_P02.message.setFunctionWorkStateStandby();
			}else{
				//解锁
				mdSmart.B0_P02.message.setFunctionWorkStateLock();
			}
			if(mdSmart.common.isCartBtnLock() == true){return false;}
			$("#B0_P02_ChildLock").addClass("ricecooker_05_waiting");
			var cmdBytes = mdSmart.B0_P02.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
				$("#B0_P02_ChildLock").removeClass("ricecooker_05_waiting");
				mdSmart.common.isCartBtnLockControl(false);
				mdSmart.B0_P02.showStatus(cmdBytes, messageBack);
			},function(errCode){
				if(errCode == -1){
					$("#B0_P02_ChildLock").removeClass("ricecooker_05_waiting");
					mdSmart.common.isCartBtnLockControl(false);
				} 
			});
			mdSmart.B0_P02.afterControlProcess(cmdId, cmdBytes);
		}
	};
	// 工作状态--工作
    mdSmart.B0_P02.setFunctionWorkStateWork = function () {
        console.log("function:mdSmart.B0_P02.setFunctionWorkStateWork");
        mdSmart.B0_P02.message.setFunctionWorkStateWork();
        var cmdBytes = mdSmart.B0_P02.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P02.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P02.afterControlProcess(cmdId, cmdBytes);
    };
    mdSmart.B0_P02.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P02.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P02.message.getResponseBack();
            var messageType = cmdMessageType;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = statusMessage[9];
            }
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_P02.showStatus = function (messageBackRequest, messageBackBack) {
	    var jsonStatus = mdSmart.B0_P02.message.parseMessageForView(messageBackBack);
		mdSmart.B0_P02.workState = jsonStatus.status.workState.value;
		if(mdSmart.B0_P02.workState == 0x02
		|| mdSmart.B0_P02.workState == 0x03
		|| mdSmart.B0_P02.workState == 0x04){
			if($.mobile.activePage[0].id == "B0_P02"){
				$.mobile.changePage("#B0_P01");
			}	
		}
		if(mdSmart.B0_P02.workState == 0x05){
			$("#B0_P02_ChildLock_Img").css("height","16px");
			$("#B0_P02_ChildLock").html(mdSmart.i18n.CHILDUNLOCK_FUNCTION);
		}else{
			$("#B0_P02_ChildLock_Img").css("height","0px");
			$("#B0_P02_ChildLock").html(mdSmart.i18n.CHILDLOCK_FUNCTION);
		}
    }
})(mdSmart);
