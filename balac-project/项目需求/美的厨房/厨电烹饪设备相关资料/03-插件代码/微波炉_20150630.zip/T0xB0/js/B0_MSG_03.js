var B0_P03_Menu_SelectName;
var startIndex;
var endIndex;
var deviceId = bridge.getCurrentApplianceID();
window.sessionStorage.removeItem("workMenuId");
$(function (){
	//获取动态码
	var token = window.localStorage.getItem("token");
	startIndex = 1;
	endIndex= 6;
	if(token == "null" || token == null){
		getPwd();
	} else {
		var recipe = window.localStorage.getItem("recipe");
		//alert(recipe);
		if(recipe == "null" || recipe== null){
			getPlatform(JSON.parse(token));
		} else {
			var currRecipe = window.localStorage.getItem(deviceId+"_currRecipe");
			var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				if(currRecipe != null && currRecipe != "null"){
					insertEl(currRecipe);
					mdSmart.B0_P03.cmdRequestStatus()
				}
			}
            insertEl(recipe);
        }
	}


});

//1.获取动态码代码
function getPwd() {
	var _jsonData = {
	"uid" : "10486", //uid先写着“10486”
	"fun" : "getPwd"
	};
	var str=encrypt4Pwd(JSON.stringify(_jsonData));
	$.ajax({
		type : "post",
		url : "http://iot3.midea.com.cn:8787/nutrition/v11/base2pro/data/transmit?data="+str,
		dataType : 'json',
		async : true,
		success : function(res){
			var obj = eval(res);
			var token = decrypt4Pwd(obj.data);
			var recipe = window.localStorage.getItem("recipe");
			if(recipe == "null" || recipe== null){
                    //二次请求
                    getPlatform(JSON.parse(token));
			} else{
                insertEl(recipe);
            }

            window.localStorage.setItem("token",token);
			
		}
	});
}

function getPlatform(token) {
    var data = token;
    var sessionPlatform = window.localStorage.getItem(deviceId+"_B2_Sn");
    var str = {
        "fun": "snQuery",
        "applianceId": deviceId,
        "pwd": data.pwd + "",
        "uid": "10486"
    };
    //if(sessionPlatform==null || sessionPlatform=="null" || sessionPlatform=="undefined"){
        $.ajax({
            type: "post",
            url: "http://" + data.server + ":" + data.port + data.preUrl + "sn",
            dataType: 'json',
            async: true,
            headers: {
                "sessionID": data.sessionID + ""
            },
            data: {"nopwd": "true", "debug": true, "data": JSON.stringify(str)},
            success: function (sn) {
                //alert(JSON.stringify(sn));
                var Sn = sn.platform;
                if(Sn !=null || Sn !=undefined){
                    window.localStorage.setItem(deviceId+"_B2_Sn",JSON.stringify(Sn));
                    getRecipe(data,Sn);
                }else{
                    window.localStorage.setItem(deviceId+"_B2_Sn","0000");
                    getRecipe(data,"");
                }
            },
            error:function(er){
                //alert(er);
            }
        });

    //}else{
    //    getRecipe(data,sessionPlatform);
    //}

}

function getRecipe(data,platform){
	var str1 = {
		"fun" : "3conditionList",  
		"food": "", //食材类别id
		"area": "",   //区域类别id
		"commontype": "", //常见分类id  //如家常菜、海鲜、热菜、凉菜、素菜、蒸菜、药膳、卤菜、甜品、点心。
		"devType": "1",   //烹饪设备种类id
		"page": startIndex +"," + endIndex,  //分页 要求返回第1到20条数据
		"pwd" : data.pwd+"",
		"platform":platform,
		"uid" : "10486"
	};
	$.ajax({
		type : "post",
		url : "http://"+data.server+":"+data.port+data.preUrl+"recipe",
		dataType : 'json',					
		async : true,
		headers:{
			"sessionID": data.sessionID+""
		},
		data:{"nopwd":"true","debug":true,"data":JSON.stringify(str1)},
		success : function(res){	
			//alert(JSON.stringify(res));
			if(startIndex == 1){
				$(".listWrap").remove();
				window.localStorage.setItem("recipe", JSON.stringify(res));
				var currRecipe = window.localStorage.getItem(deviceId+"_currRecipe");
				var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
				if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
					if(currRecipe != null && currRecipe != "null"){
						insertEl(currRecipe);
						mdSmart.B0_P03.cmdRequestStatus();
					}
				}
			}
			insertEl(JSON.stringify(res));
			//myScroll.refresh();
		} ,
		error:function(datr){
			//alert(JSON.stringify(datr));
		}
	});
}

//2，加密方法
function encrypt4Pwd(str){
	var keyHex = CryptoJS.enc.Utf8.parse("guoqnlyq");
	var encrypted = CryptoJS.DES.encrypt(str, keyHex, {
							  mode: 		CryptoJS.mode.ECB,
							  padding: 		CryptoJS.pad.Pkcs7
							  });
	 var unicode = CryptoJS.enc.Base64.parse(encrypted.toString()).toString();
	 var  str = '';
	 for(var i = 0 ; i < unicode.length/2;++i){
		 var temp =parseInt (unicode.substr(i*2,2), 16);
		 if(temp>128)
		 {
			temp=temp-256;
		 }

		 if(i!=unicode.length/2-1)
		 {
			str+=temp.toString(32)+',';
		 }else{
			str+=temp.toString(32);
		 }
	}
	return str;
}


//3，解密方法
function decrypt4Pwd(str){
	var array = str.split(",");
	var returnStr = '';
	for (var i=0 ; i< array.length ; i++)
	{
		var temp;
		if(array[i].substr(0,1)=="-")
		{
			temp = (256-parseInt(array[i].substr(1,2),16)).toString(16);
		}else{
			if(parseInt(array[i],16)<16){
				temp = "0"+parseInt(array[i],16).toString(16);
			}else{
				temp = parseInt(array[i],16).toString(16);
			}
		}
		returnStr+=temp;
	}
	var encryptedHexStr = CryptoJS.enc.Hex.parse(returnStr);
	var encryptedBase64Str = CryptoJS.enc.Base64.stringify(encryptedHexStr);
	var keyHex = CryptoJS.enc.Utf8.parse("lyqguoqn");
	var decrypted = CryptoJS.DES.decrypt({
										  ciphertext:CryptoJS.enc.Base64.parse(encryptedBase64Str)
										  }, keyHex, {
										  mode: CryptoJS.mode.ECB,
										  padding: CryptoJS.pad.Pkcs7
										  });  
	returnStr = decrypted.toString(CryptoJS.enc.Utf8);
	return returnStr;
 }
//插入列表
function insertEl(messsageBack){

    menuDate=JSON.parse(messsageBack).list;
    for(var i=0;i<menuDate.length;i++)
    {	
		if(menuDate.length > 1){
			var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				var currRecipe = window.localStorage.getItem(deviceId+"_currRecipe");
				if(currRecipe != null && currRecipe != "null"){
					var currData = JSON.parse(currRecipe).list;
					if(currData[0].recipe == menuDate[i].recipe){
						continue;
					}
				}
			}
		}
		
        var totalMinutes= 0,listWrap;
        var picUrl = menuDate[i].picUrl;
        var subString = picUrl.substr(0,picUrl.length - 4);
        var listImg = "<div class='list_img'><img class='listImg' src='"+subString+"_m.jpg'/></div>";
        var listCir = "<div class='listCirWrap'><div class='cir on'></div></div>";
        var listMain = "<div class='list_main'><div class='list_main_title'>"+menuDate[i].name+"</div><div class='list_main_time' style='display: none'>烹饪中...</div></div>";
        var listBut =  "<div class='list_but'></div>";
        listWrap = "<div class='listWrap' id='" + menuDate[i].recipe + "'>" + listImg + listCir + listMain + listBut + "</div>" ;
        $("#listsContain").append(listWrap).insertBefore($(".mui-pull-bottom-pocket"));

    }
    picLoading();
    $(".listWrap").on("tap",{},function(ev){
        var menuId = $(this).attr("id");
        var title = $(this).find(".list_main_title").text();
        window.location.href="cookstep.html?menuTit="+decodeURI(title) +"&menuId="+menuId;
        ev.preventDefault();
    });
    //$("#listsContain").append("<div class='pullDown'>下拉加载</div>");
}
function picLoading(backData){
    document.addEventListener("readystatechange",function(event){

        if(document.readyState == "interactive"){

            for(var i=0;i < backData.length;i++ ){
                var picUrl1 =backData[i].picUrl;
                var urlString = picUrl.substr(0,picUrl1.length - 4)+"_m.jpg";
                document.getElementsByClassName("listImg")[i].setAttribute("data-src",picUrl1);
                document.getElementsByClassName("listImg")[i].src = document.getElementsByClassName("stepImg")[i].getAttribute("data-src");
            }
        }

    },false);
}
/**
 *  下拉刷新具体业务实现
 */
function pullDownRefresh() {
	setTimeout(function(){
        var localToken = window.localStorage.getItem("token");
        if(localToken == "null" || localToken == null){
            return;
        }
        startIndex = 1;
        endIndex = 6;
        
        getPlatform(JSON.parse(localToken));
        mui('#pullrefresh').pullRefresh().endPulldownToRefresh(false);
    },1500);

       
}

/**
 * 上拉加载具体业务实现
 */
function pullUpRefresh() {
    setTimeout(function(){
        var localToken = window.localStorage.getItem("token");
        if(localToken == "null" || localToken == null){
            return;
        }
        startIndex += 6;
        endIndex += 6;
        getPlatform(JSON.parse(localToken));
        mui('#pullrefresh').pullRefresh().endPullupToRefresh(false);

    },1500);
}

(function (mdSmart) {
    //var bDebug = true;
    var bDebug = false;
    mdSmart.B0_P03 = mdSmart.B0_P03 || {};
    $(document).on('pageinit', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P03 pageinit.');
        mdSmart.B0_P03.message = new mdSmart.msg0xB0();
        $(document).bind('recieveMessage', {}, function (event, message) {
            mdSmart.B0_P03.showStatus("", message);
        });
        try{
        	var session_status = window.localStorage.getItem(deviceId+"_local_status");
	        if(session_status !== "null" || session_status != null){
	        	mdSmart.B0_P03.showStatusByJson(JSON.parse(session_status));
	        }
		
        }catch(e){
        	bridge.goBack();
        }


		setInterval("mdSmart.B0_P03.cmdRequestStatus()",20000); //轮询
    });
    
    $(document).on('pageshow', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P03 pageshow.');
		//多语言画面文言绑定
		mdSmart.B0_P03.pageTextInit();
		mdSmart.B0_P03.cmdRequestStatus();
		var session_status = window.localStorage.getItem(deviceId+"_local_status");
		mdSmart.B0_P03.showStatusByJson(JSON.parse(session_status));
		//mdSmart.B0_P03.cmdRequestStatus();
       // var session_status = window.localStorage.getItem("local_status");
		//if(session_status == "null" || session_status == null){
			
		//} else {
		//	mdSmart.B0_P03.showStatusByJson(session_status);
		//}
		//工作状态按钮绑定事件
        $("#B0_P03_BTN_BACK").bind('tap', {}, mdSmart.B0_P03.gotoHomePage);
		$("#B0_P03_Pause").bind('tap', {}, mdSmart.B0_P03.eventPause);
		$("#B0_P03_Cancel").bind('tap', {}, mdSmart.B0_P03.eventCancel);
		$("#B0_P03_ChildLock").bind('tap', {}, mdSmart.B0_P03.eventChildLock);
		$("#B0_P03_PowerOff").bind('tap',{},mdSmart.B0_P03.eventPowerOff);
		$("#menu_opt_1_list li").bind('tap', {}, mdSmart.B0_P03.menu_opt_1_list);
		$("#menu_opt_2_list li").bind('tap', {}, mdSmart.B0_P03.menu_opt_2_list);
		$("#menu_opt_3_list li").bind('tap', {}, mdSmart.B0_P03.menu_opt_3_list);

    });
    $(document).on('pagehide', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P03 pagehide.');
        //取消绑定事件
		$("#B0_P03_BTN_BACK").unbind('tap');
		$("#B0_P03_Pause").unbind('tap');
		$("#B0_P03_Cancel").unbind('tap');
		$("#B0_P03_ChildLock").unbind('tap');
		$("#menu_opt_1_list li").unbind('tap');
		$("#menu_opt_2_list li").unbind('tap');
		$("#menu_opt_3_list li").unbind('tap');
    });
	//多语言画面文言绑定
    mdSmart.B0_P03.pageTextInit=function(){
	    console.log("mdSmart.B0_P03.pageTextInit");
		//$("#B0_P03_BTN_BACK").html(mdSmart.i18n.BACK);
		//$("#B0_P03_TITLE").html(mdSmart.i18n.APP_NAME);
		//$("#B0_P03_TEXT_MINUTES").html(mdSmart.i18n.MINUTE);
		//$("#B0_P03_TEXT_SECOND").html(mdSmart.i18n.SECOND);
		//$("#B0_P03_TEXT_AUTOMENU").html(mdSmart.i18n.AUTOMENU);
		//$("#B0_P03_TEXT_AREAMENU").html(mdSmart.i18n.REGIONAL_RECIPE);
		// $("#B0_P03_TEXT_AREAMENU_GUANGDONG").html(mdSmart.i18n.GUANGDONG+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_SICHUAN").html(mdSmart.i18n.SICHUAN+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_SHANDONG").html(mdSmart.i18n.SHANDONG+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_JIANGSU").html(mdSmart.i18n.JIANGSU+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_FUJIAN").html(mdSmart.i18n.FUJIAN+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_ZHEJIANG").html(mdSmart.i18n.ZHEJIANG+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_HUNAN").html(mdSmart.i18n.HUNAN+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_AREAMENU_ANHUI").html(mdSmart.i18n.ANHUI+mdSmart.i18n.FOOD);
		// $("#B0_P03_TEXT_SEASONSMENU").html(mdSmart.i18n.SOUP_IN_FOUR_SEASONS);
		// $("#B0_P03_TEXT_SEASONSMENU_SPRING").html(mdSmart.i18n.SPRING);
		// $("#B0_P03_TEXT_SEASONSMENU_SUMMER").html(mdSmart.i18n.SUMMER);
		// $("#B0_P03_TEXT_SEASONSMENU_AUTUMN").html(mdSmart.i18n.AUTUMN);
		// $("#B0_P03_TEXT_SEASONSMENU_WINTER").html(mdSmart.i18n.WINTER);
		// $("#B0_P03_TEXT_LOCALMENU").html(mdSmart.i18n.LOCAL_RECIPE);
		// $("#B0_P03_TEXT_LOCALMENU_ALL").html(mdSmart.i18n.ALL);
		// $("#B0_P03_TEXT_AUTOMENU_DOWN").html(mdSmart.i18n.AUTOMENU);
		// $("#B0_P03_Pause span").html(mdSmart.i18n.PAUSE_FUNCTION);
		// $("#B0_P03_Cancel span").html(mdSmart.i18n.CANCEL_FUNCTION);
		// $("#B0_P03_ChildLock span").html(mdSmart.i18n.CHILDLOCK_FUNCTION);
	};
    mdSmart.B0_P03.prepareAndShow = function () {
        console.log("mdSmart.B0_P03.prepareAndShow");
		mdSmart.B0_P03.cmdRequestStatus();
        // if (bDebug == true) {
            // var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();           
            // var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
			// mdSmart.message.setByte(messageBody,0,0x02);
			// mdSmart.message.setByte(messageBody,1,0x01);
            // var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
            // var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            // bridge.recieveMessage(bridgeMessage);
        // }
    };
    //菜单列表点击
    mdSmart.B0_P03.list_main=function(){
        // debugger;
        mdSmart.B0_P03.MenuId=$(this).attr("id");
        var title = "沙茶猪肝";
        var menuId = "07d8a0c9ad40443ba000e9d466894aeb";
        window.location.href="cookstep.html?menuTit="+decodeURI(title) +"&menuId="+menuId;
    };


	// 工作状态--关机
    var timerDown = null;
	//开关按钮
	mdSmart.B0_P03.eventPowerOff = function(){
		console.log("function:mdSmart.B0_P03.eventPowerOff");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if ($('#B0_P03_PowerOff').find('span').html() === '关机') {
//            $('#B0_P03_PowerOff').find('span').html('确认关机');
//            $('#B0_P03_PowerOff').find('span').css({
//                'background-image': 'url(./images/footer-power-icon-closed.png)'
//            })
//            $('#B0_P03_PowerOff').css({
//                'border-color': 'red'
//            })
//            timerDown = setTimeout(function(){
//                $('#B0_P03_PowerOff').find('span').html('关机');
//                $('#B0_P03_PowerOff').find('span').css({
//                    'background-image': 'url(./images/power.png)'
//                })
//                $('#B0_P03_PowerOff').css({
//                    'border-color': '#ccc'
//                })
//            },3000)
//        } else if ($('#B0_P03_PowerOff').find('span').html() === '确认关机') {
//            if(timerDown) clearTimeout(timerDown);
            mdSmart.B0_P03.message.setFunctionWorkStateEnergySaving();
			var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				mdSmart.common.isCartBtnLockControl(false);
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				mdSmart.B0_P03.cmdRequestStatus();
			}, function(errCode) {
				if (errCode == -1) {
					mdSmart.common.isCartBtnLockControl(false);
				}
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
        } else {
			mdSmart.B0_P03.message.setFunctionWorkStateStandby();
			mdSmart.B0_P03.message.setFunctioncheckSum();
			var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
          
        }
	}

	//返回按钮
    mdSmart.B0_P03.gotoHomePage=function(){
	    console.log("function:mdSmart.B0_P03.gotoHomePage");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		bridge.goBack();
	};
	//暂停按钮
	mdSmart.B0_P03.eventPause=function(){
		console.log("function:mdSmart.B0_P03.eventPause");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if($("#B0_P03_Pause span").text()=="暂停")
		{
            $("#B0_P03_Pause span").text("开始");
			mdSmart.B0_P03.setFunctionWorkStatePause();
		}
		else
		{
            $("#B0_P03_Pause span").text("暂停");
			mdSmart.B0_P03.setFunctionWorkStateWork();
		}
	};
	//取消按钮
	mdSmart.B0_P03.eventCancel=function(){
		
		console.log("function:mdSmart.B0_P03.eventCancel");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		
		mdSmart.B0_P03.setFunctionWorkStateStandby();
			
	};
	//童锁、解锁按钮
	mdSmart.B0_P03.eventChildLock=function(){
		
	    console.log("function:mdSmart.FC_P03.eventChildLock");
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		
		//$("#B0_P03_ChildLock span").html()=="童锁"
		if($("#B0_P03_ChildLock span").html()=="童锁")
		{
			mdSmart.B0_P03.setFunctionWorkStateLock();
		}
		else
		{
			mdSmart.B0_P03.setFunctionWorkStateStandby();
		}
	};
	//区域菜选择
	mdSmart.B0_P03.menu_opt_1_list=function(){
		console.log("function:mdSmart.FC_P03.menu_opt_1_list");
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		$.mobile.changePage("#B0_P04","true");
	};
	//四季汤水选择
	mdSmart.B0_P03.menu_opt_2_list=function(){
		console.log("function:mdSmart.FC_P03.menu_opt_1_list");
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		$.mobile.changePage("#B0_P04","true");
	};
	//本地菜选择
	mdSmart.B0_P03.menu_opt_3_list=function(){
		console.log("function:mdSmart.FC_P03.menu_opt_1_list");
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		$.mobile.changePage("#B0_P04","true");
	};
	// 工作状态--待机
    mdSmart.B0_P03.setFunctionWorkStateStandby = function () {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateStandby");
        mdSmart.B0_P03.message.setFunctionWorkStateStandby();
		mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
    		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--暂停
    mdSmart.B0_P03.setFunctionWorkStatePause = function () {
		//门没关不可以操作
        console.log("function:mdSmart.B0_P03.setFunctionWorkStatePause");
        mdSmart.B0_P03.message.setFunctionWorkStatePause();
		mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
    		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--工作
    mdSmart.B0_P03.setFunctionWorkStateWork = function () {
		//门没关不可以操作
		
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateWork");
        mdSmart.B0_P03.message.setFunctionWorkStateWork();
		mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--结束
    mdSmart.B0_P03.setFunctionWorkStateOver = function () {
		//门没关不可以操作
		if($("#hidden_door_state").html()==1){
			$("#B0_P03_DIALOG_Warning_Text").html("门没关不可以操作。");
			mdSmart.common.doPopupByA("B0_P03_DIALOG_Warning");
			return false;
		}
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateOver");
        mdSmart.B0_P03.message.setFunctionWorkStateOver();
		mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
    		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--童锁
    mdSmart.B0_P03.setFunctionWorkStateLock = function () {
	
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateLock");
        mdSmart.B0_P03.message.setFunctionWorkStateLock();
		mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
	 // 查询按钮
    mdSmart.B0_P03.cmdRequestStatus = function () {
		
        console.log("function:mdSmart.B0_P03.cmdRequestStatus");
		var cmdBytes = mdSmart.B0_P03.message.cmdRequestStatus();    
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);		
		// var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
		// var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
		// var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
		// bridge.recieveMessage(bridgeMessage);
    };
	//模拟返回数据
    mdSmart.B0_P03.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P03.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P03.message.getResponseBack();
            var messageType = cmdMessageType;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = cmdMessageType;
            }else{
				mdSmart.message.setBits(messageBody,0,0,3,0x01);
				mdSmart.message.setBit(messageBody,0,7,0x00);
				mdSmart.message.setByte(messageBody,1,0x02);
			}
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };


	mdSmart.B0_P03.getWorkStatus = function(workMode, temperature){
		var workStateParam = "";
		switch(workMode){
			case 0x01: //微波
				switch(temperature){
					case 0x01:
						workStateParam = "小文火";
						break;
					case 0x02:
						workStateParam = "";
						break;
					case 0x03:
						workStateParam = "文火";
						break;
					case 0x04:
						workStateParam = "";
						break;
					case 0x05:
						workStateParam = "中火";
						break;
					case 0x06:
						workStateParam = "";
						break;
					case 0x07:
						workStateParam = "";
						break;
					case 0x08:
						workStateParam = "武火";
						break;
					case 0x09:
						workStateParam = "";
						break;
					case 0x0a:
						workStateParam = "大武火";
						break;
				}
				break;
			case 0x02:  //烧烤
				switch(temperature){
					case 0x01:
						workStateParam = "纯烧烤";
						break;
					case 0x02:
						workStateParam = "组合1";
						break;
					case 0x03:
						workStateParam = "组合2";
						break;
				}
				break;
			case 0x03:
				break;
			case 0x04:
				switch(temperature){
					case 0x00:
						workStateParam = "按重";
						break;
					case 0x01:
						workStateParam = "按时";
						break;
				}
				break;
			case 0x05:
				workStateParam = temperature+"度";
				break;
			case 0x06:
				workStateParam = temperature+"度";
				break;
			case 0x07:
				break;
			case 0x08:
				break;
			case 0x09:
				if(temperature == 0x01)
					workStateParam = "文火";
				else if(temperature == 0x02)
					workStateParam = "中火";
				break;
		}
		return workStateParam;
	}

    mdSmart.B0_P03.showStatus = function (messageBackRequest, messageBackBack) {
		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
	    var jsonStatus = mdSmart.B0_P03.message.parseMessageForView(messageBackBack);
		
		mdSmart.B0_P03.showStatusByJson(jsonStatus);
    }
	
	mdSmart.B0_P03.showStatusByJson = function (messageBackBack) {
	    var jsonStatus = messageBackBack;
		var workState = jsonStatus.status.workState.value;
		var workMode = jsonStatus.status.workMode.value;
		var temperature = jsonStatus.status.temperature.value;
		var surplusTimeMinute = jsonStatus.status.surplusTimeMinute.value;
		var surplusTimeSeconds = jsonStatus.status.surplusTimeSeconds.value;
		var errorCode = jsonStatus.status.errorCode.value;
		var DoorIsOpen = jsonStatus.status.DoorIsOpen.value;

		if(workState < 0x01 || workState > 0x0c) //错误状态
			return;
		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
        //$("#log").text(JSON.stringify(jsonStatus));
		$("#B0_P03_mode_close_bg").css("opacity","1.0");
		if(workState == 0x09){//爱心3秒
			workState = 0x03;
		}
		
		window.localStorage.setItem(deviceId+"_local_status",JSON.stringify(jsonStatus));  //缓存
		if(errorCode != 0x00){//故障
			$("#iOSdialogBoxLockScreen").remove();
			$("#iOSdialogBoxWindow").remove();
			$(this).iOSdialogBoxAlert({
				'title'   : "E-0"+errorCode+"故障" ,
				'message' : '请尽快联系售后人员维修' ,
				'button' : '确定'
			},timeOut1);
			function timeOut1(returnData){
				bridge.goBack();
			}
			return;
		} else{

		}


		if(DoorIsOpen == 0x01){//提醒
			$("#iOSdialogBoxLockScreen").remove();
			$("#iOSdialogBoxWindow").remove();
			$(this).iOSdialogBoxAlert({
				'title'   : "炉门没关！" ,
				'message' : '请确保炉门关紧' ,
				'button' : '确定'
			},timeOut2);
			function timeOut2(returnData){
				mdSmart.B0_P03.setFunctionWorkStateStandby();
			}
			return;
		}
		
		if(workState == 0x0a){//自检
			$("#iOSdialogBoxLockScreen").remove();
			$("#iOSdialogBoxWindow").remove();
			$(this).iOSdialogBoxAlert({
				'title'   : "设备自检！" ,
				'message' : '请按取消键结束自检' ,
				'button' : '取消'
			},timeOut2);
			function timeOut2(returnData){
				bridge.goBack();
			}
			return;
		}

		if(workState == 0x0c){//演示
			$("#iOSdialogBoxLockScreen").remove();
			$("#iOSdialogBoxWindow").remove();
			$(this).iOSdialogBoxAlert({
				'title'   : "操作演示！" ,
				'message' : '请按取消键结束操作演示' ,
				'button' : '取消'
			},timeOut2);
			function timeOut2(returnData){
				mdSmart.B0_P03.setFunctionWorkStateStandby();
			}
			return;
		}

		$("#iOSdialogBoxLockScreen").remove();
		$("#iOSdialogBoxWindow").remove();
		if(workState == 0x01){
			$("#B0_P03_TimeMinShow").text("00");
			$("#B0_P03_TimeSecShow").text("00");
		}else {
			$("#B0_P03_TimeMinShow").text(mdSmart.common.formatNumberByZero(surplusTimeMinute,2));
			$("#B0_P03_TimeSecShow").text(mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
		}
		$("#B0_P03_ChildLock").removeClass("disableTouch");
		$("#B0_P03_Pause").removeClass("disableTouch");
		$("#B0_P03_Cancel").removeClass("disableTouch");
		$("#B0_P03_ChildLock").unbind('tap');
		$("#B0_P03_Pause").unbind('tap');
		$("#B0_P03_Cancel").unbind('tap');
		$("#B0_P03_Pause").bind('tap', {}, mdSmart.B0_P03.eventPause);
		$("#B0_P03_Cancel").bind('tap', {}, mdSmart.B0_P03.eventCancel);
		$("#B0_P03_ChildLock").bind('tap', {}, mdSmart.B0_P03.eventChildLock);

		$(".topbg_01").removeClass("offTitBg");
		$(".data_area_1").removeClass("offTitBg");
		$(".topbg_01").removeClass("workTitBg");
		$(".data_area_1").removeClass("workInfoBg");
		$("#B0_P03_TimeSecShow").removeClass("mainLock");
		$("#B0_P03_Pause span").text("暂停");
		$("#B0_P03_ChildLock").find('span').text("童锁");
		$("#B0_P03_ChildLock").removeClass("icon_control01_active");
		$("#B0_P03_WorkModeShow").text("");
		$("#B0_P03_SurplusTimeShow").text("");
		$(".listCirWrap").hide();
		$(".list_main_time").hide();
		//省电
		if(workState == 0x07){
			//$("#B0_P03_ChildLock").css("opacity","0.4");
            $("#B0_P03_ChildLock").addClass("disableTouch");
			//$("#B0_P03_Pause").css("opacity","0.4");
            $("#B0_P03_Pause").addClass("disableTouch");
			//$("#B0_P03_Cancel").css("opacity","0.4");
            $("#B0_P03_Cancel").addClass("disableTouch");
			$("#B0_P03_ChildLock").unbind('tap');
			$("#B0_P03_Pause").unbind('tap');
			$("#B0_P03_Cancel").unbind('tap');

            $(".functiondiv").css("background","#f5f8fa");
			$("#CloseStatus").show();
			$("#NormalStatus").hide();
			$(".topbg_01").addClass("offTitBg");
			$(".data_area_1").addClass("offTitBg");

			$('#B0_P03_PowerOff').find('span').html('开机');
            $('#B0_P03_PowerOff').find('span').css({
                'background-image': 'url(./images/footer-power-icon.png)'
            });
            $('#B0_P03_PowerOff').css({
                'border-color': '#089c0b'
            });
		} else{
			$("#CloseStatus").hide();
            $(".functiondiv").css("background","#dee5eb");
			$("#NormalStatus").show();
			$('#B0_P03_PowerOff').find('span').html('关机');
			$('#B0_P03_PowerOff').find('span').css({
				'background-image': 'url(./images/power.png)'
			})
			$('#B0_P03_PowerOff').css({
				'border-color': '#ccc'
			})
		}

		//开关按钮的按钮不可操作
		if(workState == 0x01 || workState == 0x07){
			$('#B0_P03_PowerOff').css("opacity","1");
			$("#B0_P03_PowerOff").unbind('tap');
			$("#B0_P03_PowerOff").bind('tap',{},mdSmart.B0_P03.eventPowerOff);
		} else{
			$('#B0_P03_PowerOff').css("opacity","0.4");
			$("#B0_P03_PowerOff").unbind('tap');
		}

		//初始化菜单项
		if(workState == 0x01){
			window.localStorage.setItem(deviceId+"_local_workMode", "null");
		}

		
		if(workState == 0x01){  //待机
            $(".listWrap").find(".list_main_title").css("margin-top","20%");
            $("#B0_P03_Pause").addClass("disableTouch");
            $("#B0_P03_Cancel").addClass("disableTouch");
			$("#B0_P03_Pause").unbind('tap');
			$("#B0_P03_Cancel").unbind('tap');

		} else if(workState == 0x05){  //童锁
     //       $(".listWrap").find(".listCirWrap",".list_main_time").hide();
			$(".listWrap").find(".list_main_title").css("margin-top","20%");

            $("#B0_P03_Pause").addClass("disableTouch");
            $("#B0_P03_Cancel").addClass("disableTouch");
			$("#B0_P03_Pause").unbind('tap');
			$("#B0_P03_Cancel").unbind('tap');
			$("#B0_P03_ChildLock").find('span').text("解锁");
			$("#B0_P03_ChildLock").addClass("icon_control01_active");
			$("#B0_P03_TimeSecShow").addClass("mainLock");
		} else if(workState == 0x02){  //工作中
            /**
             * 烹饪中
             */
			var menuItem = $.trim(window.localStorage.getItem(deviceId+"_local_workMode"));
			$(".listWrap").each(function(){
				if($.trim($(this).find(".list_main_title").text()) == menuItem){
					$(this).find(".listCirWrap").show();
					$(this).find(".cir").addClass("on");
					$(this).find(".list_main_title").css("margin-top","10px");
					$(this).find(".list_main_time").show();
					$(this).find(".list_main_time").text("烹饪中...");
				}else {
					$(this).find(".list_main_time").hide();
				}
			});

			$("#B0_P03_ChildLock").addClass("disableTouch");
			$("#B0_P03_ChildLock").unbind('tap');
			$(".topbg_01").addClass("workTitBg");
			$(".data_area_1").addClass("workInfoBg");
			var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
			if(constant_workMode == "null" || constant_workMode == null){  //不是自动菜单
				$("#B0_P03_WorkModeShow").text(jsonStatus.status.workMode.view[workMode]);
				var workStatusParam = mdSmart.B0_P03.getWorkStatus(workMode, temperature);
				$("#B0_P03_SurplusTimeShow").text(workStatusParam);
				$(".data_status").css("margin-top","3%");
				
			} else {  //自动菜单
				if(constant_workMode.length>3){
					constant_workMode = constant_workMode.substring(0,3)+"..";
				}
				$("#B0_P03_WorkModeShow").text(constant_workMode);
				$("#B0_P03_SurplusTimeShow").text("");
				$(".data_status").css("margin-top","15%");
				
			}

			if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
				$("#B0_P03_TimeMinShow").text("00");
				$("#B0_P03_TimeSecShow").text("00");
			}else{
				mdSmart.B0_P03.formatSecondsDownRunOnlyOneTime(surplusTimeMinute, surplusTimeSeconds);
				mdSmart.B0_P03.formatSecondsDownF(surplusTimeMinute, surplusTimeSeconds);
			}
			
		} else if(workState == 0x03){  //暂停
			var menuItem = $.trim(window.localStorage.getItem(deviceId+"_local_workMode"));
			$(".listWrap").each(function(){
				if($.trim($(this).find(".list_main_title").text()) == menuItem){
					$(this).find(".listCirWrap").show();
					$(this).find(".cir").removeClass("on");
					$(this).find(".list_main_title").css("margin-top","10px");
					$(this).find(".list_main_time").show();
					$(this).find(".list_main_time").text("暂停中...");
				}else {
					$(this).find(".list_main_time").hide();
				}
			});


			$("#B0_P03_ChildLock").addClass("disableTouch");
			$("#B0_P03_ChildLock").unbind('tap');
			$(".topbg_01").addClass("workTitBg");
			$(".data_area_1").addClass("workInfoBg");
			$("#B0_P03_Pause span").text("开始");
			var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
			if(constant_workMode == "null" || constant_workMode == null){  //不是自动菜单
				$("#B0_P03_WorkModeShow").text(jsonStatus.status.workMode.view[workMode]);
				var workStatusParam = mdSmart.B0_P03.getWorkStatus(workMode, temperature);
				$("#B0_P03_SurplusTimeShow").text(workStatusParam);
				$(".data_status").css("margin-top","3%");
				
			} else {  //自动菜单
				if(constant_workMode.length>3){
					constant_workMode = constant_workMode.substring(0,3)+"..";
				}
				$("#B0_P03_WorkModeShow").text(constant_workMode);
				$("#B0_P03_SurplusTimeShow").text("");
				$(".data_status").css("margin-top","15%");
				
			}

			if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
				$("#B0_P03_TimeMinShow").text("00");
				$("#B0_P03_TimeSecShow").text("00");
			}else{
				$("#B0_P03_TimeMinShow").text(mdSmart.common.formatNumberByZero(surplusTimeMinute,2));
				$("#B0_P03_TimeSecShow").text(mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
			}
			
		} else if(workState == 0x04){  //结束
            $(".listWrap").find(".list_main_title").css("margin-top","20%");
			$("#iOSdialogBoxLockScreen").remove();
			$("#iOSdialogBoxWindow").remove();
			$("#B0_P03_WorkModeShow").text("烹饪完成！");
			$(this).iOSdialogBoxAlert({
				'title'   : "烹饪完成！" ,
				'message' : '请尽快取出食物' ,
				'button' : '确定'
			},timeOut5);
			function timeOut5(returnData){
				 mdSmart.B0_P03.setFunctionWorkStateStandby();
                 bridge.goBack();
            }
			return;
		}

    };

	// 将秒数换成分秒格式倒计时
    mdSmart.B0_P03.formatSecondsFunctionDown1 = 0;
	mdSmart.B0_P03.formatSecondsDownF = function(minutes, seconds){
		var int_T = parseInt(minutes)*60 + parseInt(seconds);
		mdSmart.B0_P03.formatSecondsFunctionDown1 = window.setInterval(
			function (){
				var theTime = parseInt(int_T);// 秒
			    var theTime1 = 0;// 分
			    if(theTime >= 60) {
			        theTime1 = parseInt(theTime/60);
			        theTime = parseInt(theTime%60);
			    }
		        //var result = parseInt(theTime1)+":"+mdSmart.common.formatNumberByZero(theTime,2);
		        if(int_T <= 0){
		        	// mdSmart.B0_P01.Close();
    				window.clearInterval(mdSmart.B0_P01.formatSecondsFunctionDown1);
					//$("#B0_P01_LBL_SURPLUSTIME").html("0:00");
					$("#B0_P03_TimeMinShow").text("00");
					$("#B0_P03_TimeSecShow").text("00");
		        }else{
					$("#B0_P03_TimeMinShow").text(mdSmart.common.formatNumberByZero(theTime1,2));
					$("#B0_P03_TimeSecShow").text(mdSmart.common.formatNumberByZero(theTime,2));
					int_T--;
		        }
			}, 1000);
	}
	mdSmart.B0_P03.formatSecondsDownRunOnlyOneTime = function(minutes, seconds){
		var int_T = parseInt(minutes)*60 + parseInt(seconds);
		var theTime = parseInt(int_T);// 秒
	    var theTime1 = 0;// 分
	    if(theTime >= 60) {
	        theTime1 = parseInt(theTime/60);
	        theTime = parseInt(theTime%60);
	    }
        //var result = parseInt(theTime1)+":"+mdSmart.common.formatNumberByZero(theTime,2);
        if(int_T <= 0){
        	// mdSmart.B0_P03.Close();
        }else{
			$("#B0_P03_TimeMinShow").text(mdSmart.common.formatNumberByZero(theTime1,2));
			$("#B0_P03_TimeSecShow").text(mdSmart.common.formatNumberByZero(theTime,2));
        }
	}
    mdSmart.B0_P03.showJSON = function (pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    }
                    else {
                        strStatus = strStatus + temp.value;
                    }
                }
                else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_P03.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
