(function (mdSmart) {
    // var bDebug = true;
    var bDebug = false;
    mdSmart.B0_P04 = mdSmart.B0_P04 || {};

    $(document).on('pageinit', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P04 pageinit.');
        mdSmart.B0_P04.message = new mdSmart.msg0xB0();
        // $(document).bind('recieveMessage', {}, function (event, message) {
            // mdSmart.B0_P04.showStatus("", message);
        // });

    });
    
    $(document).on('pageshow', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P04 pageshow.');
		//多语言画面文言绑定
		// mdSmart.B0_P04.pageTextInit();
        // mdSmart.B0_P04.prepareAndShow();
		//工作状态按钮绑定事件
        // $("#B0_P04_BTN_BACK").bind('tap', {}, mdSmart.B0_P04.gotoHomePage);
		//$(".list_img").bind('tap', {}, mdSmart.B0_P04.list_main);
		//$(".list_main").bind('tap', {}, mdSmart.B0_P04.list_main);
		$(".listWrap").bind('tap', {}, mdSmart.B0_P04.list_main);
    });

    $(document).on('pagehide', 'div[id="B0_P03"]', function (event) {
        console.log('#B0_P04 pagehide.');
        //取消绑定事件
		// $("#B0_P04_BTN_BACK").unbind('tap');
		$(".list_img").unbind('tap');
		$(".list_main").unbind('tap');
		$(".list_but").unbind('tap');
    });
	//多语言画面文言绑定
    mdSmart.B0_P04.pageTextInit=function(){
	    console.log("mdSmart.B0_P04.prepareAndShow");
	    $("#B0_P03_BTN_BACK").html(mdSmart.i18n.BACK);//返回
	};
    mdSmart.B0_P04.prepareAndShow = function () {
        console.log("mdSmart.B0_P04.prepareAndShow");
		// $("#"+B0_P03_Menu_SelectName+"_list a").next("div").slideToggle("slow");
		// $("#"+B0_P03_Menu_SelectName+"_list a").toggleClass("icon_modebg_active");
		// $("#"+B0_P03_Menu_SelectName+"_list a").siblings(".icon_modebg_active").removeClass("icon_modebg_active");
		//$("#Regional_Y").toggleClass("icon_modebg_active");
		//mdSmart.B0_P04.cmdRequestStatus();
        // if (bDebug == true) {
            // var cmdBytes = mdSmart.B0_P04.message.cmdControlStatus();           
            // var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
			// mdSmart.message.setByte(messageBody,0,0x05);
            // var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
            // var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            // bridge.recieveMessage(bridgeMessage);
        // }
    };
	//返回按钮
    mdSmart.B0_P04.gotoHomePage=function(){
	    console.log("function:mdSmart.B0_P04.gotoHomePage");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		//bridge.goBack();
		$.mobile.changePage("#B0_P03", "turn");
	};
	//菜单开始
	// mdSmart.B0_P04.eventMenuStart=function(){
		// console.log("function:mdSmart.B0_P04.eventMenuStart");
		// if(mdSmart.common.isOperationLock() == true){return false;}
		// if(mdSmart.common.isPopupLock() == true){return false;}
		// //bridge.goBack();
		// var currentId=$(this).attr("id");
		// var currentMenu = mdSmart.B0_P04.menuDate.filter(function(e) {
				// return e.id==currentId;
			// });
		// for(var i=0;i<currentMenu[0].byte20[0].cmd.length;i++)
		// {
			// var array = currentMenu[0].byte20[0].cmd[i].bytectrl;
			// var cmdBytes = [];
			// for (var i=0 ; i< array.length ; i++)
			// {
				// i++;
				// cmdBytes.push(parseInt(array.substring(i-1,i+1),16));
			// }
			// window.setTimeout(mdSmart.B0_P04.startMenu(cmdBytes),400);
		// }
	// };
	//菜单发令
	// mdSmart.B0_P04.startMenu=function(cmdBytes){
		// var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			// mdSmart.B0_P04.showStatus(cmdBytes, messageBack);
			// $.mobile.changePage("#B0_P03","turn");
		// });
		// mdSmart.B0_P04.afterControlProcess(cmdId, cmdBytes);
	// };
	mdSmart.B0_P04.list_main=function(){
		// debugger;
		mdSmart.B0_P04.MenuId=$(this).attr("id");
        var title = $(this).find(".list_main_title").text();
	    //$.mobile.changePage("#cookStep", "turn");
        window.location.href="cookstep.html?menuTit="+decodeURI(title);
	};
	//模拟返回数据
    mdSmart.B0_P04.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P04.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P04.message.getResponseBack();
            var messageType = 0x82;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = cmdMessageType;
            }
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_P04.showStatus = function (messageBackRequest, messageBackBack) {
	
	    var jsonStatus = mdSmart.B0_P04.message.parseMessageForView(messageBackBack);
		// if(jsonStatus.status.workState.value==0x05 && mdSmart.message.getByte(messageBackBack,9)==0x03)
		// {
			// $(".icon_control02").next("div").slideToggle("slow");
			// $(".icon_control02").toggleClass("icon_control02_active");
			// $(".icon_control02").siblings(".icon_control02_active").removeClass("icon_control02_active");
		    // $(".icon_control02 span").html(mdSmart.i18n.WORK_STATE_UnLock);
		// }
        // $("#sendMsgDiv").html("<hr>send:" + mdSmart.message.convertTo16Str(messageBackRequest));
        // $("#receiveMsgDiv").html("<hr>receive:" + mdSmart.message.convertTo16Str(messageBackBack));
        var jsonStatus = mdSmart.B0_P04.message.parseMessageForView(messageBackBack);
        //var strStatus = "isRequestBack:" + jsonStatus.isRequestBack + "<br>";
        var strStatus = "messageType:" + jsonStatus.messageType + "<br>";
        //strStatus = strStatus + "messageBodyCommand:" + jsonStatus.messageBodyCommand + "<br>";
        strStatus = strStatus + mdSmart.B0_P04.showJSON(jsonStatus.status)
        // $("#statusDiv").html("<hr>" + strStatus);
        //$("#statusDiv").html(JSON.stringify(jsonStatus));
    }
    mdSmart.B0_P04.showJSON = function (pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    }
                    else {
                        strStatus = strStatus + temp.value;
                    }
                }
                else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_P04.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
