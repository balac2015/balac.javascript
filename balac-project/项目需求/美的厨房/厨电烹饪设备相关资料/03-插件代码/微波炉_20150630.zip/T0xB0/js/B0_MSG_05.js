(function (mdSmart) {
    // var bDebug = true;
    var bDebug = false;
    mdSmart.B0_P05 = mdSmart.B0_P05 || {};

    $(document).on('pageinit', 'div[id="B0_P05"]', function (event) {
        console.log('#B0_P05 pageinit.');
        mdSmart.B0_P05.message = new mdSmart.msg0xB0();
        // $(document).bind('recieveMessage', {}, function (event, message) {
            // mdSmart.B0_P05.showStatus("", message);
        // });
    });
    
    $(document).on('pageshow', 'div[id="B0_P05"]', function (event) {
        console.log('#B0_P05 pageshow.');
		//多语言画面文言绑定
		mdSmart.B0_P05.pageTextInit();
        mdSmart.B0_P05.prepareAndShow();
		//工作状态按钮绑定事件
        $("#B0_P05_BTN_BACK").bind('tap', {}, mdSmart.B0_P05.gotoHomePage);
		$("#B0_P05_MenuStart").bind('tap',{}, mdSmart.B0_P05.eventMenuStart);
    });

    $(document).on('pagehide', 'div[id="B0_P05"]', function (event) {
        console.log('#B0_P05 pagehide.');
        //取消绑定事件
		$("#B0_P05_BTN_BACK").unbind('tap');
		$("#B0_P05_MenuStart").unbind('tap');
    });
	//多语言画面文言绑定
    mdSmart.B0_P05.pageTextInit=function(){
	    console.log("mdSmart.B0_P05.pageTextInit");
	    $("#B0_P05_BTN_BACK").html(mdSmart.i18n.BACK);
	    $("#B0_P05_TITLE").html(mdSmart.i18n.RECIPE);
	};
    mdSmart.B0_P05.prepareAndShow = function () {
        console.log("mdSmart.B0_P05.prepareAndShow");
		// $("#"+B0_P03_Menu_SelectName+"_list a").next("div").slideToggle("slow");
		// $("#"+B0_P03_Menu_SelectName+"_list a").toggleClass("icon_modebg_active");
		// $("#"+B0_P03_Menu_SelectName+"_list a").siblings(".icon_modebg_active").removeClass("icon_modebg_active");
		
		// alert(mdSmart.B0_P04.MenuId);
		if(mdSmart.B0_P04.MenuId==null||mdSmart.B0_P04.menuDate==null)
		{
			return false;
		}
		var currentMenu = mdSmart.B0_P04.menuDate.filter(function(e) {
			return e.id==mdSmart.B0_P04.MenuId;
		});
		$("#B0_P05_MenuName").html(currentMenu[0].mdrecipename);
		$("#B0_P05_MenuImag").attr("src",currentMenu[0].mdrecipepic);
		$("#B0_P05_MenuIntroduction").html(currentMenu[0].description);
		$("#B0_P05_MenuNeed").html(currentMenu[0].mdrecipeingd);
		$("#B0_P05_Menustep").html(currentMenu[0].mdrecipecook);
    };
	//返回按钮
    mdSmart.B0_P05.gotoHomePage=function(){
	    console.log("function:mdSmart.B0_P05.gotoHomePage");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		//bridge.goBack();
		$.mobile.changePage("#B0_P03", "turn");
	};
	//做菜
	mdSmart.B0_P05.eventMenuStart=function(){
		
		//门没关不可以操作
		if($("#hidden_door_state").html()==1){
			$("#B0_P05_DIALOG_Warning_Text1").html("门没关不可以操作。");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		//铜锁不能做菜
		if($("#hidden_work_state").html()==5){
			$("#B0_P05_DIALOG_Warning_Text1").html("童锁状态下不可以做菜。");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		//工作状态下不可执行此操作，请先停止工作
		if($("#hidden_work_state").html()==2 || $("#hidden_work_state").html()==8){
			$("#B0_P05_DIALOG_Warning_Text1").html("工作状态下不可执行此操作，请先停止工作。");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		if($("#B0_P03_TimeShow").html() != "0:00"){
			$("#B0_P05_DIALOG_Warning_Text1").html("工作状态下不可执行此操作，请先停止工作。");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		console.log("function:mdSmart.B0_P05.eventMenuStart");
		if(mdSmart.common.isOperationLock() == true){
			
			$("#B0_P05_DIALOG_Warning_Text1").html("isOperationLock");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		if(mdSmart.common.isPopupLock() == true){
			$("#B0_P05_DIALOG_Warning_Text1").html("isPopupLock");
			mdSmart.common.doPopupByA("B0_P05_DIALOG_Warning");
			return false;
		}
		//bridge.goBack();
		if(mdSmart.B0_P04.MenuId==null||mdSmart.B0_P04.menuDate==null)
		{
			return false;
		}
		// alert(mdSmart.B0_P04.MenuId);
		var currentId=mdSmart.B0_P04.MenuId;
		var currentMenu = mdSmart.B0_P04.menuDate.filter(function(e) {
				return e.id==currentId;
			});
		if (currentId == '8a2896304907432b014929e60e3922e5'){
			// 鹌鹑莲藕汤 第1段
	        mdSmart.B0_P05.startMenuFrist(0);
			// 鹌鹑莲藕汤 第2段
			mdSmart.B0_P05.startMenuSecond(1);
			
		} else if(currentId == '8a2896304907432b01492a85846922fc'){
			// 淮山芡实炖水鸭 第1段
	        mdSmart.B0_P05.startMenuFrist(2);
			// 淮山芡实炖水鸭 第2段
			mdSmart.B0_P05.startMenuSecond(3);
			
		} else if(currentId == '8a2896304907432b01492a89410e2300'){
			// 香菇枸杞酸枣仁炖老鸡汤 第1段
	        mdSmart.B0_P05.startMenuFrist(4);
			// 香菇枸杞酸枣仁炖老鸡汤 第2段
			mdSmart.B0_P05.startMenuSecond(5);
			
		} else if(currentId == '8a2896304907432b01492a8cd9ef2304'){
			// 牛蒡鲜淮山排骨汤 第1段
	        mdSmart.B0_P05.startMenuFrist(6);
			// 牛蒡鲜淮山排骨汤 第2段
			mdSmart.B0_P05.startMenuSecond(7);
			
		} else if(currentId == '8a2896304867a8de0148ba69b5383b47'){
			// 肉沫蒸豆腐 第1段
	        mdSmart.B0_P05.startMenuFrist(8);
	        
		} else if(currentId == '8a2896304907432b01492aaac52d2324'){
			// 香菇肉饼 第1段
	        mdSmart.B0_P05.startMenuFrist(9);
	        
		} else if(currentId == '8a28963047d9402f014825ac4e7421b4'){
			// 剁椒金针卷 第1段
	        mdSmart.B0_P05.startMenuFrist(10);
	        
		} else if(currentId == '8a28963047d9402f014825c1dbd521f3'){
			// 五花肉海带汤 第1段
	        mdSmart.B0_P05.startMenuFrist(11);
			// 五花肉海带汤 第2段
			mdSmart.B0_P05.startMenuSecond(12);
		} 
		
		window.setTimeout(function(){
			$.mobile.changePage("#B0_P03","turn");
		},2000);
	};
	//第1段菜单发令 第1段
	mdSmart.B0_P05.startMenuFrist=function(Food_Id){
		window.clearInterval(mdSmart.B0_P03.formatSecondsFunctionDown1);
        mdSmart.B0_P05.message.setFunctionFood(Food_Id);
        var cmdBytes = mdSmart.B0_P05.message.cmdControlStatus();
	    var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			//mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
		});
	};
	
	//第2段菜单发令 第2段
	mdSmart.B0_P05.startMenuSecond=function(Food_Id){
		
		window.setTimeout(function(){
			mdSmart.B0_P05.message.setFunctionFood(Food_Id);
	        var cmdBytes = mdSmart.B0_P05.message.cmdControlStatus();
		    var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
				//mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
			});
		},500);
	};
	//菜单发令
	// mdSmart.B0_P05.startMenu=function(cmdBytes){
		// var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			// mdSmart.B0_P05.showStatus(cmdBytes, messageBack);
			// $.mobile.changePage("#B0_P03","turn");
		// });
		// mdSmart.B0_P05.afterControlProcess(cmdId, cmdBytes);
	// };
	//模拟返回数据
    mdSmart.B0_P05.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P05.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P05.message.getResponseBack();
            var messageType = 0x82;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = cmdMessageType;
            }
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_P05.showStatus = function (messageBackRequest, messageBackBack) {
	    var jsonStatus = mdSmart.B0_P05.message.parseMessageForView(messageBackBack);
        $("#sendMsgDiv").html("<hr>send:" + mdSmart.message.convertTo16Str(messageBackRequest));
        $("#receiveMsgDiv").html("<hr>receive:" + mdSmart.message.convertTo16Str(messageBackBack));
        var strStatus = "messageType:" + jsonStatus.messageType + "<br>";
        strStatus = strStatus + mdSmart.B0_P05.showJSON(jsonStatus.status)
        $("#statusDiv").html("<hr>" + strStatus);
    }
    mdSmart.B0_P05.showJSON = function (pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    }
                    else {
                        strStatus = strStatus + temp.value;
                    }
                }
                else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_P05.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
