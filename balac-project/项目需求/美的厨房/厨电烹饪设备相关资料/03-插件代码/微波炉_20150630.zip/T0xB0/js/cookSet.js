var order;
var workStatus = "offline";//离线

//$("#log").text(JSON.stringify(testJson));
var results = testJson.cookStep,
    desc = results.desc, //描述
    easy = results.easy, //难易
    time = results.time, //耗时
    effect = results.effect.item, //特点(数组)
    finishedPicUrl = "./images/0.jpg",//results.finishedPicUrl[0].url, //完成图片(数组)
    ingredientPicUrl = "./images/0.jpg",//results.ingredientPicUrl[0].url, //配料图片(数组)
    ingredients = results.ingredients,//配料(数组)
    mainIngredients = results.mainingredients,//主料(数组)
	recipeId = results.id,  //id
	picUrl = results.picurl,  //图片
	name = results.name,  //名称
    steps = results.steps;//步骤
/**
 * 页面处理
 */
//$("#log").text(JSON.stringify(results));
//评分处理
 for(var i=0;i<parseInt(easy);i++){
    	$(".start").eq(i).addClass("startBg");
        //document.getElementsByClassName("start")[i].className = "start startBg";
 }    

var titImg = "<div class='topImg' ><img src='" +finishedPicUrl + "' id='titImg' data-src='' /></div>";
var titMsg =  "<div class='step_msg firstSlid'><div class='tit'>"+desc +"</div></div>";
var titEl =  "<div class='swiper-slide' >"+titImg+titMsg+"</div>";
var swiperWrapper = document.querySelector(".swiper-wrapper");
var mainIngredientTxt = "",secondIngredientTxt = "";
var mainIngredientMsg,secondIngredientMsg;
var IngredientImg = "<div class='topImg'><img src='" +ingredientPicUrl + "' id='ingredientPic' data-src='' /></div>";
//主料
var ingredient = {
    mainIngredient: function (){
        for(var i=0;i < mainIngredients.length; i++ ){

            mainIngredientTxt +=mainIngredients[i].name +"(" +mainIngredients[i].weight + ")"+"<br/>";
        }
        // mainIngredientTxt = mainIngredientTxt.substr(0,mainIngredientTxt.length-1);

        mainIngredientMsg =  " <div class='mainIngredient'><div class='mainIngredientTit'>主料</div><div id='mainIngredient'><div id='wrapper1'><div id='scroller1'><div>"+mainIngredientTxt +"</div></div></div></div></div>";

    },
    secondIngredient: function (){
        for(var i=0;i < ingredients.length; i++ ){
            secondIngredientTxt +=ingredients[i].name +"(" + ingredients[i].weight + ")"+"<br/>";
        }
        //secondIngredientTxt = secondIngredientTxt.substr(0,secondIngredientTxt.length-1);
        secondIngredientMsg =  "<div class='secondIngredient'><div class='secondIngredientTit'>辅料</div><div id='secondIngredient'><div id='wrapper'><div id='scroller'><div>"+secondIngredientTxt+"</div></div></div></div></div>";

    }
};
var step = {
    setStep:function (){
        var element = "<div class='swiper-slide' id=''></div>";
        var sn = window.localStorage.getItem(deviceId+"_B2_Sn");
        var subSn;
        var len = sn.length;
        subSn = sn.substring(1,len-1); 
        for(var i=0;i < steps.length;i++ ){
            var picUrl = "./images/0.jpg";//steps[i].picUrl;
            var desc = steps[i].desc;
            var byte20Len = steps[i].byte20.length;
            var hour,minute,second;
            if(byte20Len > 0){
				for(var j=0; j< byte20Len; j ++){
					if(steps[i].byte20[j].platform == subSn){
						order = steps[i].byte20[j].cmd[0].bytectrl;
						hour = steps[i].byte20[j].th;
                        if(hour == "undefined" || hour == undefined){
                            minute = steps[i].byte20[j].tm;
                        }else{
                            minute = steps[i].byte20[j].tm + hour*60;
                        }

						second = steps[i].byte20[j].ts;
					}
				}
            }
            insertElem(i,picUrl,desc,byte20Len,second,minute,hour);
        }
        function insertElem(stepId,imgSrc,stepTxt,byte20Len,second,minute,hour){
			formatNumberByZero = function(timeS){
				if(parseInt(timeS) < 10)
					return "0"+timeS;
				return timeS;
			};
            var element1 ="<div class='topImg'><img class='stepImg' data-src='' src='"+imgSrc +"'\/><\/div>";
            var element2 = "<div class='step_msg'><h3>步骤"+parseInt(stepId+1) +"<\/h3><div class='stepTxt'>"+stepTxt +"<\/div><\/div>";
            var element4 = "<div class='menuImg'><img src='./images/minioven.png' /></div>";
            var element5 = "<div class='menuTxt'>微波炉<br/><div class='timeShow' data-minu="+formatNumberByZero(minute)+" data-second="+formatNumberByZero(second)+"><span class='minuteTime'>"+ formatNumberByZero(minute) +"</span>分<span class='secondTime'>"+ formatNumberByZero(second)+"</span>秒</div></div>";
            var element6 = "<div class='menu' data-cmd="+order+"><span>启动自动菜单</span></div>";
            var element7 = "<div class='line'></div>";
            var element3 = " <div class='autoMenu'>"+element4 + element5 + element6 + element7 + "</div>";
            if(byte20Len > 0){
            	if(hour == "undefined" || hour == undefined){
            		swiperWrapper.innerHTML += "<div class='swiper-slide' id='step" + stepId + "'>"+ element1 + element2 +"<\/div>";
            	}else{
            		swiperWrapper.innerHTML += "<div class='swiper-slide' id='step" + stepId + "'>"+ element1 + element3 + element2 +"<\/div>";
            	}
                
            }else{
                swiperWrapper.innerHTML += "<div class='swiper-slide' id='step" + stepId + "'>"+ element1+element2 +"<\/div>";
            }

        }
    }
};
ingredient.mainIngredient();
ingredient.secondIngredient();
var ingredientEl = "<div class='swiper-slide' >"+IngredientImg+"<div class='step_msg'><div class='tit'>"+mainIngredientMsg+secondIngredientMsg+"</div></div></div>";
document.getElementsByClassName("swiper-wrapper")[0].innerHTML = titEl + ingredientEl;
step.setStep();

var menuTit = queryString();
document.getElementById("totalTime").innerText = time;
document.getElementById("B0_P03_TITLE").innerText = menuTit["menuTit"];
var touchMenu = function (){
    document.getElementsByClassName("menu")[0].addEventListener("touchstart",function(event){
        window.location.href = "runMenu.html?runMenuTit=" + menuTit["menuTit"];
    },false);
};
//启动自动菜单

//图片高度设置
var bodyH = document.body.clientHeight;
$(".topImg").css("height",bodyH*0.35);

 document.addEventListener("readystatechange",function(event){
 // alert(document.readyState);
 if(document.readyState == "interactive"){
		var mySwiper=new Swiper('.swiper-container',{
		    mode:'horizontal',
		    loop:false,
		    slidesPerViewFit:false,
		    pagination : '.pagination'
		});
        var workMenuId = window.sessionStorage.getItem("workMenuId");
        if(workMenuId !== "null"){
            workMenuId = parseInt(workMenuId)+2;
            //mySwiper.swipeTo(workMenuId);
        }
     /*
 var finishedPicUrl1 = results.finishedPicUrl[0].url; //完成图片(数组)
 var ingredientPicUrl1 = results.ingredientPicUrl[0].url; //配料图片(数组)
 var urlString = function(string){
 return string.substr(0,string.length - 4)+"_h.jpg";
 };

 document.getElementById("titImg").setAttribute("data-src",urlString(finishedPicUrl1));
 document.getElementById("ingredientPic").setAttribute("data-src",urlString(ingredientPicUrl1));
 document.getElementById("ingredientPic").src = document.getElementById("ingredientPic").getAttribute("data-src");
 document.getElementById("titImg").src = document.getElementById("titImg").getAttribute("data-src");
 for(var i=0;i < steps.length;i++ ){
 var picUrl1 =steps[i].picUrl;
 document.getElementsByClassName("stepImg")[i].setAttribute("data-src",urlString(picUrl1));
 document.getElementsByClassName("stepImg")[i].src = document.getElementsByClassName("stepImg")[i].getAttribute("data-src");
 }
 */

 var local_status = window.localStorage.getItem(deviceId+"_local_status");  //缓存
 showStatusByJson(JSON.parse(local_status));
 }

 },false);

//DataBase
/*
var dataBase = window.webkitIndexedDB;
var request,database;
request = dataBase.open("admin");
request.onsuccess = function(event){
    database = event.target.result;
    alert(database);
};
*/

//$(function(){
    $(document).on('pageinit', 'div[id="B0_P03"]', function (event) {

        $(document).bind('recieveMessage', {}, function (event, message) {
            showStatus("", message);
        });
        //var session_status = window.localStorage.getItem("local_status");
        //showStatusByJson(JSON.parse(session_status));
        setInterval("cmdRequestStatus()",20000); //轮询
    });
    $(document).on('pageshow', 'div[id="B0_P03"]', function (event) {
        $(".menu").bind('tap',{}, goToRunMenu);
        //$(".menu").on("tap",function(ev){
        //    goToRunMenu();
         //   ev.preventDefault();
        //});
        cmdRequestStatus();
        
    });

//});

goToRunMenu = function(){
    var stepId = $(this).parent().parent().attr("id");
    window.sessionStorage.setItem("stepId",stepId.substring(4,stepId.length));
    window.sessionStorage.setItem("menuId",params["menuId"]);
    window.sessionStorage.setItem("menuTit",params["menuTit"]);
	var cmdOrder = $(this).attr("data-cmd");
	var status = $(this).find("span").text();
    var minuteTime = $(this).prev(".menuTxt").find(".minuteTime").text();
    var secondTime = $(this).prev(".menuTxt").find(".secondTime").text();
	if(status == "烹饪中..."){
		window.location.href="runMenu.html?cookingTime="+minuteTime+secondTime;
	}else if(status == "暂停中..."){
		window.location.href="runMenu.html?cookingTime="+minuteTime+secondTime;
	} else if(status == "启动自动菜单"){
		var md =mdSmart.msg0xB0(); 
		md.setMenuFood(cmdOrder);
		md.setFunctioncheckSum();
		var cmdBytes =  md.cmdControlStatus();
		var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			var md =mdSmart.msg0xB0();
			window.localStorage.setItem(deviceId+"_local_status", JSON.stringify(md.parseMessageForView(messageBack)));  //缓存
			window.localStorage.setItem(deviceId+"_local_workMode",menuTit["menuTit"] );
			var currRecipe = {"list":[{"name":name,"picUrl":picUrl,"recipe":recipeId,"type":""}]};
			window.localStorage.setItem(deviceId+"_currRecipe", JSON.stringify(currRecipe));
			window.location.href="runMenu.html?cookingTime="+minuteTime+secondTime;
		});
	}

};
// 查询按钮
cmdRequestStatus = function () {
	var md =mdSmart.msg0xB0(); 
	var cmdBytes = md.cmdRequestStatus();
	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
		showStatus(cmdBytes, messageBack);
	});
};


//回显状态
showStatus = function (messageBackRequest, messageBackBack) {
	var md =mdSmart.msg0xB0();
	var jsonStatus = md.parseMessageForView(messageBackBack);
	showStatusByJson(jsonStatus);
};



showStatusByJson = function (messageBackBack) {
	
	var jsonStatus = messageBackBack;
	var workState = jsonStatus.status.workState.value;
	var errorCode = jsonStatus.status.errorCode.value;
	var DoorIsOpen = jsonStatus.status.DoorIsOpen.value;
	
	if(workState == 0x09){
		return;
	}
	if(workState < 0x01 || workState > 0x0c) //错误状态
			return;

	window.localStorage.setItem(deviceId+"_local_status", JSON.stringify(jsonStatus));  //缓存
	//初始化菜单项
	

	$(".menu").addClass("offRunMenu");
	$(".menu").unbind('tap');
	$(".menu span").text("启动自动菜单");
	$(".timeShow").each(function(){
		$(this).html("<span class='minuteTime'>"+$(this).attr("data-minu")+"</span>分<span class='secondTime'>" + $(this).attr("data-second") + "</span>秒");
	});
	
	if(errorCode != 0x00){//故障
		$(".timeShow").html("<span>E-0"+errorCode+"故障！</span>");
		return;
	}
	if(DoorIsOpen == 0x01){
		$(".timeShow").html("<span>炉门没关！</span>");
		return;
	}
	if(workState == 0x0a){
		$(".timeShow").html("<span>设备自检！</span>");
		return;
	}
	if(workState == 0x0c){
		$(".timeShow").html("<span>操作演示！</span>");
		return;
	}
	if(workState == 0x05){  //童锁
		$(".timeShow").html("<span>童锁中...</span>");
		return;
	}
	if(workState == 0x01){ //待机
		window.localStorage.setItem(deviceId+"_local_workMode", "null");
		$(".menu").removeClass("offRunMenu");
		$(".menu").bind('tap',{}, goToRunMenu);
	}else if(workState == 0x02){  //工作
		var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
		if(constant_workMode == menuTit["menuTit"]){  //自动菜单
			$(".menu").removeClass("offRunMenu");
			$(".menu").bind('tap',{}, goToRunMenu);
			$(".menu span").text("烹饪中...");
		}  else{
			$(".timeShow").html("<span>工作中...</span>");
		}
		
	} else if(workState == 0x03){  //暂停
		var constant_workMode = window.localStorage.getItem(deviceId+"_local_workMode");
		if(constant_workMode == menuTit["menuTit"]){  //自动菜单
			$(".menu").removeClass("offRunMenu");
			$(".menu").bind('tap',{}, goToRunMenu);
			$(".menu span").text("暂停中...");
		}  else{
			$(".timeShow").html("<span>暂停中...</span>");
		}
	} else if(workState == 0x04){  //结束
		$(".menu").removeClass("offRunMenu");
		$(".menu").bind('tap',{}, goToRunMenu);
	} else if(workState == 0x07){  //省电
		$(".timeShow").html("<span>省电中...</span>");
	} 
};