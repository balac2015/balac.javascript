var headH=document.querySelector(".topbg_01").offsetHeight;
var bodyH=document.body.clientHeight;
var content=document.querySelector(".content");
var deviceId = bridge.getCurrentApplianceID();
var three = true;
content.style.height=bodyH-headH+"px";
var stopH = document.getElementsByClassName("stop")[0].clientHeight;
 var touch = function(){
     document.getElementsByClassName("stop")[0].addEventListener("touchstart",function(event){
        var _this = document.getElementsByClassName("stop")[0];
         var txt = _this.innerHTML;
         if(txt == "暂停"){
             //alert(three);
             if(three){
                 _this.innerHTML = "开始";
                 setFunctionWorkStatePause();
             }

         }else{
             _this.innerHTML = "暂停";
			setFunctionWorkStateWork();
         }
     },false);
     //return document.getElementsByClassName("stop")[0];
 };
 touch();
//touch().style.lineHeight =stopH +"px";
//document.getElementsByClassName("cancle")[0].style.lineHeight =stopH +"px";

$("#BACK").on("tap",{},function(ev){
    window.sessionStorage.setItem("workMenuId",window.sessionStorage.getItem("stepId"));
	location.href = "cookstep.html?menuId="+window.sessionStorage.getItem("menuId")+"&menuTit="+window.sessionStorage.getItem("menuTit");
    ev.preventDefault();
});
document.getElementById("B0_P03_TITLE").innerText = window.localStorage.getItem(deviceId+"_local_workMode");


//$(function(){
    $(document).on('pageinit', 'div[id="B0_P03"]', function (event) {
        $(document).bind('recieveMessage', {}, function (event, message) {
           // alert(JSON.stringify(message));
            showStatus("", message);
        });

    });
    $(document).on('pageshow', 'div[id="B0_P03"]', function (event) {
        $(".cancle").bind('tap', {}, setFunctionWorkStateStandby);
    });

//});


// 查询按钮
cmdRequestStatus = function () {
	var md =mdSmart.msg0xB0(); 
	var cmdBytes = md.cmdRequestStatus();
	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
		showStatus(cmdBytes, messageBack);
	});
};
document.addEventListener("readystatechange",function(event){
   // alert(document.readyState);
    if(document.readyState == "interactive"){
        var params = queryString();
        var menuTime = params["cookingTime"];
        if(menuTime != null){
            $("#minuteTime").text(menuTime.substring(0,2));
            $("#secondTime").text(menuTime.substring(2,4));
        }

		var local_status = window.localStorage.getItem(deviceId+"_local_status");  //缓存
		showStatusByJson(JSON.parse(local_status));
		cmdRequestStatus();
		setInterval("cmdRequestStatus()",20000); //轮询
    }

},false);
//回显状态
showStatus = function (messageBackRequest, messageBackBack) {
	var md =mdSmart.msg0xB0();
	var jsonStatus = md.parseMessageForView(messageBackBack);
	showStatusByJson(jsonStatus);
};

showStatusByJson = function (messageBackBack) {
	window.clearInterval(formatSecondsFunctionDown1);
	var jsonStatus = messageBackBack;
	var workState = jsonStatus.status.workState.value;
	var errorCode = jsonStatus.status.errorCode.value;
	var DoorIsOpen = jsonStatus.status.DoorIsOpen.value;
	var surplusTimeMinute = jsonStatus.status.surplusTimeMinute.value;
	var surplusTimeSeconds = jsonStatus.status.surplusTimeSeconds.value;
    window.localStorage.setItem(deviceId+"_local_status",JSON.stringify(jsonStatus));
	//alert(surplusTimeMinute + "-" + surplusTimeSeconds);
	if(errorCode != 0x00 && errorCode!=undefined){//故障
        $("#iOSdialogBoxLockScreen").remove();
        $(".inCirBg").removeClass("on");
        $("#iOSdialogBoxWindow").remove();
        $(this).iOSdialogBoxAlert({
            'title'   : "E-0"+errorCode+"故障！" ,
            'message' : '请尽快联系售后人员维修' ,
            'button' : '确定'
        },timeOut1);
        function timeOut1(returnData){
            location.href = "cookstep.html?menuId="+window.sessionStorage.getItem("menuId")+"&menuTit="+window.sessionStorage.getItem("menuTit");
            window.sessionStorage.setItem("workMenuId",window.sessionStorage.getItem("stepId"));
        }
        return;
    } else{
        $("#iOSdialogBoxLockScreen").remove();
    }
	if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
		$("#B0_P03_TimeMinShow").text("00");
		$("#B0_P03_TimeSecShow").text("00");
	}
    $(".stop").text("开始");
    $(".inCirBg").removeClass("on");
    //alert(workState);
	if(workState == 0x09){
        three = false;
        $(".stop").text("暂停");
        setTimeout("cmdRequestStatus()",4000); //轮询
        /*
        $(".inCirBg").addClass("on");
        if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
            $("#B0_P03_TimeMinShow").text("00");
            $("#B0_P03_TimeSecShow").text("00");
        }else{
            formatSecondsDownRunOnlyOneTime(surplusTimeMinute, surplusTimeSeconds);
            formatSecondsDownF(surplusTimeMinute, surplusTimeSeconds);
        }
        */
	}else{
        three = true;
    }
	window.localStorage.setItem(deviceId+"_local_status", JSON.stringify(jsonStatus));  //缓存
	//初始化菜单项

	if(errorCode != 0x00){//故障
		return;
	}
	if(DoorIsOpen == 0x01){
		$("#iOSdialogBoxLockScreen").remove();
		$("#iOSdialogBoxWindow").remove();
		$(this).iOSdialogBoxAlert({
			'title'   : "炉门没关！" ,
			'message' : '请确保炉门关紧' ,
			'button' : '确定'
		},error1);
		function error1(returnData){
			bridge.goBack();
		}
		return;
	}else{
        $("#iOSdialogBoxLockScreen").remove();
		$("#iOSdialogBoxWindow").remove();
    }

	if(workState == 0x01){ //待机
        three = true;
		window.localStorage.setItem(deviceId+"_local_workMode","null");
		window.sessionStorage.setItem("workMenuId",window.sessionStorage.getItem("stepId"));
		location.href = "cookstep.html?menuId="+window.sessionStorage.getItem("menuId")+"&menuTit="+window.sessionStorage.getItem("menuTit");
	}else if(workState == 0x02){  //工作
        three = true;
		$(".stop").text("暂停");
		$(".inCirBg").addClass("on");
		if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
			$("#B0_P03_TimeMinShow").text("00");
			$("#B0_P03_TimeSecShow").text("00");
		}else{
			formatSecondsDownRunOnlyOneTime(surplusTimeMinute, surplusTimeSeconds);
			formatSecondsDownF(surplusTimeMinute, surplusTimeSeconds);
		}
	} else if(workState == 0x03){  //暂停
        three = true;
		if(surplusTimeMinute == 0 && surplusTimeSeconds == 0){
			$("#B0_P03_TimeMinShow").text("00");
			$("#B0_P03_TimeSecShow").text("00");
		}else{
			formatSecondsDownRunOnlyOneTime(surplusTimeMinute, surplusTimeSeconds);
		}
	} else if(workState == 0x04){  //结束
		window.sessionStorage.setItem("workMenuId",window.sessionStorage.getItem("stepId"));
		location.href = "cookstep.html?menuId="+window.sessionStorage.getItem("menuId")+"&menuTit="+window.sessionStorage.getItem("menuTit");
	} else if(workState == 0x05){  //童锁
	} else if(workState == 0x07){  //省电
        three = true;
		window.sessionStorage.setItem("workMenuId",window.sessionStorage.getItem("stepId"));
		location.href = "cookstep.html?menuId="+window.sessionStorage.getItem("menuId")+"&menuTit="+window.sessionStorage.getItem("menuTit");
	} 
};


formatSecondsFunctionDown1 = 0;
formatSecondsDownF = function(minutes, seconds){
	var int_T = parseInt(minutes)*60 + parseInt(seconds);
	formatSecondsFunctionDown1 = window.setInterval(
		function (){
			var theTime = parseInt(int_T);// 秒
			var theTime1 = 0;// 分
			if(theTime >= 60) {
				theTime1 = parseInt(theTime/60);
				theTime = parseInt(theTime%60);
			}
			//var result = parseInt(theTime1)+":"+mdSmart.common.formatNumberByZero(theTime,2);
			if(int_T <= 0){
				// mdSmart.B0_P01.Close();
				window.clearInterval(formatSecondsFunctionDown1);
				//$("#B0_P01_LBL_SURPLUSTIME").html("0:00");
				$("#minuteTime").text("00");
				$("#secondTime").text("00");
			}else{
				$("#minuteTime").text(mdSmart.common.formatNumberByZero(theTime1,2));
				$("#secondTime").text(mdSmart.common.formatNumberByZero(theTime,2));
				int_T--;
			}
		}, 1000);
};
formatSecondsDownRunOnlyOneTime = function(minutes, seconds){
	var int_T = parseInt(minutes)*60 + parseInt(seconds);
	var theTime = parseInt(int_T);// 秒
	var theTime1 = 0;// 分
	if(theTime >= 60) {
		theTime1 = parseInt(theTime/60);
		theTime = parseInt(theTime%60);
	}
	//var result = parseInt(theTime1)+":"+mdSmart.common.formatNumberByZero(theTime,2);
	if(int_T <= 0){
		// mdSmart.B0_P03.Close();
	}else{
		$("#minuteTime").text(mdSmart.common.formatNumberByZero(theTime1,2));
		$("#secondTime").text(mdSmart.common.formatNumberByZero(theTime,2));
	}
};

// 工作状态--工作
setFunctionWorkStateWork = function () {
	var md =mdSmart.msg0xB0();
	md.setFunctionWorkStateWork();
	md.setFunctioncheckSum();
	var cmdBytes = md.cmdControlStatus();
	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
		showStatus(cmdBytes, messageBack);
	});
};

// 工作状态--暂停
setFunctionWorkStatePause = function () {
	var md =mdSmart.msg0xB0();
	md.setFunctionWorkStatePause();
	md.setFunctioncheckSum();
	var cmdBytes = md.cmdControlStatus();
	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
		showStatus(cmdBytes, messageBack);
	});
};

// 工作状态--取消
setFunctionWorkStateStandby = function () {
	var md =mdSmart.msg0xB0();
	md.setFunctionWorkStateStandby();
	md.setFunctioncheckSum();
	var cmdBytes = md.cmdControlStatus();
	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
		showStatus(cmdBytes, messageBack);
	});
};