var testJson= testJson || {};
var params = queryString();
var menuId = params["menuId"];
var title = params["menuTit"];
bridge.showProgress();
var deviceId = bridge.getCurrentApplianceID();
var tokenTmp = window.localStorage.getItem("token");
if(tokenTmp == null || tokenTmp == "null"){
	getPwd();
} else {
	getPlatform(tokenTmp);
}

//获取列表详情
function getRecipeDetail(recipeId, token){
	var data = JSON.parse(token);
	var str1 = {
		"fun" : "recipeDetail",  
		"recipe" : recipeId,
		"pwd" : data.pwd+"",
		"uid" : "10486",
	};
	$.ajax({
		type : "post",
		url : "http://"+data.server+":"+data.port+data.preUrl+"recipe",
		dataType : 'json',					
		async : false,
		headers:{
			"sessionID": data.sessionID+""
		},
		data:{"nopwd":"true","debug":true,"data":JSON.stringify(str1)},
		success : function(res){	
			bridge.closeProgress();
			testJson.cookStep = res;

		} ,
		error:function(datr){
			var functionParamers = {
				   title : '提示',
				   message : '网络不给力...',
				   btnText : '确定'
			};

		    bridge.showAlert(functionParamers);
			bridge.closeProgress();
			bridge.goBack();
		}
	});
}

//1.获取动态码代码
function getPwd() {
	var _jsonData = {
	"uid" : "10486", //uid先写着“10486”
	"fun" : "getPwd"
	};
	var str=encrypt4Pwd(JSON.stringify(_jsonData));
	$.ajax({
		type : "post",
		url : "http://iot3.midea.com.cn:8787/nutrition/v11/base2pro/data/transmit?data="+str,
		dataType : 'json',
		async : false,
		success : function(res){
			var obj = eval(res);
			var token = decrypt4Pwd(obj.data);
			getRecipeDetail(menuId, token);
			
		}
	});
}

//2，加密方法
function encrypt4Pwd(str){
	var keyHex = CryptoJS.enc.Utf8.parse("guoqnlyq");
	var encrypted = CryptoJS.DES.encrypt(str, keyHex, {
							  mode: 		CryptoJS.mode.ECB,
							  padding: 		CryptoJS.pad.Pkcs7
							  });
	 var unicode = CryptoJS.enc.Base64.parse(encrypted.toString()).toString();
	 var  str = '';
	 for(var i = 0 ; i < unicode.length/2;++i){
		 var temp =parseInt (unicode.substr(i*2,2), 16);
		 if(temp>128)
		 {
			temp=temp-256;
		 }

		 if(i!=unicode.length/2-1)
		 {
			str+=temp.toString(32)+',';
		 }else{
			str+=temp.toString(32);
		 }
	}
	return str;
}


//3，解密方法
function decrypt4Pwd(str){
	var array = str.split(",");
	var returnStr = '';
	for (var i=0 ; i< array.length ; i++)
	{
		var temp;
		if(array[i].substr(0,1)=="-")
		{
			temp = (256-parseInt(array[i].substr(1,2),16)).toString(16);
		}else{
			if(parseInt(array[i],16)<16){
				temp = "0"+parseInt(array[i],16).toString(16);
			}else{
				temp = parseInt(array[i],16).toString(16);
			}
		}
		returnStr+=temp;
	}
	var encryptedHexStr = CryptoJS.enc.Hex.parse(returnStr);
	var encryptedBase64Str = CryptoJS.enc.Base64.stringify(encryptedHexStr);
	var keyHex = CryptoJS.enc.Utf8.parse("lyqguoqn");
	var decrypted = CryptoJS.DES.decrypt({
										  ciphertext:CryptoJS.enc.Base64.parse(encryptedBase64Str)
										  }, keyHex, {
										  mode: CryptoJS.mode.ECB,
										  padding: CryptoJS.pad.Pkcs7
										  });  
	returnStr = decrypted.toString(CryptoJS.enc.Utf8);
	return returnStr;
 }

 //sn
 function getPlatform(token) {
    var data = JSON.parse(token);
    var str = {
        "fun": "snQuery",
        "applianceId": deviceId,
        "pwd": data.pwd + "",
        "uid": "10486"
    };
    //if(sessionPlatform==null || sessionPlatform=="null" || sessionPlatform=="undefined"){
        $.ajax({
            type: "post",
            url: "http://" + data.server + ":" + data.port + data.preUrl + "sn",
            dataType: 'json',
            async: false,
            headers: {
                "sessionID": data.sessionID + ""
            },
            data: {"nopwd": "true", "debug": true, "data": JSON.stringify(str)},
            success: function (sn) {
                //alert(JSON.stringify(sn));
                var Sn = sn.platform;
                if(Sn !=null || Sn !=undefined){
                    window.localStorage.setItem(deviceId+"_B2_Sn",JSON.stringify(Sn));
                    getRecipeDetail(menuId, token);
                }else{
                    window.localStorage.setItem(deviceId+"_B2_Sn","0000");
                    getRecipeDetail(menuId, token);
                   // getRecipe(data,"0000");
                }
            },
            error:function(er){
                //alert(er);
            }
        });

    //}else{
     //   getRecipe(data,sessionPlatform);
    //}

}
 //testJson.cookStep = {"desc":"美味可口的小点心","devicetypes":"2","devs":"","easy":"1","effect":[{"item":"营养\r\n低糖"}],"finishedPicUrl":[{"url":"http://121.41.75.163:8000/source/image/20150117/1421486759290e87g.jpg"}],"id":"b07e628dde12466da71d291201f38962","ingredientPicUrl":[{"url":"http://121.41.75.163:8000/source/image/20150117/1421486759621cuxx.jpg"}],"ingredients":[{"name":"鸡蛋","weight":"2个"},{"name":"水","weight":"100g"},{"name":"淡奶油或果酱","weight":"适量"}],"mainingredients":[{"name":"黄油","weight":"50g"},{"name":"低筋面粉","weight":"50g"}],"marks":"美味","name":"天鹅泡芙","oil":"6","picurl":"http://121.41.75.163:8000/source/image/20150117/1421486759290e87g.jpg","platforms":"2001","recorded":"yes","recorded_people":34,"steps":[{"byte20":[],"desc":"黄油切小块，加入水，用微波高火加热至沸腾","id":"7231e8c1d24d4593854d87247c0e01d2","order":1,"picUrl":"http://121.41.75.163:8000/source/image/20150117/142148675989815j9.jpg"},{"byte20":[],"desc":"加入过筛的面粉，边加边搅拌，搅拌均匀，再用微波小火加热至黏糊状","id":"1f581595622644298fd0824e14ca73bc","order":2,"picUrl":"http://121.41.75.163:8000/source/image/20150117/1421486760179t0vp.jpg"},{"byte20":[],"desc":"凉到60℃，分次加入蛋液，搅拌均匀（呈倒三角状即可）","id":"2f2610221d114350b4bcf01decbe995e","order":3,"picUrl":"http://121.41.75.163:8000/source/image/20150117/1421486760454b8vr.jpg"},{"byte20":[{"cmd":[{"aftmsg":"1","befmsg":"1","bytectrl":"AA13B40000000000000202010002DC1100000243","fgaftmsg":0,"fgbefmsg":0,"h":0,"m":2,"s":0,"seq":1,"trig":"1"}],"devicetype":"2","platform":"2001","segments":1,"th":0,"tm":2,"ts":0}],"desc":"装入一次性裱花袋，剪一个小口，在烤盘上分别挤上正2或反2；烤箱预热 220℃，烤制2min，待膨胀和上色即可","id":"30d90af782b6460586a2b3844d817d6f","order":4,"picUrl":"http://121.41.75.163:8000/source/image/20150117/14214867607197oss.jpg"},{"byte20":[],"desc":"再挤些椭圆形面团","id":"05b78456ceab47a78ee90f9555661a3c","order":5,"picUrl":"http://121.41.75.163:8000/source/image/20150117/1421486760994yst7.jpg"},{"byte20":[],"desc":"入预热好的烤箱，220℃烤15-20min，膨胀、表面金黄色即可取出、放凉","id":"90a34a9c245842c59e4a81f69ce00018","order":6,"picUrl":"http://121.41.75.163:8000/source/image/20150117/1421486761279jqv7.jpg"},{"byte20":[],"desc":"用剪刀剪掉椭圆形泡芙的上面一般，然后再剪成两半形成翅膀。泡芙下面一半填上打发的淡奶油或果酱，再插上天鹅头和翅膀","id":"72e747492a7f49b3a798cbcdfc1fe27e","order":7,"picUrl":"http://121.41.75.163:8000/source/image/20150117/1421486759290e87g.jpg"}],"time":"90","tips":"黄油一定要沸腾","weight":"0"};





