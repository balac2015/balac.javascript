var mdSmart = mdSmart || {};
/*
 * 微波炉通信协议
 * @doc 20140620网络设备与通用控制模块之间的串口协议（厨电类）.docx
 */
mdSmart.msg0xB0 = function(){
	var _messageBodyFunctionSelect = undefined;
	var _responseBack  = undefined;
	var _status = {
		workState:{name:"工作状态",value:0x00,view:{0x01:"待机",0x02:"工作",0x03:"暂停",0x04:"结束",0x51:"童锁",0x06:"预约",0x07:"省电",0x08:"预热"}},
	    DoorIsOpen:{name:"开门",value:0x00,view:{0:"关门",1:"开门"}},
		workMode:{name:"工作模式",value:0x00,view:{0x01:"解冻",0x02:"保温",0x03:"蒸鱼",0x04:"蒸肉",0x05:"蒸水蛋",0x06:"蒸海鲜",0x07:"清洁",0x08:"蒸汽",0x09:"蒸红薯",0x0A:"蒸米饭",0x0B:"蒸菜单7",0x0C:"蒸菜单8",0x0D:"发酵",0x0E:"翻热",0x0F:"清水垢",0x10:"消毒"}},
		surplusTimeHour:{name:"剩余时间小时",value:0x00},
		surplusTimeMinute:{name:"剩余时间分",value:0x00},
		surplusTimeSeconds:{name:"剩余时间秒",value:0x00},
		temperature:{name:"实际温度",value:0x00,view:{0x01:"100°C",0x02:"200°C",0x03:"300°C",0x04:"400°C",0x05:"500°C",0x06:"600°C",0x08:"700°C",0x09:"800°C",0x0A:"900°C",0x0B:"910°C",0x0C:"920°C"}},
	    errorCode:{name:"故障代码",value:0x00,view:{0x00:"正常",0x01:"炉腔传感器开路",0x02:"炉腔传感器短路",0x03:"蒸汽传感器开路",0x04:"蒸汽传感器短路"}},
		warningCode00:{name:"提醒代码00",value:0x00},//文档没有给出具体提醒内容的code码
		warningCode01:{name:"提醒代码01",value:0x00},//文档没有给出具体提醒内容的code码
		warningCode03:{name:"提醒代码03",value:0x00},//文档没有给出具体提醒内容的code码
		maintenance:{name:"维护保养",value:0x00},//文档没有给出具体维修内容的code码
		powerConsumption:{name:"耗电量",value:0x00},
		usingTimeLong:{name:"使用时长",value:0x00},
		currentCookingNumber:{name:"当前烹调段数",value:0x00},
		checkSum:{name:"检验和",value:0x00}
	};
	(function init(){
		//消息体(功能选择-请求)
		_messageBodyFunctionSelect = mdSmart.message.createMessageBody(11);
		
	}());
	function _parseMessage(pReceiveMessage){
		var receiveMessageBody = pReceiveMessage.slice(10,pReceiveMessage.length - 1);
		var messageType = mdSmart.message.getByte(pReceiveMessage,9);
		//据最新文档，控制(0x02)，查询(0x03)，运行参数上报(0x04)，设备异常主动上报(0x06)，异常信息上报(0x0a)均对应统一消息体
		if (0x02 == messageType || 0x03 == messageType || 0x04 == messageType || 0x06 == messageType ||0x0a == messageType)
		{
		    _responseBack=pReceiveMessage;
			_parseRequestStatusBackToStatus(receiveMessageBody);
			_doSynchronousRequestStatusBackToCmd();
		}
		var result = {
			messageType:messageType,
			status:_status
		};
		return result;
	}
	// 状态查询-回复==>_status
	function _parseRequestStatusBackToStatus(pReceiveMessageBody){
		_status.workState.value = mdSmart.message.getByte(pReceiveMessageBody,0);
		_status.DoorIsOpen.value = mdSmart.message.getBit(pReceiveMessageBody,0,7);
		_status.workMode.value = mdSmart.message.getByte(pReceiveMessageBody,1);
		_status.surplusTimeHour.value = mdSmart.message.getByte(pReceiveMessageBody,2);
		_status.surplusTimeMinute.value = mdSmart.message.getByte(pReceiveMessageBody,3);
		_status.surplusTimeSeconds.value = mdSmart.message.getByte(pReceiveMessageBody,9);
		_status.temperature.value = mdSmart.message.getByte(pReceiveMessageBody,4);
		_status.errorCode.value = mdSmart.message.getByte(pReceiveMessageBody,5);
		_status.warningCode00.value = mdSmart.message.getBits(pReceiveMessageBody,6,0,0);
		_status.warningCode01.value = mdSmart.message.getBits(pReceiveMessageBody,6,1,1);
		_status.warningCode03.value = mdSmart.message.getBits(pReceiveMessageBody,6,3,3);
		_status.maintenance.value = mdSmart.message.getByte(pReceiveMessageBody,7);
		_status.powerConsumption.value = mdSmart.message.getByte(pReceiveMessageBody,8);
		_status.usingTimeLong.value = mdSmart.message.getByte(pReceiveMessageBody,9);
		_status.currentCookingNumber.value = mdSmart.message.getByte(pReceiveMessageBody,10);
		_status.checkSum.value = mdSmart.message.getByte(pReceiveMessageBody,11);
	}
	
	function _doSynchronousRequestStatusBackToCmd(){
		//0		工作状态	
		mdSmart.message.setByte(_messageBodyFunctionSelect,0,_status.DoorIsOpen.value<<8|_status.workState.value);
		//1		工作模式
		mdSmart.message.setByte(_messageBodyFunctionSelect,1,_status.workMode.value);
		//4		当前烹调段数
		mdSmart.message.setByte(_messageBodyFunctionSelect,6,_status.currentCookingNumber.value);
	}
	function _getCheckCode(pBytes){
		var sumBytes = 0;
		for(var i=0;i<pBytes.length - 1;i++){
			sumBytes = sumBytes + pBytes[i];
		}
		return ((~sumBytes) + 1) & 0xFF;
	}
	return{
		/**
		 * 生成查询-请求命令
		 *
		 *@return {byteArray} 预约状态查询-请求
		 */
		cmdRequestStatus:function(){
			var messageBody = mdSmart.message.createMessageBody(11);
			messageBody[11] = _getCheckCode(messageBody);
		    var message = mdSmart.message.createMessage(0xB2,0x03,messageBody);
			return message;
		},
		/**
		 * 生成控制-请求命令
		 *
		 *@return {byteArray} 控制-请求
		 */
		cmdControlStatus:function(){
			_messageBodyFunctionSelect[11] = _getCheckCode(_messageBodyFunctionSelect);
			var message = mdSmart.message.createMessage(0xB2,0x02,_messageBodyFunctionSelect);
			return message;
		},
		
		/**
		 * 菜谱指令工作
		 */
		setMenuFood:function(order){
			var workM = parseInt(order.substring(22,24),16);
			var hourP = parseInt(order.substring(24,26),16);
			var secondP = parseInt(order.substring(26,28),16);
			var workP = parseInt(order.substring(28,30),16);
            var workStep =parseInt(order.substring(30,32),16);
            var netRecipce1 = parseInt(order.substring(40,42),16);
            var netRecipce2 = parseInt(order.substring(42,44),16);
            var netRecipce3 = parseInt(order.substring(44,46),16);
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,workM);
			mdSmart.message.setByte(_messageBodyFunctionSelect,2,hourP);
			mdSmart.message.setByte(_messageBodyFunctionSelect,3,secondP);
			mdSmart.message.setByte(_messageBodyFunctionSelect,4,workP);
            mdSmart.message.setByte(_messageBodyFunctionSelect,5,workStep);
            mdSmart.message.setByte(_messageBodyFunctionSelect,10,netRecipce1);
            mdSmart.message.setByte(_messageBodyFunctionSelect,11,netRecipce2);
            mdSmart.message.setByte(_messageBodyFunctionSelect,12,netRecipce3);

		},
		
		/**
		 * 工作状态-待机
		 */
		setFunctionWorkStateStandby:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x01);
		},
		/**
		 * 工作状态-工作
		 */
		setFunctionWorkStateWork:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
		},
		/**
		 * 工作状态-结束
		 */
		setFunctionWorkStateOver:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x04);
		},
		/**
		 * 工作状态-暂停
		 */
		setFunctionWorkStatePause:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x03);
		},
		/**
		 * 工作状态-童锁
		 */
		setFunctionWorkStateLock:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x51);
			
		},
		/**
		 * 工作状态-解锁
		 */
		setFunctionWorkStateUnLock:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x11);
		},
		/**
		 * 工作状态-预约
		 */
		setFunctionWorkStateReserve:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x06);
		},
		/**
		 * 工作状态-省电
		 */
		setFunctionWorkStateEnergySaving:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x07);
		},
		/**
		 * 工作状态-预热
		 */
		setFunctionWorkStatePreheat:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x08);
		},
		/**
		 * 工作模式
		 */
		/**
		 * 工作模式-菜单1（蒸鱼） ==> 菜单：蒸鱼
		 */
		setFunctionWorkModeMenu01:function(){
			console.log('star menu01');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x03);
		},
		/**
		 * 工作模式-菜单2（排骨）==> 菜单：蒸肉
		 */
		setFunctionWorkModeMenu02:function(){
			console.log('star menu02');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x04);
		},
		/**
		 * 工作模式-菜单3（蔬菜） ==> 菜单：蒸水蛋
		 */
		setFunctionWorkModeMenu03:function(){
			console.log('star menu03');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x05);
		},
		/**
		 * 工作模式-菜单4（米饭）==>菜单：蒸海鲜
		 */
		setFunctionWorkModeMenu04:function(){
			console.log('star menu04');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x06);
		},
		/**
		 * 工作模式-菜单5 ==>菜单：蒸杂粮
		 */
		setFunctionWorkModeMenu05:function(){
			console.log('star menu05');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x09);
		},
		/**
		 * 工作模式-菜单6 ==>菜单：蒸米饭
		 */
		setFunctionWorkModeMenu06:function(){
			console.log('star menu06');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x0A);
		},
		/**
		 * 工作模式-菜单7
		 */
		setFunctionWorkModeMenu07:function(){
			console.log('star menu07');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x0B);
		},
		/**
		 * 工作模式-菜单8
		 */
		setFunctionWorkModeMenu08:function(){
			console.log('star menu08');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x0C);
		},
		/**
		 * 工作模式-菜单9 ==>菜单：发酵
		 */
		setFunctionWorkModeMenu09:function(){
			console.log('star menu09');
			mdSmart.message.setByte(_messageBodyFunctionSelect,0,0x02);
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x0D);
		},
		/**
		 * 工作模式-自动菜单
		 */
		setFunctionWorkModeAutomaticMenu:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x03);
		},
		/**
		 * 工作模式-解冻
		 */
		setFunctionWorkModeThaw:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x04);
		},
		/**
		 * 工作模式-热风对流
		 */
		setFunctionWorkModeHotAirConvection:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x05);
		},
		/**
		 * 工作模式-高温蒸汽
		 */
		setFunctionWorkModeHighTemperatureSteam:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x06);
		},
		/**
		 * 工作模式-感应菜单
		 */
		setFunctionWorkModeInductionMenu:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x07);
		},
		/**
		 * 工作模式-快捷加热
		 */
		setFunctionWorkModeInductionMenu:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x08);
		},
		/**
		 * 工作模式-微波蒸汽
		 */
		setFunctionWorkModeInductionMenu:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,1,0x09);
		},
		/**
		 * 工作时间：分
		 */
		setFunctionWorkTimeMinute:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,2,pValue&0xff);
		},
		/**
		 * 工作时间：秒
		 */
		setFunctionWorkTimeSeconds:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,3,pValue&0xff);
		},
		/**
		 * 工作模式参数1
		 */
		setFunctionSetWorkParameters1:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,4,pValue&0xff);
		},
		/**
		 * 工作模式参数2
		 */
		setFunctionSetWorkParameters2:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,5,pValue&0xff);
		},
		/**
		 * 总烹饪段数
		 */
		setFunctionTotalCookingNumber:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,6,pValue<<4|(mdSmart.message.getByte(_messageBodyFunctionSelect,6)&0x0f));
		},
		/**
		 * 当前烹饪段
		 */
		setFunctionCurrentCookingNumber:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,6,pValue|(mdSmart.message.getByte(_messageBodyFunctionSelect,6)&0xf0));
		},
		/**
		 * 预约时间：小时
		 */
		setFunctionBookedTimeHour:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,7,pValue&0xff);
		},
		/**
		 * 预约时间：分钟
		 */
		setFunctionBookedTimeMinute:function(pValue){
			mdSmart.message.setByte(_messageBodyFunctionSelect,8,pValue&0xff);
		},
		
		/**
		 * 下一段烹调操作-无须干预
		 */
		setFunctionBarbecueWithoutIntervention:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,9,0x00);
		},
		/**
		 * 下一段烹调操作-无操作自动开始
		 */
		setFunctionBarbecueAutoStart:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,9,0x01);
		},
		/**
		 * 下一段烹调操作-需按键开始
		 */
		setFunctionKeyStart:function(){
			mdSmart.message.setByte(_messageBodyFunctionSelect,9,0x02);
		},
		/**
		 * 检验和
		 */
		setFunctioncheckSum:function(){
		    var _messageBodyFunctionSelectTmp=_messageBodyFunctionSelect;
			_messageBodyFunctionSelectTmp.pop();
			mdSmart.message.setByte(_messageBodyFunctionSelect,10,((~eval(_messageBodyFunctionSelectTmp.join("+")))+1)&0xff);
		},
		/**
		 * 解析报文
		 *@param {byteArray} message 报文
		 *@return {json}
		 */
		parseMessageForView:function(message){
			return _parseMessage(message);
		},
		//状态查询-回复
		getResponseBack:function(){
			return _responseBack;
		}
	}
}