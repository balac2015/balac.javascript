var allTime = 0;
var deviceId = bridge.getCurrentApplianceID();
(function (mdSmart) {
    var bDebug = false;
    var msgBB;
    mdSmart.B0_P01 = mdSmart.B0_P01 || {};
	mdSmart.B0_COM = mdSmart.B0_COM || {};

	mdSmart.B0_P01.childLockStatus = false; //童锁状态
	mdSmart.B0_P01.workStatus = false; //工作状态

    $(document).on('pageinit', 'div[id="B0_P01"]', function (event) {
        console.log('#B0_P01 pageinit.');
		mdSmart.B0_P01.message = mdSmart.B0_COM.message = mdSmart.B0_COM.message == undefined?(new mdSmart.msg0xB0()):mdSmart.B0_COM.message;
        
		$(document).bind('recieveMessage', {}, function (event, message) {
            mdSmart.B0_P01.showStatus("", message);
        });

		setInterval("mdSmart.B0_P01.cmdRequestStatus()",20000); //轮询
    });

    $(document).on('pageshow', 'div[id="B0_P01"]', function (event) {
        console.log('#B0_P01 pageshow.');
        $('#B0_P01_PowerOff').removeClass("clearBg").html('关机');
		//多语言画面文言绑定
		mdSmart.B0_P01.pageTextInit();
        mdSmart.B0_P01.prepareAndShow();
		//工作状态按钮绑定事件
        $("#B0_P01_Pause").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_Pause);
		$("#B0_P01_StartWork").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_Start);
		$("#B0_P01_Cancel").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_Cancel);
       $("#B0_P01_CancelWork").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_CancelWork);
		$("#B0_P01_Working_Cancel").bind('tap', {}, mdSmart.B0_P01.eventB0_Working_Cancel);
		$("#B0_P01_EndConfirm").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_EndConfirm);
		$("#B0_P01_ChildLock").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_ChildLock);
		$("#B0_P01_ChildUnLock").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_ChildUnLock);
		$("#B0_P01_PowerOff").bind('tap', {}, mdSmart.B0_P01.eventPowerOff);
		$(".goto-panel-mask").bind('tap', {}, mdSmart.B0_P01.gotoControlPanelPage); //
//		$("#B0_P02").bind('tap', {}, mdSmart.B0_P01.gotoControlPanelPage); //
		$("#B0_P01_BTN_OpenPower").bind('tap', {}, mdSmart.B0_P01.eventB0_P01_OpenPower);
    });

    $(document).on('pagehide', 'div[id="B0_P01"]', function (event) {
        console.log('#B0_P01 pagehide.');
        //取消绑定事件
		$("#B0_P01_BTN04").unbind('tap');
		$("#B0_P01_BTN05").unbind('tap');
		$("#B0_P01_BTN06").unbind('tap');
		
		$("#B0_P01_StartWork").removeClass("ricecooker_02_waiting");
		$("#B0_P01_Pause").removeClass("ricecooker_02_waiting");
		$("#B0_P01_CancelConfirm").removeClass("ricecooker_04_waiting");
		mdSmart.common.isCartBtnLockControl(false);
    });
    mdSmart.B0_P01.pageTextInit=function(){
	    console.log("mdSmart.B0_P01.pageTextInit");
		$("#B0_P01_LBL_SURPLUSTIME_HEADER").html(mdSmart.i18n.TIME_LEFT);//剩余时间
		$("#B0_P01_TEXT_MINUTES").html(mdSmart.i18n.MINUTE);//分
		$("#B0_P01_TEXT_SECOND").html(mdSmart.i18n.SECOND);//秒
	    //$("#B0_P01_Pause").html(mdSmart.i18n.PAUSE_FUNCTION);//暂停
		//$("#B0_P01_StartWork").html(mdSmart.i18n.START_FUNCTION);//开始
		$("#B0_P01_Cancel").html(mdSmart.i18n.CANCEL_FUNCTION);//取消
		$("#B0_P01_CancelConfirm").html(mdSmart.i18n.CONFIRM_CANCEL);//确认取消
		//$("#B0_P01_ChildLock").html(mdSmart.i18n.CHILDLOCK_FUNCTION);//童锁
		
		$("#B0_P01_LBL_SURPLUSTIME_HEADER").html(mdSmart.i18n.TIME_LEFT);
		$("#B0_P01_TITLE").html(mdSmart.i18n.BITTER_MELON_SPARERIBS);
		// $("#B0_P01_APP_NAME").html(mdSmart.i18n.APP_NAME);
		// $("#B0_P01_TITLE").html(mdSmart.i18n.BITTER_MELON_SPARERIBS);
		// $("#B0_P01_TITLE").html(mdSmart.i18n.BITTER_MELON_SPARERIBS);
	};
    mdSmart.B0_P01.prepareAndShow = function () {
        console.log("mdSmart.B0_P01.prepareAndShow");
		mdSmart.B0_P01.cmdRequestStatus();
        bridge.getCardTitle(function(message){
			$(".title").text(message);
		});
        // For Debug
        if (bDebug == true) {
            var title = JSON.stringify({
                messageBody: mdSmart.i18n.APP_NAME
            });
            bridge.setCardTitle(title);
        }
    };
	// 控制面板
    mdSmart.B0_P01.gotoControlPanelPage = function() {
        console.log("function:mdSmart.FC_P01.gotoControlPanelPage");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if($("#errorDiv").css("display") == "none"){
			bridge.showControlPanelPage();
		}
    };
	//暂停按钮
    mdSmart.B0_P01.eventB0_P01_Pause=function(){

    	if(mdSmart.B0_P01.childLockStatus){
    		$('#B1_POP01').click();
    		return false;
    	}
    	if(!mdSmart.B0_P01.workStatus){
            $('#B1_POP03').click();
            return false;
        }
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//开始按钮状态控制
		if(timer) {clearTimeout(timer);}
		mdSmart.B0_P01.setFunctionWorkStatePause();
	};
	//开始按钮
    mdSmart.B0_P01.eventB0_P01_Start=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//开始按钮状态控制
		if(timer) {clearTimeout(timer);}
		mdSmart.B0_P01.setTimeoutSurplusTime();
		mdSmart.B0_P01.setFunctionWorkStateWork();
	};
	//取消按钮
    mdSmart.B0_P01.eventB0_P01_Cancel=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//确认取消按钮事务处理
		mdSmart.B0_P01.message.setFunctionWorkStateStandby();
		$("#B0_P01_Cancel").addClass("ricecooker_04_waiting");
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			$("#B0_P01_Cancel").removeClass("ricecooker_04_waiting");
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
				$("#B0_P01_Cancel").removeClass("ricecooker_04_waiting");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
	};
	mdSmart.B0_P01.eventB0_Working_Cancel=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//确认取消按钮事务处理
		mdSmart.B0_P01.message.setFunctionWorkStateStandby();
       $('#B0_P01_Working_Cancel').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
           $('#B0_P01_Working_Cancel').css('background-image','url(images/card-icon03.png)');
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
              $('#B0_P01_Working_Cancel').css('background-image','url(images/card-icon03.png)');
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
	};
	//开机
    mdSmart.B0_P01.eventB0_P01_OpenPower=function(){
	    console.log('open power');
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		// $("#B4_P03_PowerOff").hide();
		// $("#B4_P03_PowerOffConfirm").show();
		//开始按钮状态控制
		mdSmart.B0_P01.OpenPower_setFunctionWorkStateWork();
	};
	//关机按钮
	mdSmart.B0_P01.eventPowerOff=function(e){
		console.log("function:mdSmart.FC_P03.eventPowerOff");
		if(mdSmart.B0_P01.childLockStatus){
    		$('#B1_POP01').click();
    		return false;
    	}
    	if(mdSmart.B0_P01.workStatus){
            $('#B1_POP04').click();
            return false;
        }
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		// $("#B4_P03_PowerOff").hide();
		// $("#B4_P03_PowerOffConfirm").show();
		mdSmart.B0_P01.setFunctionWorkStateEnergySaving();
	};
	//确认取消按钮
    mdSmart.B0_P01.eventB0_P01_CancelWork=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//确认取消按钮事务处理
		mdSmart.B0_P01.message.setFunctionWorkStateStandby();
       $('#B0_P01_CancelWork').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
          $('#B0_P01_CancelWork').css('background-image','url(images/card-icon03.png)');
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
              $('#B0_P01_CancelWork').css('background-image','url(images/card-icon03.png)');
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
	};
	//确认按钮
    mdSmart.B0_P01.eventB0_P01_EndConfirm=function(){
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		if(mdSmart.common.isCartBtnLock() == true){return false;}
		//确认取消按钮事务处理
		mdSmart.B0_P01.message.setFunctionWorkStateStandby();
		$("#B0_P01_EndConfirm").addClass("ricecooker_06_waiting");
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			$("#B0_P01_EndConfirm").removeClass("ricecooker_06_waiting");
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
				$("#B0_P01_EndConfirm").removeClass("ricecooker_04_waiting");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
	};
	//童锁按钮事件
	mdSmart.B0_P01.eventB0_P01_ChildLock=function(){
		if(mdSmart.B0_P01.workStatus){
            $('#B1_POP02').click();
            return false;
        }
	    if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		mdSmart.B0_P01.setFunctionWorkStateLock();
	};
	//解锁按钮事件
	mdSmart.B0_P01.eventB0_P01_ChildUnLock=function(){
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		mdSmart.B0_P01.setFunctionWorkStateUnLock();
	}
    // 工作状态--待机
    mdSmart.B0_P01.setFunctionWorkStateStandby = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateStandby");
        mdSmart.B0_P01.message.setFunctionWorkStateStandby();
        $('div[data-state="standbyAndWork"]').removeClass('Standby').addClass('Standby');
        $('.heat-food').css('display','none');
		$("#B0_P01_Cancel").addClass("ricecooker_06_waiting");
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
			$("#B0_P01_Cancel").removeClass("ricecooker_06_waiting");
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
				$("#B0_P01_Cancel").removeClass("ricecooker_04_waiting");
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--暂停
    mdSmart.B0_P01.setFunctionWorkStatePause = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStatePause");
        mdSmart.B0_P01.message.setFunctionWorkStatePause();
        $('#B0_P01_Pause').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
           $('#B0_P01_Pause').css('background-image','url(images/card-icon01.png)');
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
              $('#B0_P01_Pause').css('background-image','url(images/card-icon01.png)');
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--工作
    mdSmart.B0_P01.OpenPower_setFunctionWorkStateWork = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateWork");
        mdSmart.B0_P01.message.setFunctionWorkStateWork();
        $('#B0_P01_BTN_OpenPower').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            $('#B0_P01_BTN_OpenPower').css('background-image','url(images/card-icon06.png)');
            mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
            if(errCode == -1){
                $('#B0_P01_BTN_OpenPower').css('background-image','url(images/card-icon06.png)');
                mdSmart.common.isCartBtnLockControl(false);
            }
        });
        // mdSmart.B0_P01.setTimeoutSurplusTime();
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--工作
    mdSmart.B0_P01.setFunctionWorkStateWork = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateWork");
        mdSmart.B0_P01.message.setFunctionWorkStateWork();
        $('#B0_P01_StartWork').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            $('#B0_P01_StartWork').css('background-image','url(images/card-icon02.png)');
			mdSmart.common.isCartBtnLockControl(false);
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        },function(errCode){
			if(errCode == -1){
                $('#B0_P01_StartWork').css('background-image','url(images/card-icon02.png)');
				mdSmart.common.isCartBtnLockControl(false);
			} 
		});
		// mdSmart.B0_P01.setTimeoutSurplusTime();
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--关机
    mdSmart.B0_P01.setFunctionWorkStateEnergySaving = function () {
    	var timer = null;
        console.log("function:mdSmart.B0_P01.eventPowerOff");
	    // if(mdSmart.common.isOperationLock() == true){return false;}
		// if(mdSmart.common.isPopupLock() == true){return false;}
		//【断电】统一修改为【关机】，指令为把工作状态（byte10）设置为省电0x07 
		if ($('#B0_P01_PowerOff').html() === '关机') {
            /*
            // mdSmart.B0_P03.message.setFunctionWorkStateEnergySaving();
            $('#B0_P01_PowerOff').addClass("clearBg").html('确认关机');
            timer = setTimeout(function(){
                $('#B0_P01_PowerOff').removeClass("clearBg").html('关机');
            },3000);
			return;
			*/
            //$('#B0_P01_PowerOff').addClass("clearBg").html('正在关机');
            $('#B0_P01_PowerOff').css('background-image','url(images/waiting.gif)');
            mdSmart.B0_P01.message.setFunctionWorkStateEnergySaving();
            var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
            var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
                mdSmart.common.isCartBtnLockControl(false);
                mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
                $('#B0_P01_PowerOff').css('background-image','url(images/card-icon06.png)');
                mdSmart.B0_P01.cmdRequestStatus();
            },function(errCode){
                if(errCode == -1){
                    $('#B0_P01_PowerOff').removeClass("clearBg").html('关机');
                    mdSmart.common.isCartBtnLockControl(false);
                    $('#B0_P01_PowerOff').css('background-image','url(images/card-icon06.png)');
                }
            });
            mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
        } else if ($('#B0_P01_PowerOff').html() === '正在关机') {
            //$('#B0_P01_PowerOff').removeClass("clearBg").html('关机');
        } 
    };
	// 工作状态--结束
    mdSmart.B0_P01.setFunctionWorkStateOver = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateOver");
        mdSmart.B0_P01.message.setFunctionWorkStateOver();
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
        });
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--童锁
    mdSmart.B0_P01.setFunctionWorkStateLock = function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateLock");
        mdSmart.B0_P01.message.setFunctionWorkStateLock();
       $('#B0_P01_ChildLock').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
           $('#B0_P01_ChildLock').css('background-image','url(images/button_lock.png)');
        },function(errCode){
			if(errCode == -1){
              $('#B0_P01_ChildLock').css('background-image','url(images/button_lock.png)');
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
	//工作状态--解锁
	mdSmart.B0_P01.setFunctionWorkStateUnLock= function () {
        console.log("function:mdSmart.B0_P01.setFunctionWorkStateUnLock");
        mdSmart.B0_P01.message.setFunctionWorkStateUnLock();
       $('#B0_P01_ChildUnLock').css('background-image','url(images/waiting.gif)');
        var cmdBytes = mdSmart.B0_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P01.cmdRequestStatus();
           $('#B0_P01_ChildUnLock').css('background-image','url(images/icon_unlock.png)');
        },function(errCode){
			if(errCode == -1){
              $('#B0_P01_ChildUnLock').css('background-image','url(images/icon_unlock.png)');
			} 
		});
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
    // 查询按钮
    mdSmart.B0_P01.cmdRequestStatus = function () {
        console.log("function:mdSmart.B0_P01.cmdRequestStatus");
		var cmdBytes = mdSmart.B0_P01.message.cmdRequestStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P01.afterControlProcess(cmdId, cmdBytes);
    };
    // 定时取 剩余时间
    var timer = null;
    // var i=0;
    mdSmart.B0_P01.setTimeoutSurplusTime = function(){
    	// var surplusTimeHour = jsonStatus.status.surplusTimeHour.value;
    	// var surplusTimeMinute = jsonStatus.status.surplusTimeMinute.value;
		// var surplusTimeSeconds = jsonStatus.status.surplusTimeSeconds.value;
    	// if(timer) {clearTimeout(timer)}
		var min, sec;
		allTime = allTime - 1;
		if(allTime < 0) {clearTimeout(timer); return false;}
		timer = setTimeout(function(){
			$("#B0_P01_LBL_SURPLUSTIME_MINUTE").html(mdSmart.common.formatNumberByZero(parseInt(allTime/60, 10), 2));
			$("#B0_P01_LBL_SURPLUSTIME_SECOND").html(mdSmart.common.formatNumberByZero(parseInt(allTime%60),2));
			mdSmart.B0_P01.setTimeoutSurplusTime();
		}, 1000);
    }
    mdSmart.B0_P01.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P01.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P01.message.getResponseBack();
            var messageType = cmdMessageType;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
            }else{
				mdSmart.message.setByte(messageBody,0,0x02);
			}
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_P01.showStatus = function (messageBackRequest, messageBackBack) {
	
	    var jsonStatus = mdSmart.B0_P01.message.parseMessageForView(messageBackBack);
	    msgBB = messageBackBack;
	    // alert(JSON.stringify(jsonStatus))
	    mdSmart.B0_P01.workStatus = false; //工作状态
		window.localStorage.setItem(deviceId+"_B2_local_status", JSON.stringify(jsonStatus));  //缓存
	    if (bDebug == true){
	    	//alert(JSON.stringify(jsonStatus));
	    }
	    console.log(jsonStatus);
		var workState = jsonStatus.status.workState.value;
		$("#waitingDiv").hide();
		$("#lockDiv").hide();
		$("#workingDiv").hide();
		$("#baowenDiv").hide();
		$("#endDiv").hide();
		$("#StopDiv").hide();
		$("#workStatusDiv").show();
		$("#errorDiv").hide();
		// alert(workState)
		var errorCode = jsonStatus.status.errorCode.value;
		var warningCode00 = jsonStatus.status.warningCode00.value;
		var warningCode01 = jsonStatus.status.warningCode01.value;
		var warningCode03 = jsonStatus.status.warningCode03.value;
        
		//故障
        if(errorCode != 0x00){
            $("#standbyAndWork").addClass("errorBg");
            $(".baoWenTxt1").text("E-0"+errorCode+"故障");
            $(".baoWenTxt2").text("请尽快联系售后人员维修");
            $("#workStatusDiv").hide();
            $("#errorDiv").show();
            return;
        } else {
            $("#standbyAndWork").removeClass("errorBg");
        }

        if(warningCode03 == 0x01){
            $("#standbyAndWork").addClass("Standby");
            $(".baoWenTxt1").text("炉门没关！");
            $(".baoWenTxt2").text("请确保炉门关紧");
            $("#workStatusDiv").hide();
            $("#errorDiv").show();
            return;
        }
        if(warningCode00 == 0x01){
            $("#standbyAndWork").addClass("Standby");
            $(".baoWenTxt1").text("水箱没插好！");
            $(".baoWenTxt2").text("请确保水箱已置于设备内");
            $("#workStatusDiv").hide();
            $("#errorDiv").show();
            return;
        }
        if(warningCode01 == 0x01){
            $("#standbyAndWork").addClass("Standby");
            $(".baoWenTxt1").text("水箱缺水！");
            $(".baoWenTxt2").text("请确保水箱中水量充足");
            $("#workStatusDiv").hide();
            $("#errorDiv").show();
            return;
        }

 		// 省电
//		if(workState == 0x07){
//			if($.mobile.activePage[0].id == "B0_P01"){
//				$.mobile.changePage("#B0_P02");
//			}
//		} else {  //非省电
//			if($.mobile.activePage[0].id == "B0_P02"){
//				$.mobile.changePage("#B0_P01");
//			}
//		}
		if (workState == 0x01) {
			window.localStorage.setItem(deviceId+"_B2_local_workMode", "null");
		}
        if (workState == 0x07) {
            document.getElementById('B0_P02').className = 'card_ricecooker_gray';
            $('#B0_P01').hide();
            $('#B0_P02').show();
            $('.card_bottom').hide();
            $('.card_bottom01').show();
        } else {
            document.getElementById('B0_P01').className = 'card_main';
            $('#B0_P01').show();
            $('#B0_P02').hide();
            $('.card_bottom').show();
            $('.card_bottom01').hide();
        }

        
		//待机：0：00，剩余时间这几个字不显示 
		if(workState == 0x01 || workState == 0x05) {
			
			$('div[data-state="standbyAndWork"]').removeClass('Standby').addClass('Standby');
        	$('.heat-food').css('display','none');	
        	if(timer) {clearTimeout(timer);}
        	$('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');
        	$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');

        	//暂停按钮显示,开始按钮隐藏
			//$("#B0_P01_Pause").show();
			//$("#B0_P01_Start").hide();
			$("#waitingDiv").show();
		}
		
		var surplusTimeMinute = jsonStatus.status.surplusTimeMinute.value;
		var surplusTimeSeconds = jsonStatus.status.surplusTimeSeconds.value;
		var workMode = jsonStatus.status.workMode.view[jsonStatus.status.workMode.value];/*jsonStatus.status.workMode.value*/
		var temp = jsonStatus.status.temperature.value;
		
		$("#B0_P01_LBL_SURPLUSTIME_HEADER").html(mdSmart.i18n.TIME_LEFT);
		$("#B0_P01_LBL_CONNECTOR").html("|");
		//温度显示 
		$("#B1_P01_Temp").html(temp);
		//工作状态
		$("#B0_P01_LBL_WORKMODE").html(workMode);
		$("#B0_P01_LBL_SURPLUSTIME").html("");
		$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');
		$('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');
		$("#B0_P01_CancelConfirm").hide();//隐藏确认取消按钮,显示取消按钮
		//童锁按钮控制
		// $("#B0_P01_ChildLock").html(mdSmart.i18n.CHILDLOCK_FUNCTION);
		// $("#B0_P01_ChildLock").removeClass("switch-off").addClass("switch-on");
		// $("#B0_P01_ChildLock_Img").attr("src",""); 
		//工作：显示的回复数据包中的byte12，byte13 
		if(workState == 0x02 || workState == 0x03 ){
			//工作和暂停
			var constant_workMode = window.localStorage.getItem(deviceId+"_B2_local_workMode");

			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				if(constant_workMode.length>3){
					$("#B0_P01_LBL_WORKMODE").text(constant_workMode.substring(0,3)+"..");
				} else {
					$("#B0_P01_LBL_WORKMODE").text(constant_workMode);
				}
			}
		}
		
		if(workState==0x02){
			$('div[data-state="standbyAndWork"]').removeClass('Standby');
        	$('.heat-food').css('display','block');	
			$("#B0_P01_LBL_SURPLUSTIME").html(surplusTimeMinute+":"+mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
			$("#B0_P01_LBL_SURPLUSTIME_MINUTE").html(mdSmart.common.formatNumberByZero(surplusTimeMinute,2));
			$("#B0_P01_LBL_SURPLUSTIME_SECOND").html(mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
			allTime = surplusTimeMinute*60 + parseInt(surplusTimeSeconds, 10);
			if(timer) {clearTimeout(timer);}
			mdSmart.B0_P01.setTimeoutSurplusTime();
			//暂停按钮隐藏,显示开始按钮
			//$("#B0_P01_Pause").show();
			//$("#B0_P01_Start").hide();
			// $("#B0_P01_Cancel").show();
			$("#workingDiv").show();
			mdSmart.B0_P01.workStatus = true; //工作状态
		}
		//暂停：显示的回复数据包中的byte12，byte13 
		if(workState==0x03){
			$('div[data-state="standbyAndWork"]').removeClass('Standby');
        	// $('.heat-food').css('display','none');	
			$("#B0_P01_LBL_SURPLUSTIME").html(surplusTimeMinute+":"+mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
			$("#B0_P01_LBL_SURPLUSTIME_MINUTE").html(mdSmart.common.formatNumberByZero(surplusTimeMinute,2));
			$("#B0_P01_LBL_SURPLUSTIME_SECOND").html(mdSmart.common.formatNumberByZero(surplusTimeSeconds,2));
			//暂停按钮隐藏,显示开始按钮
			//$("#B0_P01_Pause").hide();
			//$("#B0_P01_Start").show();
			// $("#B0_P01_Cancel").show();
			if (timer) {
                clearTimeout(timer);
            }
			$("#StopDiv").show();
            mdSmart.B0_P01.workStatus = true; //工作状态
		}
		//结束：时间的位置显示 END，不显示【剩余时间】这几个字
		if(workState==0x04){
			/*$("#B0_P01_LBL_SURPLUSTIME_HEADER").html("");
			$("#B0_P01_LBL_CONNECTOR").html("");
			$('#B1_P01_Temp').html('');
			$("#B0_P01_LBL_WORKMODE").html("");
			$("#B0_P01_LBL_SURPLUSTIME").html("END");
			$("#B0_P01_LBL_SURPLUSTIME_MINUTE").html('00');
			$("#B0_P01_LBL_SURPLUSTIME_SECOND").html('00');*/
			//暂停按钮隐藏,显示开始按钮
			//$("#B0_P01_Pause").hide();
			//$("#B0_P01_Start").show();
			// $("#B0_P01_Cancel").show();
			$('div[data-state="standbyAndWork"]').removeClass('Standby').addClass('Standby');
			$("#workStatusDiv").hide();
			$("#errorDiv").show();
			$(".baoWenTxt1").text("烹饪完成！");
			$(".baoWenTxt2").text("请尽快取出食物");
			$("#endDiv").show();
		}

		if(workState==0x51){
		    if(!$("#B0_P01_ChildLock").hasClass("switch-off")){
			    $("#B0_P01_ChildLock").removeClass("switch-on").addClass("switch-off"); 
		    }
			//$("#B0_P01_ChildLock").html(mdSmart.i18n.CHILDUNLOCK_FUNCTION);
            $(".heat-food").hide();
			$('#js-clock').css('display','block');
			mdSmart.B0_P01.childLockStatus = true;
			$("#waitingDiv").hide();
			$("#working").hide();
			$("#baowenDiv").hide();
			$("#endDiv").hide();
			$("#lockDiv").show();
			$("#StopDiv").hide();
		} else {
		   if($("#B0_P01_ChildLock").hasClass("switch-off")){
				$("#B0_P01_ChildLock").removeClass("switch-off").addClass("switch-on");
		   } 
		   //$("#B0_P01_ChildLock").html(mdSmart.i18n.CHILDLOCK_FUNCTION);
		   $('#js-clock').css('display','none');
		   mdSmart.B0_P01.childLockStatus = false;
		}
		
		if(jsonStatus.status.workMode.value == 0x02){ //保温
			$("#waitingDiv").hide();
			$("#workingDiv").hide();
			$("#baowenDiv").show();
			$("#endDiv").hide();
			$("#lockDiv").hide();
			$("#StopDiv").hide();
		}
    }
})(mdSmart);

var firstCome = 0;
$(function(){ // 初始化数据
	if(firstCome ==0 ){
		//window.localStorage.setItem(deviceId+"_B2_local_workMode", "null");
		window.localStorage.setItem("B2_token", "null");
	}
})
