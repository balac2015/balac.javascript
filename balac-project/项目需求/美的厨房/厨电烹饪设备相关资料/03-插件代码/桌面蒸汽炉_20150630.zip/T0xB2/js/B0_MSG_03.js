var B0_P03_Menu_SelectName;
var allTime = 0;
var isBaoWen = false;
var isPowerOff = false;
var deviceId = bridge.getCurrentApplianceID();
window.sessionStorage.removeItem("workMenuId");

$(function (){
	//获取动态码
	var token = window.localStorage.getItem("B2_token");
	startIndex = 1;
	endIndex= 6;
	if(token == "null" || token == null){
		getPwd();
	} else {
		var recipe = window.localStorage.getItem("B2_recipe");
		//alert(recipe);
		if(recipe == "null" || recipe== null){
			getPlatform(JSON.parse(token));
		} else {
			var currRecipe = window.localStorage.getItem(deviceId+"_B2_currRecipe");
			var constant_workMode = window.localStorage.getItem(deviceId+"_B2_local_workMode");
			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				if(currRecipe != null && currRecipe != "null"){
					insertEl(currRecipe);
					mdSmart.B0_P03.cmdRequestStatus()
				}
			}
            insertEl(recipe);
        }
	}


});

//1.获取动态码代码
function getPwd() {
	var _jsonData = {
	"uid" : "10486", //uid先写着“10486”
	"fun" : "getPwd"
	};
	var str=encrypt4Pwd(JSON.stringify(_jsonData));
	$.ajax({
		type : "post",
		url : "http://iot3.midea.com.cn:8787/nutrition/v11/base2pro/data/transmit?data="+str,
		dataType : 'json',
		async : true,
		success : function(res){
			var obj = eval(res);
			var token = decrypt4Pwd(obj.data);
			var recipe = window.localStorage.getItem("B2_recipe");
			if(recipe == "null" || recipe== null){
                    //二次请求
                    getPlatform(JSON.parse(token));
			} else{
                insertEl(recipe);
            }

            window.localStorage.setItem("B2_token",token);
			
		}
	});
}

function getPlatform(token) {
    var data = token;
    var sessionPlatform = window.localStorage.getItem(deviceId+"_B2_Sn");
    var str = {
        "fun": "snQuery",
        "applianceId": deviceId,
        "pwd": data.pwd + "",
        "uid": "10486"
    };
    //if(sessionPlatform==null || sessionPlatform=="null" || sessionPlatform=="undefined"){
        $.ajax({
            type: "post",
            url: "http://" + data.server + ":" + data.port + data.preUrl + "sn",
            dataType: 'json',
            async: true,
            headers: {
                "sessionID": data.sessionID + ""
            },
            data: {"nopwd": "true", "debug": true, "data": JSON.stringify(str)},
            success: function (sn) {
                //alert(JSON.stringify(sn));
                var Sn = sn.platform;
                if(Sn !=null || Sn !=undefined){
                    window.localStorage.setItem(deviceId+"_B2_Sn",JSON.stringify(Sn));
                    getRecipe(data,Sn);
                }else{
                    window.localStorage.setItem(deviceId+"_B2_Sn","0000");
                    getRecipe(data,"");
                }
            },
            error:function(er){
                //alert(er);
            }
        });

    //}else{
      //  getRecipe(data,sessionPlatform);
    //}

}

function getRecipe(data,platform){
	var str1 = {
		"fun" : "3conditionList",  
		"food": "", //食材类别id
		"area": "",   //区域类别id
		"commontype": "", //常见分类id  //如家常菜、海鲜、热菜、凉菜、素菜、蒸菜、药膳、卤菜、甜品、点心。
		"devType": "4",   //烹饪设备种类id
		"page": startIndex +"," + endIndex,  //分页 要求返回第1到20条数据
		"pwd" : data.pwd+"",
        "platform":platform,
		"uid" : "10486"
	};
	$.ajax({
		type : "post",
		url : "http://"+data.server+":"+data.port+data.preUrl+"recipe",
		dataType : 'json',					
		async : true,
		headers:{
			"sessionID": data.sessionID+""
		},
		data:{"nopwd":"true","debug":true,"data":JSON.stringify(str1)},
		success : function(res){	
			//alert(JSON.stringify(res));
			if(startIndex == 1){
				$(".listWrap").remove();
				window.localStorage.setItem("B2_recipe", JSON.stringify(res));
				var currRecipe = window.localStorage.getItem(deviceId+"_B2_currRecipe");
				var constant_workMode = window.localStorage.getItem(deviceId+"_B2_local_workMode");
				if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
					if(currRecipe != null && currRecipe != "null"){
						insertEl(currRecipe);
						mdSmart.B0_P03.cmdRequestStatus();
					}
				}
			}
			insertEl(JSON.stringify(res));
			//myScroll.refresh();
		} ,
		error:function(datr){
			//alert(JSON.stringify(datr));
		}
	});
}

//2，加密方法
function encrypt4Pwd(str){
	var keyHex = CryptoJS.enc.Utf8.parse("guoqnlyq");
	var encrypted = CryptoJS.DES.encrypt(str, keyHex, {
							  mode: 		CryptoJS.mode.ECB,
							  padding: 		CryptoJS.pad.Pkcs7
							  });
	 var unicode = CryptoJS.enc.Base64.parse(encrypted.toString()).toString();
	 var  str = '';
	 for(var i = 0 ; i < unicode.length/2;++i){
		 var temp =parseInt (unicode.substr(i*2,2), 16);
		 if(temp>128)
		 {
			temp=temp-256;
		 }

		 if(i!=unicode.length/2-1)
		 {
			str+=temp.toString(32)+',';
		 }else{
			str+=temp.toString(32);
		 }
	}
	return str;
}


//3，解密方法
function decrypt4Pwd(str){
	var array = str.split(",");
	var returnStr = '';
	for (var i=0 ; i< array.length ; i++)
	{
		var temp;
		if(array[i].substr(0,1)=="-")
		{
			temp = (256-parseInt(array[i].substr(1,2),16)).toString(16);
		}else{
			if(parseInt(array[i],16)<16){
				temp = "0"+parseInt(array[i],16).toString(16);
			}else{
				temp = parseInt(array[i],16).toString(16);
			}
		}
		returnStr+=temp;
	}
	var encryptedHexStr = CryptoJS.enc.Hex.parse(returnStr);
	var encryptedBase64Str = CryptoJS.enc.Base64.stringify(encryptedHexStr);
	var keyHex = CryptoJS.enc.Utf8.parse("lyqguoqn");
	var decrypted = CryptoJS.DES.decrypt({
										  ciphertext:CryptoJS.enc.Base64.parse(encryptedBase64Str)
										  }, keyHex, {
										  mode: CryptoJS.mode.ECB,
										  padding: CryptoJS.pad.Pkcs7
										  });  
	returnStr = decrypted.toString(CryptoJS.enc.Utf8);
	return returnStr;
 }

 //插入列表
function insertEl(messsageBack){

    menuDate=JSON.parse(messsageBack).list;
    for(var i=0;i<menuDate.length;i++)
    {	
		if(menuDate.length > 1){
			var constant_workMode = window.localStorage.getItem(deviceId+"_B2_local_workMode");
			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				var currRecipe = window.localStorage.getItem(deviceId+"_B2_currRecipe");
				if(currRecipe != null && currRecipe != "null"){
					var currData = JSON.parse(currRecipe).list;
					if(currData[0].recipe == menuDate[i].recipe){
						continue;
					}
				}
			}
		}
		
        var totalMinutes= 0,listWrap;
        var picUrl = menuDate[i].picUrl;
        var subString = picUrl.substr(0,picUrl.length - 4);
        var listImg = "<div class='list_img'><img class='listImg' src='"+subString+"_m.jpg'/></div>";
        var listCir = "<div class='listCirWrap'><div class='cir on'></div></div>";
        var listMain = "<div class='list_main'><div class='list_main_title'>"+menuDate[i].name+"</div><div class='list_main_time' style='display: none'>烹饪中...</div></div>";
        var listBut =  "<div class='list_but'></div>";
        listWrap = "<div class='listWrap' id='" + menuDate[i].recipe + "'>" + listImg + listCir + listMain + listBut + "</div>" ;
        $("#listsContain").append(listWrap).insertBefore($(".mui-pull-bottom-pocket"));

    }
    picLoading();
    $(".listWrap").on("tap",{},function(ev){
        var menuId = $(this).attr("id");
        var title = $(this).find(".list_main_title").text();
        window.location.href="cookstep.html?menuTit="+decodeURI(title) +"&menuId="+menuId;
        ev.preventDefault();
    });
    //$("#listsContain").append("<div class='pullDown'>下拉加载</div>");
}
function picLoading(backData){
    document.addEventListener("readystatechange",function(event){

        if(document.readyState == "interactive"){

            for(var i=0;i < backData.length;i++ ){
                var picUrl1 =backData[i].picUrl;
                var urlString = picUrl.substr(0,picUrl1.length - 4)+"_m.jpg";
                document.getElementsByClassName("listImg")[i].setAttribute("data-src",picUrl1);
                document.getElementsByClassName("listImg")[i].src = document.getElementsByClassName("stepImg")[i].getAttribute("data-src");
            }
        }

    },false);
}
/**
 *  下拉刷新具体业务实现
 */
function pullDownRefresh() {
	setTimeout(function(){
        var localToken = window.localStorage.getItem("B2_token");
        if(localToken == "null" || localToken == null){
            return;
        }
        startIndex = 1;
        endIndex = 6;
        
        getPlatform(JSON.parse(localToken));
        mui('#pullrefresh').pullRefresh().endPulldownToRefresh(false);
    },1500);

       
}

/**
 * 上拉加载具体业务实现
 */
function pullUpRefresh() {
    setTimeout(function(){
        var localToken = window.localStorage.getItem("B2_token");
        if(localToken == "null" || localToken == null){
            return;
        }
        startIndex += 6;
        endIndex += 6;
        getPlatform(JSON.parse(localToken));
        mui('#pullrefresh').pullRefresh().endPullupToRefresh(false);

    },1500);
}


(function(mdSmart) {
    var bDebug = false;
	var currentId = "Menu01";   //选中的菜单序号
    mdSmart.B0_P03 = mdSmart.B0_P03 || {};
    // mdSmart.B0_P04 = mdSmart.B0_P04 || {};

    mdSmart.B0_P03.childLockStatus = false; //童锁状态
    mdSmart.B0_P03.workStatus = false; //工作状态
    // $(document).bind('recieveMessage', {}, function(event, message) {
    //     mdSmart.B0_P03.showStatus("", message);
    // });
    $(document).on('pageinit', 'div[id="B0_P03"]', function(event) {
        console.log('#B0_P03 pageinit.');
        mdSmart.B0_P03.message = new mdSmart.msg0xB0();
        $(document).bind('recieveMessage', {}, function(event, message) {
            mdSmart.B0_P03.showStatus("", message);
        });
		setInterval("mdSmart.B0_P03.cmdRequestStatus()",20000); //轮询
        
        var jsonMenuDate = {
            "MenuDate": [
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b0000000000000020201280008000000000007",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "14",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "40",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": "",
                    "id": "Menu01",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸鱼",
                    "mdrecipepic": "./images/temp/yu.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                },
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "完成。",
                                    "befmsg": "开始",
                                    "bytectrl": "aa14b000000000000002020105000a000000000028",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "24",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "5",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": "",
                    "id": "Menu02",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸肉",
                    "mdrecipepic": "./images/temp/pai_gu.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                },
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b0000000000000020201280008000000000007",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "10",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "40",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": "",
                    "id": "Menu03",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸水蛋",
                    "mdrecipepic": "./images/temp/menu_3.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                },
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b000000000000002020106000a000000000027",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "10",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "6",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": "",
                    "id": "Menu04",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸海鲜",
                    "mdrecipepic": "./images/temp/menu_4.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 2,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                },
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b0000000000000020201280008000000000007",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "35",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "40",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": ".",
                    "id": "Menu05",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸红薯",
                    "mdrecipepic": "./images/temp/menu_5.jpg",
                    "mdrecipepic2": "http://iot3.midea.com.cn:8010/md/menuimage/95/140/c6f0feae-d7f0-4ff2-8997-cfd15273e983.jpg",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                },
                {
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b0000000000000020201280008000000000007",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "30",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "40",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": ".",
                    "id": "Menu06",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "蒸米饭",
                    "mdrecipepic": "./images/temp/menu_6.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                }
                /*{
                    "accessory": "",
                    "advice": "",
                    "barcode": "",
                    "byte20": [
                        {
                            "cmd": [
                                {
                                    "aftmsg": "",
                                    "befmsg": "",
                                    "bytectrl": "aa14b0000000000000020201280008000000000007",
                                    "fgaftmsg": "0",
                                    "fgbefmsg": "0",
                                    "h": "0",
                                    "m": "40",
                                    "s": "0",
                                    "seq": "1",
                                    "trig": "1"
                                }
                            ],
                            "devicetype": "1",
                            "platform": "1002",
                            "segments": "1",
                            "th": "0",
                            "tm": "40",
                            "ts": "0"
                        }
                    ],
                    "description": "",
                    "effect": ".",
                    "id": "Menu09",
                    "mdrecipecomm": [
                        
                    ],
                    "mdrecipecook": "",
                    "mdrecipeingd": "",
                    "mdrecipename": "发酵",
                    "mdrecipepic": "./images/temp/menu_7.jpg",
                    "mdrecipepic2": "",
                    "mdrecipepic3": "",
                    "mdrecipeseason": "",
                    "mdrecipetype1": 20,
                    "mdrecipetype2": 100001,
                    "mdrecipetype3": 5,
                    "nutrition": "",
                    "program": "",
                    "remark": ""
                }*/
            ]
        };
        mdSmart.B0_P03.menuDate = jsonMenuDateParse = jsonMenuDate.MenuDate;
        for (var i = 0; i < mdSmart.B0_P03.menuDate.length; i++) {
            $("#B0_P04_MenuList").append("<div class='menuList' data-menuid=" + mdSmart.B0_P03.menuDate[i].id + ">" + mdSmart.B0_P03.menuDate[i].mdrecipename + "</div>")
            /*
            $("#B0_P04_MenuList").append("<div class='list_img' data-menuid=" + mdSmart.B0_P03.menuDate[i].id + "><img src=" + mdSmart.B0_P03.menuDate[i].mdrecipepic + " /></div>");
            var totalMinutes = 0;
            for (var j = 0; j < mdSmart.B0_P03.menuDate[i].byte20[0].cmd.length; j++) {
                totalMinutes = totalMinutes + parseInt(mdSmart.B0_P03.menuDate[i].byte20[0].cmd[j].m);
            }
            $("#B0_P04_MenuList").append("<div class='list_main' data-menuid=" + mdSmart.B0_P03.menuDate[i].id + "><div class='list_main_title'>" + mdSmart.B0_P03.menuDate[i].mdrecipename + "</div><div class='list_main_time'>烹饪时间：" + totalMinutes + "分钟</div></div>");
            $("#B0_P04_MenuList").append("<div class='list_but' data-menuid=" + mdSmart.B0_P03.menuDate[i].id + " ><div class='but_start'>开始</div></div>");
            $("#B0_P04_MenuList").append("<hr class='list_hr'>");
        */
        }

		mdSmart.B0_P03.checkMode();
		var session_status = window.localStorage.getItem(deviceId+"_B2_local_status");
        if(session_status !== "null" || session_status != null){
            mdSmart.B0_P03.showStatusByJson(JSON.parse(session_status));
        }
		
    });

    $(document).on('pageshow', 'div[id="B0_P03"]', function(event) {
        console.log('#B0_P03 pageshow.');
        //多语言画面文言绑定
        mdSmart.B0_P03.pageTextInit();

        mdSmart.B0_P03.prepareAndShow();
        //工作状态按钮绑定事件
        $("#B0_P03_BTN_BACK").bind('tap', {}, mdSmart.B0_P03.gotoHomePage);
        $("#B0_P03_Pause").bind('tap', {}, mdSmart.B0_P03.eventPause);
        $("#B0_P03_Cancel").bind('tap', {}, mdSmart.B0_P03.eventCancel);
        $("#B0_P03_ChildLock").bind('tap', {}, mdSmart.B0_P03.eventChildLock);
        $("#B0_P03_PowerOff").bind('tap', {}, mdSmart.B0_P03.eventPowerOff);

        $(".list_img").bind('tap', {}, mdSmart.B0_P03.eventMenuStart);
        //$(".list_main").bind('tap', {}, mdSmart.B0_P03.eventMenuStart);
        $(".menuList").bind('tap', {}, mdSmart.B0_P03.eventMenuStart);
        $(".list_but").bind('tap', {}, mdSmart.B0_P03.eventMenuStart);
    });
    $(document).on('pagehide', 'div[id="B0_P03"]', function(event) {
        console.log('#B0_P03 pagehide.');
        //取消绑定事件
        $("#B0_P03_BTN_BACK").unbind('tap');
        $("#B0_P03_BTN_Power_Failure").unbind('tap');
        $("#B0_P03_BTN_Child_Lock").unbind('tap');
        $("#B0_P03_BTN_Reserve").unbind('tap');

    });
    //多语言画面文言绑定
    mdSmart.B0_P03.pageTextInit = function() {
        console.log("mdSmart.B0_P03.pageTextInit");
        $("#B0_P03_BTN_BACK").html(mdSmart.i18n.BACK);
        $("#B0_P03_TITLE").html(mdSmart.i18n.APP_NAME);
        $("#B0_P03_TEXT_MINUTES").html(mdSmart.i18n.MINUTE);
        $("#B0_P03_TEXT_SECOND").html(mdSmart.i18n.SECOND);
        
        $("#B0_P03_TEXT_AREAMENU").html(mdSmart.i18n.REGIONAL_RECIPE);
        $("#B0_P03_TEXT_AREAMENU_GUANGDONG").html(mdSmart.i18n.GUANGDONG + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_SICHUAN").html(mdSmart.i18n.SICHUAN + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_SHANDONG").html(mdSmart.i18n.SHANDONG + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_JIANGSU").html(mdSmart.i18n.JIANGSU + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_FUJIAN").html(mdSmart.i18n.FUJIAN + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_ZHEJIANG").html(mdSmart.i18n.ZHEJIANG + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_HUNAN").html(mdSmart.i18n.HUNAN + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_AREAMENU_ANHUI").html(mdSmart.i18n.ANHUI + mdSmart.i18n.FOOD);
        $("#B0_P03_TEXT_SEASONSMENU").html(mdSmart.i18n.SOUP_IN_FOUR_SEASONS);
        $("#B0_P03_TEXT_SEASONSMENU_SPRING").html(mdSmart.i18n.SPRING);
        $("#B0_P03_TEXT_SEASONSMENU_SUMMER").html(mdSmart.i18n.SUMMER);
        $("#B0_P03_TEXT_SEASONSMENU_AUTUMN").html(mdSmart.i18n.AUTUMN);
        $("#B0_P03_TEXT_SEASONSMENU_WINTER").html(mdSmart.i18n.WINTER);
        $("#B0_P03_TEXT_LOCALMENU").html(mdSmart.i18n.LOCAL_RECIPE);
        $("#B0_P03_TEXT_LOCALMENU_ALL").html(mdSmart.i18n.ALL);
        
        $("#B0_P03_Pause span").html(mdSmart.i18n.PAUSE_FUNCTION);
       // $("#B0_P03_Cancel span").html(mdSmart.i18n.START_FUNCTION);
        $("#B0_P03_ChildLock span").html(mdSmart.i18n.CHILDLOCK_FUNCTION);
	//$("#B0_P03_WorkState").html(mdSmart.i18n.WAITING);
	// $(".data_status").css("padding-top","78px");
    };
    mdSmart.B0_P03.prepareAndShow = function() {
        console.log("mdSmart.B0_P03.prepareAndShow");
        mdSmart.B0_P03.cmdRequestStatus();
        if (bDebug == true) {
            var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
            var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            mdSmart.message.setByte(messageBody, 0, 0x02);
            mdSmart.message.setByte(messageBody, 1, 0x01);
            var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.recieveMessage(bridgeMessage);
        }
    };
    //返回按钮
    mdSmart.B0_P03.gotoHomePage = function() {
        console.log("function:mdSmart.B0_P03.gotoHomePage");
        if (mdSmart.common.isOperationLock() == true) {
            return false;
        }
        if (mdSmart.common.isPopupLock() == true) {
            return false;
        }
        bridge.goBack();
    };
    //暂停按钮
    mdSmart.B0_P03.eventPause = function() {
        console.log("function:mdSmart.B0_P03.eventPause");
        if (mdSmart.B0_P03.btnPauseEnable != null && mdSmart.B0_P03.btnPauseEnable) {
            //$("#B0_P03_Pause span").html()==暂停
            if (timer) {
                clearTimeout(timer);
            }
			if (mdSmart.common.isOperationLock() == true) {
				return false;
			}
			if (mdSmart.common.isPopupLock() == true) {
				return false;
			}
            if ($("#B0_P03_Pause span").html() == mdSmart.i18n.PAUSE_FUNCTION) {
                mdSmart.B0_P03.setFunctionWorkStatePause();
            } else {
                mdSmart.B0_P03.setTimeoutSurplusTime();
                mdSmart.B0_P03.setFunctionWorkStateWork();
            }
        }
    };
    //取消按钮
    mdSmart.B0_P03.eventCancel = function() {
        console.log("function:mdSmart.B0_P03.eventCancel");
		if (timer) {
            clearTimeout(timer);
		}
		if (mdSmart.common.isOperationLock() == true) {
			return false;
		}
		if (mdSmart.common.isPopupLock() == true) {
			return false;
		}
		if($("#B0_P03_Cancel span").text()=="取消"){
			mdSmart.B0_P03.setFunctionWorkStateStandby();
			var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				mdSmart.B0_P03.cmdRequestStatus();
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
		} else{
			mdSmart.B0_P03.startMenu(currentId);
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				mdSmart.B0_P03.cmdRequestStatus();
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
		}
       
    };
    //童锁、解锁按钮
    mdSmart.B0_P03.eventChildLock = function() {
        console.log("function:mdSmart.FC_P03.eventChildLock");
        if (mdSmart.common.isOperationLock() == true) {
            return false;
        }
        if (mdSmart.common.isPopupLock() == true) {
            return false;
        }
        if (mdSmart.B0_P03.btnChildLockEnable != null && mdSmart.B0_P03.btnChildLockEnable) {
            //$("#B0_P03_ChildLock span").html()=="童锁"
            if ($("#B0_P03_ChildLock span").html() == mdSmart.i18n.CHILDLOCK_FUNCTION) {
                mdSmart.B0_P03.setFunctionWorkStateLock();
            } else {
                mdSmart.B0_P03.setFunctionWorkStateStandby();
            }
        }
    };

    // 工作状态--待机
    mdSmart.B0_P03.setFunctionWorkStateStandby = function() {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateStandby");
        mdSmart.B0_P03.message.setFunctionWorkStateStandby();
        mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--暂停
    mdSmart.B0_P03.setFunctionWorkStatePause = function() {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStatePause");
        mdSmart.B0_P03.message.setFunctionWorkStatePause();
        mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--工作
    mdSmart.B0_P03.setFunctionWorkStateWork = function() {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateWork");
        mdSmart.B0_P03.message.setFunctionWorkStateWork();
        mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--结束
    mdSmart.B0_P03.setFunctionWorkStateOver = function() {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateOver");
        mdSmart.B0_P03.message.setFunctionWorkStateOver();
        mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
    // 工作状态--童锁
    mdSmart.B0_P03.setFunctionWorkStateLock = function() {
        console.log("function:mdSmart.B0_P03.setFunctionWorkStateLock");
        mdSmart.B0_P03.message.setFunctionWorkStateLock();
        mdSmart.B0_P03.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };
    //关机按钮
    mdSmart.B0_P03.eventPowerOff = function() {
        console.log("function:mdSmart.FC_P03.eventPowerOff");
        if(mdSmart.B0_P03.childLockStatus){
            $('#B1_POP01').click();
            return false;
        }
        if(mdSmart.B0_P03.workStatus){
            $('#B1_POP02').click();
            return false;
        }
        if (mdSmart.common.isOperationLock() == true) {
            return false;
        }
        if (mdSmart.common.isPopupLock() == true) {
            return false;
        }
        //关机按钮状态控制
        mdSmart.B0_P03.setFunctionWorkStateEnergySaving();
    };
    // 工作状态--关机
    var timerDown = null;
    mdSmart.B0_P03.setFunctionWorkStateEnergySaving = function() {
        
        console.log("function:mdSmart.B0_P01.eventPowerOff");
        // if(mdSmart.common.isOperationLock() == true){return false;}
        // if(mdSmart.common.isPopupLock() == true){return false;}
        //【断电】统一修改为【关机】，指令为把工作状态（byte10）设置为省电0x07 
        if ($('#B0_P03_PowerOff').find('span').html() === '关机') {
            // mdSmart.B0_P03.message.setFunctionWorkStateEnergySaving();
//            $('#B0_P03_PowerOff').find('span').html('确认关机');
//            $('#B0_P03_PowerOff').find('span').css({
//                'background-image': 'url(./images/footer-power-icon-closed.png)'
//            })
//            $('#B0_P03_PowerOff').css({
//                'border-color': 'red'
//            })
//            timerDown = setTimeout(function(){
//                $('#B0_P03_PowerOff').find('span').html('关机');
//                $('#B0_P03_PowerOff').find('span').css({
//                    'background-image': 'url(./images/power.png)'
//                })
//                $('#B0_P03_PowerOff').css({
//                    'border-color': '#ccc'
//                })
//            },3000)
//        } else if ($('#B0_P03_PowerOff').find('span').html() === '确认关机') {
//            if(timerDown) clearTimeout(timerDown);
            mdSmart.B0_P03.message.setFunctionWorkStateEnergySaving();
			var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				mdSmart.common.isCartBtnLockControl(false);
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				mdSmart.B0_P03.cmdRequestStatus();
			}, function(errCode) {
				if (errCode == -1) {
					mdSmart.common.isCartBtnLockControl(false);
				}
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
	    // $(".data_status").css("padding-top","78px");
        } else {
            if(timerDown) clearTimeout(timerDown);
            mdSmart.B0_P03.message.setFunctionWorkStateWork();
            $('#B0_P03_PowerOff').find('span').html('关机');
			$('#B0_P03_PowerOff').find('span').css({
				'background-image': 'url(./images/power.png)'
			})
			$('#B0_P03_PowerOff').css({
				'border-color': '#ccc'
			})
			var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
			var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
				mdSmart.common.isCartBtnLockControl(false);
				mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
				mdSmart.B0_P03.cmdRequestStatus();
			}, function(errCode) {
				if (errCode == -1) {
					mdSmart.common.isCartBtnLockControl(false);
				}
			});
			mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
        }
        // bridge.goBack();
        
    };
    // 查询按钮
    mdSmart.B0_P03.cmdRequestStatus = function() {
        console.log("function:mdSmart.B0_P03.cmdRequestStatus");
        var cmdBytes = mdSmart.B0_P03.message.cmdRequestStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
        // var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
        // var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
        // var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
        // bridge.recieveMessage(bridgeMessage);
    };

    //菜单开始
    mdSmart.B0_P03.eventMenuStart = function() {
        console.log("function:mdSmart.B0_P03.eventMenuStart");

        if (mdSmart.common.isOperationLock() == true) {
            return false;
        }
        if (mdSmart.common.isPopupLock() == true) {
            return false;
        }

        currentId = $(this).attr("data-menuid");
		mdSmart.B0_P03.checkMode();
        console.log(currentId);
    };
    //菜单发令
    mdSmart.B0_P03.startMenu = function(currentId) {

        // mdSmart.B0_P03.message.setFunctionWorkModeMenu01();
        switch (currentId) {
            case 'Menu01':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu01();
                break;
            case 'Menu02':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu02();
                break;
            case 'Menu03':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu03();
                break;
            case 'Menu04':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu04();
                break;
            case 'Menu05':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu05();
                break;
            case 'Menu06':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu06();
                break;
            case 'Menu07':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu07();
                break;
            case 'Menu08':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu08();
                break;
            case 'Menu09':
                mdSmart.B0_P03.message.setFunctionWorkModeMenu09();
                break;
            default:
                mdSmart.B0_P03.message.setFunctionWorkModeMenu01();
                break;

        }
        var cmdBytes = mdSmart.B0_P03.message.cmdControlStatus();
        console.log(cmdBytes)
        var cmdId = bridge.startCmdProcess(cmdBytes, function(messageBack) {
            mdSmart.B0_P03.showStatus(cmdBytes, messageBack);
            // $.mobile.changePage("#B0_P03","turn");
            mdSmart.B0_P03.cmdRequestStatus();
        });
        mdSmart.B0_P03.afterControlProcess(cmdId, cmdBytes);
    };

    // 定时取 剩余时间
    var timer = null;
    // var i=0;
    mdSmart.B0_P03.setTimeoutSurplusTime = function() {
            var min, sec;
            allTime = allTime - 1;
            if (allTime < 0) {
                clearTimeout(timer);
                return false;
            }
            timer = setTimeout(function() {
                $("#B0_P01_LBL_SURPLUSTIME_MINUTE").html(mdSmart.common.formatNumberByZero(parseInt(allTime / 60, 10), 2));
                $("#B0_P01_LBL_SURPLUSTIME_SECOND").html(mdSmart.common.formatNumberByZero(parseInt(allTime % 60), 2));
                mdSmart.B0_P03.setTimeoutSurplusTime();
            }, 1000);
        }
        //模拟返回数据
    mdSmart.B0_P03.afterControlProcess = function(cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P03.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9],
                cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P03.message.getResponseBack();
            var messageType = 0x82;
            messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = cmdMessageType;
            }
            if (cmdMessageType == 0x02) {
                //Byte10	工作状态
                mdSmart.message.setByte(messageBody, 0, mdSmart.message.getByte(cmdMessageBody, 0));
                //Byte11	工作模式
                mdSmart.message.setByte(messageBody, 1, mdSmart.message.getByte(cmdMessageBody, 1));
                //Byte12	剩余时间分
                mdSmart.message.setByte(messageBody, 2, mdSmart.message.getByte(cmdMessageBody, 2));
                //Byte13	剩余时间秒
                mdSmart.message.setByte(messageBody, 3, mdSmart.message.getByte(cmdMessageBody, 3));
                //Byte14	实际温度
                mdSmart.message.setByte(messageBody, 4, mdSmart.message.getByte(cmdMessageBody, 4));
                //Byte15	故障代码
                mdSmart.message.setByte(messageBody, 5, 0x00);
                //Byte16	提醒代码
                mdSmart.message.setByte(messageBody, 6, 0x01);
                //Byte17	维护保养
                mdSmart.message.setByte(messageBody, 7, 0x02);
                //Byte18	耗电量
                mdSmart.message.setByte(messageBody, 8, 0x03);
                //Byte19	使用时长
                mdSmart.message.setByte(messageBody, 9, 0x04);
                //Byte20	当前烹调段数
                mdSmart.message.setByte(messageBody, 10, mdSmart.message.getByte(cmdMessageBody, 6));
                //Byte21	效验和
                mdSmart.message.setByte(messageBody, 11, 0xff);

            }
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
	//检查运行模式
	mdSmart.B0_P03.checkMode = function(){
		$("div[data-menuid='"+currentId+"']").addClass("menuListOn");
		$("div[data-menuid='"+currentId+"']").siblings().removeClass("menuListOn");
		 switch (currentId) {
            case 'Menu01':  //蒸鱼
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("14");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸鱼");
				$('#B0_P03_wendu').html("110");
                break;
            case 'Menu02':  //蒸肉
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("24");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸肉");
				$('#B0_P03_wendu').html("110");
                break;
            case 'Menu03':  //蒸水蛋
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("10");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸水蛋");
				$('#B0_P03_wendu').html("110");
                break;
            case 'Menu04':  //蒸海鲜
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("12");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸海鲜");
				$('#B0_P03_wendu').html("110");
                break;
            case 'Menu05':  //蒸红薯
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("35");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸红薯");
				$('#B0_P03_wendu').html("110");
                break;
            case 'Menu06':  //蒸米饭
				$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html("30");
				$('#B0_P01_LBL_SURPLUSTIME_SECOND').html("00");
				$('#B0_P03_WorkState').html("蒸米饭");
				$('#B0_P03_wendu').html("110");
                break;
		 }

	}

	mdSmart.B0_P03.showStatusByJson = function(messageBackRequest) {
		var jsonStatus = messageBackRequest;
		  mdSmart.B0_P03.workState = jsonStatus.status.workState.value;
        mdSmart.B0_P03.btnPauseEnable = false; //暂停按钮不可控
        mdSmart.B0_P03.btnCancleEnable = false; //取消按钮不可控
        mdSmart.B0_P03.btnChildLockEnable = false; //暂停按钮不可控
        mdSmart.B0_P03.workStatus = false; // 

        isPowerOff = false;

        var surplusTimeMinute = mdSmart.common.formatNumberByZero(jsonStatus.status.surplusTimeMinute.value,2);
		var surplusTimeSeconds = mdSmart.common.formatNumberByZero(jsonStatus.status.surplusTimeSeconds.value,2);
		var workMode = jsonStatus.status.workMode.value;
		//allTime = jsonStatus.status.surplusTimeMinute.value * 60 + parseInt(jsonStatus.status.surplusTimeSeconds.value, 10);
	
        var errorCode = jsonStatus.status.errorCode.value;
        var warningCode00 = jsonStatus.status.warningCode00.value;
        var warningCode01 = jsonStatus.status.warningCode01.value;
        var warningCode03 = jsonStatus.status.warningCode03.value;
        if (timer) {
            clearTimeout(timer);
        }
        //故障
        if(errorCode != 0x00){
            $("#iOSdialogBoxLockScreen").remove();
            $("#iOSdialogBoxWindow").remove();
            $(this).iOSdialogBoxAlert({
                'title'   : "E-0"+errorCode+"故障" ,
                'message' : '请尽快联系售后人员维修' ,
                'button' : '确定'
            },timeOut1);
            function timeOut1(returnData){
                bridge.goBack();
            }
            return;
        }
        if(warningCode03 == 0x01){
            $("#iOSdialogBoxLockScreen").remove();
            $("#iOSdialogBoxWindow").remove();
            $(this).iOSdialogBoxAlert({
                'title'   : "炉门没关！" ,
                'message' : '请确保炉门关紧' ,
                'button' : '确定'
            },timeOut2);
            function timeOut2(returnData){
                bridge.goBack();
            }
            return;
        }
        
        if(warningCode00 == 0x01){
            $("#iOSdialogBoxLockScreen").remove();
            $("#iOSdialogBoxWindow").remove();
            $(this).iOSdialogBoxAlert({
                'title'   : "水箱没插好！" ,
                'message' : '请确保水箱已置于设备内' ,
                'button' : '确定'
            },timeOut3);
            function timeOut3(returnData){
                bridge.goBack();
            }
            return;
        }

        if(warningCode01 == 0x01){
            $("#iOSdialogBoxLockScreen").remove();
            $("#iOSdialogBoxWindow").remove();
            $(this).iOSdialogBoxAlert({
                'title'   : "水箱缺水！" ,
                'message' : '请确保水箱中水量充足' ,
                'button' : '确定'
            },timeOut4);
            function timeOut4(returnData){
                bridge.goBack();
            }
            return;
        } 

        if(jsonStatus.status.workState.value == 0x04){
            $("#iOSdialogBoxLockScreen").remove();
            $("#iOSdialogBoxWindow").remove();
            $(".data_area_1").removeClass("workInfoBg");
            $(".topbg_01").removeClass("workTitBg");
            $(".data_number span").text("00");
            $(this).iOSdialogBoxAlert({
                'title'   : "烹饪完成！" ,
                'message' : '请尽快取出食物' ,
                'button' : '确定'
            },timeOut5);
            function timeOut5(returnData){
                mdSmart.B0_P03.setFunctionWorkStateStandby();
            }
            return;
        }
        
        //弹窗隐藏
        $("#iOSdialogBoxLockScreen").remove();
        $("#iOSdialogBoxWindow").remove();

    	$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');
		$('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');

		$("#B0_P03_Cancel span").text("开始");
        if(workMode == 0x02)
            $("#B0_P03_WorkState").text("保温温度");
        else
            $("#B0_P03_WorkState").text(jsonStatus.status.workMode.view[workMode]);

        if(mdSmart.B0_P03.workState == 0x01){
             window.localStorage.setItem(deviceId+"_B2_local_workMode", "null");
        }
		if(mdSmart.B0_P03.workState == 0x02 || mdSmart.B0_P03.workState == 0x03 ){
			//工作和暂停
			var constant_workMode = window.localStorage.getItem(deviceId+"_B2_local_workMode");

			if(constant_workMode != "null" && constant_workMode != null){  //自动菜单
				if(constant_workMode.length>3){
					$("#B0_P03_WorkState").text(constant_workMode.substring(0,3)+"..");
				} else {
					$("#B0_P03_WorkState").text(constant_workMode);
				}
			}

			$(".listWrap").each(function(){
				if($.trim($(this).find(".list_main_title").text()) == constant_workMode){
					$(this).find(".listCirWrap").show();
					$(this).find(".list_main_title").css("margin-top","10px");
					$(this).find(".list_main_time").show();
					if(mdSmart.B0_P03.workState == 0x02){
						$(this).find(".cir").addClass("on");
						$(this).find(".list_main_time").text("烹饪中...");
					}else{
						$(this).find(".cir").removeClass("on");
						$(this).find(".list_main_time").text("暂停中...");
					}
				
				}else {
					$(this).find(".list_main_time").hide();
				}
			});
		} else {
            $(".listCirWrap").hide();
            $(".list_main_time").hide();
            window.localStorage.setItem(deviceId+"_B2_local_workMode", "null");
        }


		

        //待机、童锁状态显示
        if (jsonStatus.status.workState.value == 0x01 || jsonStatus.status.workState.value == 0x51) {
            mdSmart.B0_P03.btnChildLockEnable = true; //童锁按钮可控
            //童锁画面更新
            if (jsonStatus.status.workState.value == 0x51) {
                if (!$("#B0_P03_ChildLock").hasClass("icon_control03_active")) {
                    $(".icon_control03").toggleClass("icon_control03_active");
                    $(".icon_control03").siblings(".icon_control03_active").removeClass("icon_control03_active");
                    $(".icon_control03 span").html(mdSmart.i18n.WORK_STATE_UnLock);
                }
                $("#B0_P03_ChildLock span").html(mdSmart.i18n.CHILDUNLOCK_FUNCTION); //解锁
				$("#sendLock").addClass("lockBg");
                mdSmart.B0_P03.childLockStatus = true;
            } else {
                if ($("#B0_P03_ChildLock").hasClass("icon_control03_active")) {
                    $(".icon_control03").toggleClass("icon_control03_active");
                    $(".icon_control03").siblings(".icon_control03_active").removeClass("icon_control03_active");
                    $(".icon_control03 span").html(mdSmart.i18n.WORK_STATE_UnLock);
                }
                $("#B0_P03_ChildLock span").html(mdSmart.i18n.CHILDLOCK_FUNCTION); //童锁
                $("#B0_P03_Pause span").html(mdSmart.i18n.PAUSE_FUNCTION); // 暂停
                $("#sendLock").removeClass("lockBg");
				mdSmart.B0_P03.childLockStatus = false;
                //工作状态
		// $(".data_status").css("padding-top","78px");
            }
            //待机时间显示
            if (timer) {
                clearTimeout(timer);
            }
        	if(surplusTimeMinute == '00' && surplusTimeSeconds == '00'){
        		$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');
        		$('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');
        		allTime = 0;
        	} else {
        		mdSmart.B0_P03.setTimeoutSurplusTime();
        	}
            
            
        } else if (jsonStatus.status.workState.value == 0x04) { //结束状态
            //时间显示END
            $('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');
            $('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');
        } else {
            //判断是否是暂停状态
            if (jsonStatus.status.workState.value == 0x03) {
                mdSmart.B0_P03.btnPauseEnable = true; //暂停按钮可控
                mdSmart.B0_P03.workStatus = true;
               
                if (timer) {
                    clearTimeout(timer);
                }
                // mdSmart.B0_P03.setTimeoutSurplusTime();
                //工作状态
                mdSmart.B0_P03.btnCancleEnable = true;
            } else {
                
                $("#B0_P03_Pause span").html(mdSmart.i18n.PAUSE_FUNCTION); //暂停
                if (timer) {
	                clearTimeout(timer);
	            }
                mdSmart.B0_P03.setTimeoutSurplusTime();
            }
            //时间显示
            $('#B0_P01_LBL_SURPLUSTIME_MINUTE').html(mdSmart.common.formatNumberByZero(jsonStatus.status.surplusTimeMinute.value, 2));
            $('#B0_P01_LBL_SURPLUSTIME_SECOND').html(mdSmart.common.formatNumberByZero(jsonStatus.status.surplusTimeSeconds.value, 2));
            // mdSmart.common.formatNumberByZero(parseInt(allTime%60),2)
            allTime = jsonStatus.status.surplusTimeMinute.value * 60 + parseInt(jsonStatus.status.surplusTimeSeconds.value, 10);
        }
		$("#tip").text(jsonStatus.status.workState.value);
        if(jsonStatus.status.workState.value == 0x07){
			$(".data_area_1").hide();
            $(".topbg_01").addClass("offTopBg");
			$(".data_area_2").show();

            isPowerOff = true;
            $('#B0_P03_PowerOff').find('span').html('开机');
            $('#B0_P03_PowerOff').find('span').css({
                'background-image': 'url(./images/power_on_icon.png)'
            })
            $('#B0_P03_PowerOff').css({
                'border-color': '#089c0b'
            })

            $('#B0_P03_Pause').css({
                'color': '#ccc'
            })
            $('#B0_P03_Cancel').css({
                'color': '#ccc'
            })
            $('#B0_P03_ChildLock').css({
                'color': '#ccc'
            })

            $("#B0_P03_Pause").unbind('tap');
            $("#B0_P03_Cancel").unbind('tap');
            $("#B0_P03_ChildLock").unbind('tap');
        } else {
            $(".topbg_01").removeClass("offTopBg");
			$(".data_area_2").hide();
			$(".data_area_1").show();
			$('#B0_P03_PowerOff').find('span').html('关机');
			$('#B0_P03_PowerOff').find('span').css({
				'background-image': 'url(./images/power.png)'
			})
			$('#B0_P03_PowerOff').css({
				'border-color': '#ccc'
			});
            $('#B0_P03_Pause').css({
                'color': '#000'
            });
            $('#B0_P03_Cancel').css({
                'color': '#000'
            });
            $('#B0_P03_ChildLock').css({
                'color': '#000'
            });
			$("#B0_P03_Pause").unbind('tap');
            $("#B0_P03_Cancel").unbind('tap');
            $("#B0_P03_ChildLock").unbind('tap');
            $("#B0_P03_Pause").bind('tap', {}, mdSmart.B0_P03.eventPause);
            $("#B0_P03_Cancel").bind('tap', {}, mdSmart.B0_P03.eventCancel);
            $("#B0_P03_ChildLock").bind('tap', {}, mdSmart.B0_P03.eventChildLock);
        }
        // 解锁
        if(jsonStatus.status.workState.value == 0x11){
            if ($("#B0_P03_ChildLock").hasClass("icon_control03_active")) {
                $(".icon_control03").toggleClass("icon_control03_active");
                $(".icon_control03").siblings(".icon_control03_active").removeClass("icon_control03_active");
                $(".icon_control03 span").html(mdSmart.i18n.WORK_STATE_UnLock);
            }
            $("#B0_P03_ChildLock span").html(mdSmart.i18n.CHILDLOCK_FUNCTION); //童锁
            mdSmart.B0_P03.childLockStatus = false;
        }
        //工作模式取消按钮有效 
        if (jsonStatus.status.workState.value == 0x02) {
			$('#B0_P03_ChildLock').css({
                'color': '#ccc'
            });
            $("#B0_P03_ChildLock").unbind('tap');
			
        	if (timer) {
                clearTimeout(timer);
            }
        	if(surplusTimeMinute == '00' && surplusTimeSeconds == '00'){
        		$('#B0_P01_LBL_SURPLUSTIME_MINUTE').html('00');
        		$('#B0_P01_LBL_SURPLUSTIME_SECOND').html('00');
        	} else {
        		mdSmart.B0_P03.setTimeoutSurplusTime();
        	}
            mdSmart.B0_P03.btnCancleEnable = true; //取消按钮可控
            mdSmart.B0_P03.btnPauseEnable = true;
            mdSmart.B0_P03.workStatus = true;
			
			$("#B0_P03_Cancel span").text("取消");
            //工作状态
			$(".data_area_1").addClass("workInfoBg");
			$(".topbg_01").addClass("workTitBg");
        } else {
			$(".data_area_1").removeClass("workInfoBg");
			$(".topbg_01").removeClass("workTitBg");
		}
        if(jsonStatus.status.workState.value == 0x01){
			$('#B0_P03_Pause').css({
                'color': '#ccc'
            });
			$("#B0_P03_Pause").unbind('tap');
			$("#B0_P03_TEXT_AUTOMENU_Mid").css("opacity","1.0");
			$("#B0_P03_TEXT_AUTOMENU").css("opacity","1.0");
			$("#B0_P03_TEXT_AUTOMENU_DOWN").css("opacity","1.0");
			
			
        } else{
            $('#B0_P03_mode_open_bg').slideUp('slow',function() {
                $("#B0_P03_mode_close_bg").show();
                $("#B0_P03_pulldiv").hide();
            });
			$("#B0_P03_TEXT_AUTOMENU_Mid").css("opacity","0.4");
			$("#B0_P03_TEXT_AUTOMENU").css("opacity","0.4");
			$("#B0_P03_TEXT_AUTOMENU_DOWN").css("opacity","0.4");
		}
		if(jsonStatus.status.workState.value == 0x03){//暂停
			$(".data_area_1").addClass("workInfoBg");
			$(".topbg_01").addClass("workTitBg");
			$('#B0_P03_ChildLock').css({
                'color': '#ccc'
            });
            $("#B0_P03_ChildLock").unbind('tap');
			$("#B0_P03_Cancel span").text("取消");
			$("#B0_P03_Pause span").text("开始");
		}
        if(jsonStatus.status.workState.value == 0x03 || jsonStatus.status.workState.value == 0x02){
            $('#B0_P03_wendu').html(jsonStatus.status.temperature.value);
	    // $(".data_status").css("padding-top","63px");
        } 
		if(jsonStatus.status.workState.value == 0x01 || jsonStatus.status.workState.value == 0x07){  //待机
			mdSmart.B0_P03.checkMode();

			$("#B0_P03_PowerOff").css("opacity","1.0");
			$("#B0_P03_PowerOff").unbind('tap');
			$("#B0_P03_PowerOff").bind('tap', {}, mdSmart.B0_P03.eventPowerOff);
		} else {  //非待机

			$("#B0_P03_PowerOff").css("opacity","0.4");
			$("#B0_P03_PowerOff").unbind('tap');
		}
		if (jsonStatus.status.workState.value == 0x51) {  //童锁
			mdSmart.B0_P03.checkMode();
			$('#B0_P03_Pause').css({
                'color': '#ccc'
            });
            $('#B0_P03_Cancel').css({
                'color': '#ccc'
            });
            $("#B0_P03_Pause").unbind('tap');
            $("#B0_P03_Cancel").unbind('tap');
		}
		if(jsonStatus.status.workMode.value == 0x02){
            $("#B0_P03_WorkModeShow").show();
            $('#B0_P03_Pause').css({
                'color': '#ccc'
            });
            $(".data_status").css("padding-top","1%");
		} else{
			$("#B0_P03_WorkModeShow").hide();
            $(".data_status").css("padding-top","6%");
		}

        if (jsonStatus.status.workMode.value == 0x00 && jsonStatus.status.workState.value == 0x04) {
            //工作 模式 保温
            isBaoWen = true;
        } else {
            isBaoWen = false;
        }
        // $('#tip').html(jsonStatus.status.workMode.value + '-' + jsonStatus.status.workState.value)
	}

    mdSmart.B0_P03.showStatus = function(messageBackRequest, messageBackBack) {
        var jsonStatus = mdSmart.B0_P03.message.parseMessageForView(messageBackBack);
		mdSmart.B0_P03.showStatusByJson(jsonStatus);
    }
    mdSmart.B0_P03.showJSON = function(pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    } else {
                        strStatus = strStatus + temp.value;
                    }
                } else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_P03.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
