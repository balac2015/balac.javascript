(function (mdSmart) {
    var bDebug = false;
    mdSmart.B0_P04 = mdSmart.B0_P04 || {};

    $(document).on('pageinit', 'div[id="B0_P04"]', function (event) {
        console.log('#B0_P04 pageinit.');
        mdSmart.B0_P04.message = new mdSmart.msg0xB0();
        $(document).bind('recieveMessage', {}, function (event, message) {
            mdSmart.B0_P04.showStatus("", message);
        });
		// var jsonMenuDate='{ "MenuDate": [ '
		// 				+'{"accessory":"","advice":"1、金针菇根部一般会粘连在一起，很难清洗干净，可以直接剪掉；2、白菜叶焯烫一下，变软后更易卷起；3、用白菜叶卷起的金针菇不要太多，否则不易卷起；4、金针菇和白菜都焯烫过，不必蒸太久。","barcode":"","byte20":[{"cmd":[{"aftmsg":"","befmsg":"","bytectrl":"aa14b000000000000002020106000a000000000027","fgaftmsg":"0","fgbefmsg":"0","h":"0","m":"6","s":"0","seq":"1","trig":"1"}],"devicetype":"1","platform":"1002","segments":"1","th":"0","tm":"6","ts":"0"}],"description":"很简单的吃法儿，但这么一卷，是不是看起来更有食欲呢。其实很多时候，简单的菜式都可以吃出花样，清淡的食材都可以吃出滋味，稍稍多花点时间和心思，就可以吃出不同心情，很值得，你说是不不能吃辣的同学，记得少放点剁椒哦！","effect":"别看金针菇长得细细小小的，它的氨基酸含量在蘑菇类中可是首屈一指的，而且含锌量也高，适合气血不足、营养不良的老人、儿童以及心脑血管疾病患者食用。另外，小孩子多吃点金针菇，还可以补脑益智。不过，脾胃虚寒的人，最好不要吃太多哦。","id":"8a28963047d9402f014825ac4e7421b4","mdrecipecomm":[],"mdrecipecook":"1.锅中注入适量水，水烧开后，将金针菇洗净、切去根部，放入水中焯烫1分钟2.捞出金针菇，放入白菜叶焯烫至软3.将白菜叶取出，铺平，涂上适量肉沫，再取适量金针菇对折一下，放在白菜叶上4.从上到下卷起，尽量卷紧一些5.全部卷好后，将剩余的白菜叶铺在盘中6.放入金针白菜卷，表面撒上剁椒，把调味料与高汤混合后浇入金针卷上，盖上盖子或保鲜膜，放入微波炉微波大武火加热6分钟即可","mdrecipeingd":"金针菇100克，娃娃菜5片，肉沫100克","mdrecipename":"剁椒金针卷","mdrecipepic":"http://iot3.midea.com.cn:8010/md/menuimage/60/140/61b2959a-96e0-4334-aa24-466f55afd78d.jpg","mdrecipepic2":"","mdrecipepic3":"","mdrecipeseason":"高汤4大勺、油、盐、蚝油适量，剁椒适量","mdrecipetype1":2,"mdrecipetype2":100001,"mdrecipetype3":5,"nutrition":"","program":"","remark":""}'
		//                 +',{"accessory":"","advice":"1.猪肉馅调味时一定要顺着一个方向快速大力搅拌，肉丸弹性才会好。2.烹调加醋。在烹饪大白菜时，适当放点醋，无论从味道，还是从保护营养成分来讲，都是必要的。醋可以使大白菜中的钙、磷、铁元素分解出来，从而有利于人体吸收。醋还可使大白菜中的蛋白质凝固，不致外溢而损失。3.先洗后切。一般蔬菜在烹饪之前都是先洗后切，以保证营养成分不被丢失，烹饪大白菜时也是这样。由于大白菜里的维生素C等营养成分都易溶于水，若切后再洗的话，这些营养成分就容易损失。4.用开水焯。用开水焯一下，对保护其中的维生素C很有好处。因为，大白菜通过加热，可产生一种氧化酶，它对维生素C有很强的破坏作用，这种氧化酶在温度65℃时活动力最强，而在85℃时就被破坏了。","barcode":"","byte20":[{"cmd":[{"aftmsg":"完成。","befmsg":"开始","bytectrl":"aa14b000000000000002020105000a000000000028","fgaftmsg":"0","fgbefmsg":"0","h":"0","m":"5","s":"0","seq":"1","trig":"1"}],"devicetype":"1","platform":"1002","segments":"1","th":"0","tm":"5","ts":"0"}],"description":"其实很多时候，简单的菜式都可以吃出花样，清淡的食材都可以吃出滋味，稍稍多花点时间和心思，就可以吃出不同心情，很值得！","effect":"大白菜养胃却偏凉但同肉类做菜，熟食则性甘平，因此食神就把大白菜和肉配在一起，那些脾胃寒凉的朋友们也能喝啦","id":"8a28963047d9402f014825bb7a6121e3","mdrecipecomm":[],"mdrecipecook":"1.将猪肉洗净剁碎，加入切碎的葱花、胡椒粉、鸡蛋、盐、生抽、鸡精、生粉用筷子顺着一个方向快速搅拌均匀，2.白菜去梗留叶洗净沥水备用3.去一大平底碟，将白菜叶铺平，将调好的肉馅用勺子或手挤成丸子均匀铺着白菜叶上，把高汤加入少许盐和生抽调匀，浇在盘子上摇匀后盖上保鲜膜，放入微波炉微波大武火加热5分钟即可","mdrecipeingd":"大白菜叶100克，五花肉200克、鸡蛋1个","mdrecipename":"白菜肉丸","mdrecipepic":"http://iot3.midea.com.cn:8010/md/menuimage/56/140/f2fae8b0-0ae6-41f1-9979-72f4b2b80c02.jpg","mdrecipepic2":"http://iot3.midea.com.cn:8010/md/menuimage/56/140/6876f5ed-cecf-420b-8cc5-893db420827b.jpg","mdrecipepic3":"","mdrecipeseason":"高汤2大勺、油、生抽、少许盐适量，香葱2根、胡椒粉少许、鸡精少许、生粉少许","mdrecipetype1":20,"mdrecipetype2":100001,"mdrecipetype3":5,"nutrition":"","program":"","remark":""}'
		// 				+',{"accessory":"","advice":"海带(鲜)适合人群：一般人都能食用。　1.适宜缺碘、甲状腺肿大、高血压、高血脂、冠心病、糖尿病、动脉硬化、骨质疏松、营养不良性贫血以及头发稀疏者可多食。　　2.精力不足、缺碘人群、气血不足及肝硬化腹水和神经衰弱者尤宜食用。　　3.脾胃虚寒的人的人慎食，脾胃虚寒者、甲亢中碘过盛型的","barcode":"","byte20":[{"cmd":[{"aftmsg":"","befmsg":"","bytectrl":"aa14b0000000000000020201280008000000000007","fgaftmsg":"0","fgbefmsg":"0","h":"0","m":"40","s":"0","seq":"1","trig":"1"}],"devicetype":"1","platform":"1002","segments":"1","th":"0","tm":"40","ts":"0"}],"description":"海带是一种碱性食品，经常食用会增加人体对钙的吸收，在油腻过多的食物中掺进点海带，可减少脂肪在体内的积存。","effect":"除含有丰富蛋白质、卵磷脂、亚油酸、维生素B1、维生素E、钙、铁,豆腐还含有多种叫皂角苷物质会阻止过氧化脂质产生抑制脂肪吸收促进脂肪分解；使减肥事半功倍.","id":"8a28963047d9402f014825c1dbd521f3","mdrecipecomm":[],"mdrecipecook":"1.将海带泡发洗净切丝，五花肉切薄片2.取微波适用的大碗一个，加入海带、五花肉和4碗水，微波大武火加热15分钟后，转微波中火加热20分钟至海带软，取出加入盐及鸡精调味即可。","mdrecipeingd":"五花肉150克，干海带半条","mdrecipename":"五花肉海带汤","mdrecipepic":"http://iot3.midea.com.cn:8010/md/menuimage/95/140/18971090-82b4-4673-a998-c1d913ec186e.jpg","mdrecipepic2":"http://iot3.midea.com.cn:8010/md/menuimage/95/140/c6f0feae-d7f0-4ff2-8997-cfd15273e983.jpg","mdrecipepic3":"","mdrecipeseason":"盐适量，鸡精少许","mdrecipetype1":20,"mdrecipetype2":100001,"mdrecipetype3":5,"nutrition":"","program":"","remark":""}'
		// 				+']}';
		// mdSmart.B0_P04.menuDate=jsonMenuDateParse=JSON.parse(jsonMenuDate).MenuDate;
		// for(var i=0;i<mdSmart.B0_P04.menuDate.length;i++)
		// {
		// 	$("#B0_P04_MenuList").append("<div class='list_img' id="+mdSmart.B0_P04.menuDate[i].id+"><img src="+mdSmart.B0_P04.menuDate[i].mdrecipepic+"/></div>");
		// 	var totalMinutes=0;
		// 	for(var j=0;j<mdSmart.B0_P04.menuDate[i].byte20[0].cmd.length;j++)
		// 	{
		// 		totalMinutes=totalMinutes+parseInt(mdSmart.B0_P04.menuDate[i].byte20[0].cmd[j].m);
		// 	}
		// 	$("#B0_P04_MenuList").append("<div class='list_main' id="+mdSmart.B0_P04.menuDate[i].id+"><div class='list_main_title'>"+mdSmart.B0_P04.menuDate[i].mdrecipename+"</div><div class='list_main_time'>烹饪时间："+totalMinutes+"分钟</div></div>");
		// 	$("#B0_P04_MenuList").append("<div class='list_but' id="+mdSmart.B0_P04.menuDate[i].id+" ><div class='but_start'>开始</div></div>");	
		// 	$("#B0_P04_MenuList").append("<hr class='list_hr'>");
		// }
    });
    
    $(document).on('pageshow', 'div[id="B0_P04"]', function (event) {
        console.log('#B0_P04 pageshow.');
		//多语言画面文言绑定
		mdSmart.B0_P04.pageTextInit();
        mdSmart.B0_P04.prepareAndShow();
		//工作状态按钮绑定事件
        $("#B0_P04_BTN_BACK").bind('tap', {}, mdSmart.B0_P04.gotoHomePage);
		// $(".list_img").bind('tap', {}, mdSmart.B0_P04.list_main);
		// $(".list_main").bind('tap', {}, mdSmart.B0_P04.list_main);
		// $(".list_img").bind('tap', {}, mdSmart.B0_P04.eventMenuStart);
		// $(".list_main").bind('tap', {}, mdSmart.B0_P04.eventMenuStart);
		// $(".list_but").bind('tap', {}, mdSmart.B0_P04.eventMenuStart);
    });

    $(document).on('pagehide', 'div[id="B0_P04"]', function (event) {
        console.log('#B0_P04 pagehide.');
        //取消绑定事件
		$("#B0_P04_BTN_BACK").unbind('tap');
		$(".list_img").unbind('tap');
		$(".list_main").unbind('tap');
    });
	//多语言画面文言绑定
    mdSmart.B0_P04.pageTextInit=function(){
	    console.log("mdSmart.B0_P04.prepareAndShow");
	    $("#B0_P04_BTN_BACK").html(mdSmart.i18n.BACK);//返回
	    $("#B0_P04_TITLE").html(mdSmart.i18n.RECIPE);//菜谱
	    $("#B0_P04_AUTOMENU").html(mdSmart.i18n.AUTOMENU);//自动菜单
	    $("#B0_P04_AREAMENU").html(mdSmart.i18n.REGIONAL_RECIPE_SPLIT);//菜谱
	    $("#B0_P04_AREAMENU_GUANGDONG").html(mdSmart.i18n.GUANGDONG);//粤
	    $("#B0_P04_AREAMENU_SICHUAN").html(mdSmart.i18n.SICHUAN);//川
	    $("#B0_P04_AREAMENU_SHANDONG").html(mdSmart.i18n.SHANDONG);//鲁
	    $("#B0_P04_AREAMENU_JIANGSU").html(mdSmart.i18n.JIANGSU);//苏
	    $("#B0_P04_AREAMENU_FUJIAN").html(mdSmart.i18n.FUJIAN);//闵
	    $("#B0_P04_AREAMENU_ZHEJIANG").html(mdSmart.i18n.ZHEJIANG);//浙
	    $("#B0_P04_AREAMENU_HUNAN").html(mdSmart.i18n.HUNAN);//湘
	    $("#B0_P04_AREAMENU_ANHUI").html(mdSmart.i18n.ANHUI);//徽
	    $("#B0_P04_SEASONSMENU").html(mdSmart.i18n.SOUP_IN_FOUR_SEASONS_SPLIT);//四季汤水
	    $("#B0_P04_SEASONSMENU_SPRING").html(mdSmart.i18n.SPRING);//春
	    $("#B0_P04_SEASONSMENU_SUMMER").html(mdSmart.i18n.SUMMER);//夏
	    $("#B0_P04_SEASONSMENU_AUTUMN").html(mdSmart.i18n.AUTUMN);//秋
	    $("#B0_P04_SEASONSMENU_WINTER").html(mdSmart.i18n.WINTER);//冬
	    $("#B0_P04_LOCALMENU").html(mdSmart.i18n.LOCAL_RECIPE_SPLIT);//本地菜单
	    $("#B0_P04_LOCALMENU_ALL").html(mdSmart.i18n.ALL);//全	
	    $("#B0_P04_AUTOMENU_DOWN").html(mdSmart.i18n.AUTOMENU);//全	
	};
    mdSmart.B0_P04.prepareAndShow = function () {
        console.log("mdSmart.B0_P04.prepareAndShow");
		$("#"+B0_P03_Menu_SelectName+"_list a").next("div").slideToggle("slow");
		$("#"+B0_P03_Menu_SelectName+"_list a").toggleClass("icon_modebg_active");
		$("#"+B0_P03_Menu_SelectName+"_list a").siblings(".icon_modebg_active").removeClass("icon_modebg_active");
		//$("#Regional_Y").toggleClass("icon_modebg_active");
		//mdSmart.B0_P04.cmdRequestStatus();
        // if (bDebug == true) {
            // var cmdBytes = mdSmart.B0_P04.message.cmdControlStatus();           
            // var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
			// mdSmart.message.setByte(messageBody,0,0x05);
            // var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
            // var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            // bridge.recieveMessage(bridgeMessage);
        // }
    };
	//返回按钮
    mdSmart.B0_P04.gotoHomePage=function(){
	    console.log("function:mdSmart.B0_P04.gotoHomePage");
		if(mdSmart.common.isOperationLock() == true){return false;}
		if(mdSmart.common.isPopupLock() == true){return false;}
		//bridge.goBack();
		$.mobile.changePage("#B0_P03", "turn");
	};
	//菜单开始
	// mdSmart.B0_P04.eventMenuStart=function(){
	// 	console.log("function:mdSmart.B0_P04.eventMenuStart");
	// 	if(mdSmart.common.isOperationLock() == true){return false;}
	// 	if(mdSmart.common.isPopupLock() == true){return false;}
	// 	//bridge.goBack();
	// 	var currentId=$(this).attr("id");
	// 	var currentMenu = mdSmart.B0_P04.menuDate.filter(function(e) {
	// 			return e.id==currentId;
	// 		});
	// 	for(var i=0;i<currentMenu[0].byte20[0].cmd.length;i++)
	// 	{
	// 		var array = currentMenu[0].byte20[0].cmd[i].bytectrl;
	// 		var cmdBytes = [];
	// 		for (var i=0 ; i< array.length ; i++)
	// 		{
	// 			i++;
	// 			cmdBytes.push(parseInt(array.substring(i-1,i+1),16));
	// 		}
	// 		window.setTimeout(mdSmart.B0_P04.startMenu(cmdBytes),400);
	// 	}
	// };
	//菜单发令
	// mdSmart.B0_P04.startMenu=function(cmdBytes){
	// 	var cmdBytes = 0x03; 
	// 	var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
	// 		mdSmart.B0_P04.showStatus(cmdBytes, messageBack);
	// 		// $.mobile.changePage("#B0_P03","turn");
	// 	});
	// 	mdSmart.B0_P04.afterControlProcess(cmdId, cmdBytes);
	// };
	mdSmart.B0_P04.list_main=function(){
		mdSmart.B0_P04.MenuId=$(this).attr("id");
	    $.mobile.changePage("#B0_P05", "turn");
	};
	//模拟返回数据
    mdSmart.B0_P04.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_P04.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_P04.message.getResponseBack();
            var messageType = 0x82;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = cmdMessageType;
            }
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_P04.showStatus = function (messageBackRequest, messageBackBack) {
	
	    var jsonStatus = mdSmart.B0_P04.message.parseMessageForView(messageBackBack);
		// if(jsonStatus.status.workState.value==0x05 && mdSmart.message.getByte(messageBackBack,9)==0x03)
		// {
			// $(".icon_control02").next("div").slideToggle("slow");
			// $(".icon_control02").toggleClass("icon_control02_active");
			// $(".icon_control02").siblings(".icon_control02_active").removeClass("icon_control02_active");
		    // $(".icon_control02 span").html(mdSmart.i18n.WORK_STATE_UnLock);
		// }
        $("#sendMsgDiv").html("<hr>send:" + mdSmart.message.convertTo16Str(messageBackRequest));
        $("#receiveMsgDiv").html("<hr>receive:" + mdSmart.message.convertTo16Str(messageBackBack));
        var jsonStatus = mdSmart.B0_P04.message.parseMessageForView(messageBackBack);
        //var strStatus = "isRequestBack:" + jsonStatus.isRequestBack + "<br>";
        var strStatus = "messageType:" + jsonStatus.messageType + "<br>";
        //strStatus = strStatus + "messageBodyCommand:" + jsonStatus.messageBodyCommand + "<br>";
        strStatus = strStatus + mdSmart.B0_P04.showJSON(jsonStatus.status)
        $("#statusDiv").html("<hr>" + strStatus);
        //$("#statusDiv").html(JSON.stringify(jsonStatus));
    }
    mdSmart.B0_P04.showJSON = function (pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    }
                    else {
                        strStatus = strStatus + temp.value;
                    }
                }
                else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_P04.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
