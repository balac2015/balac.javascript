(function (mdSmart) {
    var bDebug = true;
    mdSmart.B0_MSG_TEST_P01 = mdSmart.B0_MSG_TEST_P01 || {};

    $(document).on('pageinit', 'div[id="B0_MSG_TEST_P01"]', function (event) {
        console.log('#B0_MSG_TEST_P01 pageinit.');
        mdSmart.B0_MSG_TEST_P01.message = new mdSmart.msg0xB0();
        $(document).bind('recieveMessage', {}, function (event, message) {
            mdSmart.B0_MSG_TEST_P01.showStatus("", message);
        });
    });

    $(document).on('pageshow', 'div[id="B0_MSG_TEST_P01"]', function (event) {
        console.log('#B0_MSG_TEST_P01 pageshow.');
        mdSmart.B0_MSG_TEST_P01.prepareAndShow();
		//工作状态按钮绑定事件
        $("#B0_MSG_TEST_0_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateStandby);
        $("#B0_MSG_TEST_0_BTN02").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateWork);
		$("#B0_MSG_TEST_0_BTN03").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePause);
        $("#B0_MSG_TEST_0_BTN04").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateOver);
		$("#B0_MSG_TEST_0_BTN05").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateLock);
		$("#B0_MSG_TEST_0_BTN06").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateReserve);
        $("#B0_MSG_TEST_0_BTN07").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateEnergySaving);
		$("#B0_MSG_TEST_0_BTN08").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePreheat);
		//工作模式按钮绑定事件
		$("#B0_MSG_TEST_1_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeMicrowave);
		$("#B0_MSG_TEST_1_BTN02").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeBarbecue);
		$("#B0_MSG_TEST_1_BTN03").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeAutomaticMenu);
		$("#B0_MSG_TEST_1_BTN04").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeThaw);
		$("#B0_MSG_TEST_1_BTN05").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHotAirConvection);
		$("#B0_MSG_TEST_1_BTN06").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHighTemperatureSteam);
		$("#B0_MSG_TEST_1_BTN07").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeInductionMenu);
		//工作时间：分
		$("#B0_MSG_TEST_2_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeMinute);
		//工作时间：秒
		$("#B0_MSG_TEST_3_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeSeconds);
		//工作模式参数1
		$("#B0_MSG_TEST_4_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters1);
		//工作模式参数2
		$("#B0_MSG_TEST_5_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters2);
		//总烹饪段数
		$("#B0_MSG_TEST_6_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionTotalCookingNumber);
		//当前烹饪段
		$("#B0_MSG_TEST_6_BTN02").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionCurrentCookingNumber);
		//预约时间：小时
		$("#B0_MSG_TEST_7_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeHour);
		//预约时间：分钟
		$("#B0_MSG_TEST_8_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeMinute);
		//下一段烹调操作-无须干预
		$("#B0_MSG_TEST_9_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueWithoutIntervention);
		//下一段烹调操作-无操作自动开始
		$("#B0_MSG_TEST_9_BTN02").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueAutoStart);
		//下一段烹调操作-需按键开始
		$("#B0_MSG_TEST_9_BTN03").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctionKeyStart);
		//检验和
		$("#B0_MSG_TEST_10_BTN01").bind('click', {}, mdSmart.B0_MSG_TEST_P01.setFunctioncheckSum);
		//查询按钮
		$("#B0_MSG_TEST_request").bind('click', {}, mdSmart.B0_MSG_TEST_P01.cmdRequestStatus);
    });

    $(document).on('pagehide', 'div[id="B0_MSG_TEST_P01"]', function (event) {
        console.log('#B0_MSG_TEST_P01 pagehide.');
        //取消绑定事件
    });

    mdSmart.B0_MSG_TEST_P01.prepareAndShow = function () {
        console.log("mdSmart.B0_MSG_TEST_P01.prepareAndShow");
        bridge.getCardTitle(function (message) {
            $(".card-tilte span").html(message);
        });
        // For Debug
        if (bDebug == true) {
            var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();           
            var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.recieveMessage(bridgeMessage);
            var title = JSON.stringify({
                messageBody: "微波炉协议"
            });
            bridge.setCardTitle(title);
        }
    };


    // 控制-请求
    mdSmart.B0_MSG_TEST_P01.cmdControl = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.cmdControl");
        var workingStatusMessage = mdSmart.B0_MSG_TEST_P01.message.getResponseBack();
        if (bDebug == true) {
            if (workingStatusMessage == undefined) {
                var cmdRequest = mdSmart.B0_MSG_TEST_P01.message.cmdControl();
                var cmdId = bridge.startCmdProcess(cmdRequest, function (messageBack) {
                    mdSmart.B0_MSG_TEST_P01.showStatus(cmdRequest, messageBack);
                });
                var messageBody = mdSmart.message.createMessageBody(11);
                var message = mdSmart.message.createMessage(0xB0, 0x02, messageBody);
                var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
                bridge.callbackFunction(cmdId, bridgeMessage);
            } else {
                mdSmart.B0_MSG_TEST_P01.showStatus("-------------------", workingStatusMessage);
            }
        }
        else {
            var cmdRequest = mdSmart.B0_MSG_TEST_P01.message.cmdControl();
            var cmdId = bridge.startCmdProcess(cmdRequest, function (messageBack) {
                mdSmart.B0_MSG_TEST_P01.showStatus(cmdRequest, messageBack);
            });
        }
    };
   
    // 工作状态--待机
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateStandby = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateStandby");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateStandby();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--工作
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateWork = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateWork");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateWork();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--结束
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateOver = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateOver");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateOver();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--暂停
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePause = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePause");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStatePause();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--童锁
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateLock = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateLock");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateLock();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--预约
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateReserve = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateReserve");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateReserve();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--省电
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateEnergySaving = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStateEnergySaving");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStateEnergySaving();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作状态--预热
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePreheat = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkStatePreheat");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkStatePreheat();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--微波
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeMicrowave = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeMicrowave");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeMicrowave();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--烧烤
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeBarbecue = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeBarbecue");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeBarbecue();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--自动菜单
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeAutomaticMenu = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeAutomaticMenu");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeAutomaticMenu();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--解冻
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeThaw = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeThaw");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeThaw();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--热风对流
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHotAirConvection = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHotAirConvection");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeHotAirConvection();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--高温蒸汽
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHighTemperatureSteam = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeHighTemperatureSteam");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeHighTemperatureSteam();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式--感应菜单
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeInductionMenu = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkModeInductionMenu");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkModeInductionMenu();
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作时间：分
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeMinute = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeMinute");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkTimeMinute(0x01);
		mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkTimeSeconds(0x01);
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作时间：秒
    mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeSeconds = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionWorkTimeSeconds");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkTimeMinute(0x02);
        mdSmart.B0_MSG_TEST_P01.message.setFunctionWorkTimeSeconds(0x02);
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式参数1
    mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters1 = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters1");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionSetWorkParameters1(0x01);
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 工作模式参数2
    mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters2 = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionSetWorkParameters2");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionSetWorkParameters2(0x03);
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 总烹饪段数
    mdSmart.B0_MSG_TEST_P01.setFunctionTotalCookingNumber = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionTotalCookingNumber");
        mdSmart.B0_MSG_TEST_P01.message.setFunctionTotalCookingNumber(0x03);
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 当前烹饪段
    mdSmart.B0_MSG_TEST_P01.setFunctionCurrentCookingNumber = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionCurrentCookingNumber");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionCurrentCookingNumber(0x01);
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 预约时间：小时
    mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeHour = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeHour");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionBookedTimeHour(0x02);
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 预约时间：分钟
    mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeMinute = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionBookedTimeMinute");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionBookedTimeMinute(0x03);
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 下一段烹调操作-无须干预
    mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueWithoutIntervention = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueWithoutIntervention");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionBarbecueWithoutIntervention();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 下一段烹调操作-无操作自动开始
    mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueAutoStart = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionBarbecueAutoStart");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionBarbecueAutoStart();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 下一段烹调操作-需按键开始
    mdSmart.B0_MSG_TEST_P01.setFunctionKeyStart = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctionKeyStart");
		mdSmart.B0_MSG_TEST_P01.message.setFunctionKeyStart();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
	// 检验和
    mdSmart.B0_MSG_TEST_P01.setFunctioncheckSum = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.setFunctioncheckSum");
		mdSmart.B0_MSG_TEST_P01.message.setFunctioncheckSum();
        var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdControlStatus();
        var cmdId = bridge.startCmdProcess(cmdBytes, function (messageBack) {
            mdSmart.B0_MSG_TEST_P01.showStatus(cmdBytes, messageBack);
        });
        mdSmart.B0_MSG_TEST_P01.afterControlProcess(cmdId, cmdBytes);
    };
    // 查询按钮
    mdSmart.B0_MSG_TEST_P01.cmdRequestStatus = function () {
        console.log("function:mdSmart.B0_MSG_TEST_P01.cmdRequestStatus");
		var cmdBytes = mdSmart.B0_MSG_TEST_P01.message.cmdRequestStatus();           
		var messageBody = cmdBytes.slice(10, cmdBytes.length - 1);
		var message = mdSmart.message.createMessage(0xB0, 0x03, messageBody);
		var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
		bridge.recieveMessage(bridgeMessage);
    };

    mdSmart.B0_MSG_TEST_P01.afterControlProcess = function (cmdId, cmdBytes) {
        console.log("function:mdSmart.B0_MSG_TEST_P01.afterControlProcess");
        // For Debug
        if (bDebug == true) {
            var cmdMessageType = cmdBytes[9], cmdMessageBody = cmdBytes.slice(10, cmdBytes.length - 1);
            var statusMessage = mdSmart.B0_MSG_TEST_P01.message.getResponseBack();
            var messageType = 0x82;
			messageBody = mdSmart.message.createMessageBody(11);
            if (statusMessage != undefined) {
                messageBody = statusMessage.slice(10, statusMessage.length - 1);
                messageType = statusMessage[9];
            }
			if(cmdMessageType == 0x02){
				//Byte10	工作状态
				mdSmart.message.setByte(messageBody,0,mdSmart.message.getByte(cmdMessageBody,0));
				//Byte11	工作模式
				mdSmart.message.setByte(messageBody,1,mdSmart.message.getByte(cmdMessageBody,1));
				//Byte12	剩余时间分
				mdSmart.message.setByte(messageBody,2,mdSmart.message.getByte(cmdMessageBody,2));
				//Byte13	剩余时间秒
				mdSmart.message.setByte(messageBody,3,mdSmart.message.getByte(cmdMessageBody,3));
				//Byte14	实际温度
				mdSmart.message.setByte(messageBody,4,mdSmart.message.getByte(cmdMessageBody,4));
				//Byte15	故障代码
				mdSmart.message.setByte(messageBody,5,0x00);
				//Byte16	提醒代码
				mdSmart.message.setByte(messageBody,6,0x01);
				//Byte17	维护保养
				mdSmart.message.setByte(messageBody,7,0x02);
				//Byte18	耗电量
				mdSmart.message.setByte(messageBody,8,0x03);
				//Byte19	使用时长
				mdSmart.message.setByte(messageBody,9,0x04);
				//Byte20	当前烹调段数
				mdSmart.message.setByte(messageBody,10,mdSmart.message.getByte(cmdMessageBody,6));
				//Byte21	效验和
				mdSmart.message.setByte(messageBody,11,0xff);
				
			}
            var message = mdSmart.message.createMessage(0xB0, messageType, messageBody);
            var bridgeMessage = mdSmart.message.converMessageToBridgePStr(message);
            bridge.callbackFunction(cmdId, bridgeMessage);
        }
    };
    mdSmart.B0_MSG_TEST_P01.showStatus = function (messageBackRequest, messageBackBack) {
        $("#sendMsgDiv").html("<hr>send:" + mdSmart.message.convertTo16Str(messageBackRequest));
        $("#receiveMsgDiv").html("<hr>receive:" + mdSmart.message.convertTo16Str(messageBackBack));
        var jsonStatus = mdSmart.B0_MSG_TEST_P01.message.parseMessageForView(messageBackBack);
        //var strStatus = "isRequestBack:" + jsonStatus.isRequestBack + "<br>";
        var strStatus = "messageType:" + jsonStatus.messageType + "<br>";
        //strStatus = strStatus + "messageBodyCommand:" + jsonStatus.messageBodyCommand + "<br>";
        strStatus = strStatus + mdSmart.B0_MSG_TEST_P01.showJSON(jsonStatus.status)
        $("#statusDiv").html("<hr>" + strStatus);
        //$("#statusDiv").html(JSON.stringify(jsonStatus));
    }
    mdSmart.B0_MSG_TEST_P01.showJSON = function (pJson) {
        var strStatus = "";
        for (var o in pJson) {
            var temp = pJson[o];
            if (temp.name != undefined) {
                if (temp.value != undefined && temp.value != 0) {
                    strStatus = strStatus + "<BR>" + temp.name + ":"
                    if (temp.view != undefined) {
                        strStatus = strStatus + temp.view[temp.value];
                    }
                    else {
                        strStatus = strStatus + temp.value;
                    }
                }
                else if (temp.detail != undefined) {
                    strStatus = strStatus + mdSmart.B0_MSG_TEST_P01.showJSON(temp.detail);
                }
            }
        }
        return strStatus;
    }
})(mdSmart);
