/**
 * @fileoverview iOS用bridge
 */
var mdSmartios = mdSmartios || {};
(function(mdSmartios) {
    if (mdSmartios.bridge) {
        console.log("mdSmartios.bridge is already defined.");
        return;
    }
    mdSmartios.bridge = mdSmartios.bridge || {};

    /**
     * 返回前页(JS->WebView）
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.goBack = function() {
        console.log("function:mdSmartios.bridge.goBack");
        return mdSmartios.bridge.po._execObjcMethod('goBack');
    };

    /**
     * 显示家电信息页(JS->WebView）
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.goInfoPage = function() {
        console.log("function:mdSmartios.bridge.goInfoPage");
        return mdSmartios.bridge.po._execObjcMethod('goInfoPage');
    };

    /**
     * 显示控制面板页(JS->WebView）
     * @param {json} pageParamers 控制面板页的启动参数,例如：{key1:value1,key2:value2}
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.showControlPanelPage = function(pageParamers) {
        console.log("function:mdSmartios.bridge.showControlPanelPage");
        var p = JSON.stringify({
            pageParameters : pageParamers
        });
        return mdSmartios.bridge.po._execObjcMethod('showControlPanelPage', p);
    };

    /**
     * 取得显示控制面板页的参数(JS->WebView）
     * @return {json}
     */
    mdSmartios.bridge.getPageParameters = function() {
        console.log('function:mdSmartios.bridge.getPageParameters');
        var param = {};
        var p = JSON.stringify(param);
        var pageParameters = mdSmartios.bridge.po._execObjcMethod('getPageParameters', p);
        var jsonResult = JSON.parse(pageParameters);
        return jsonResult.pageParameters;
    };

    /**
     * 显示控制面板页(JS->WebView）
     * @param {String} controlPanelName 控制面板页的页面文件名，例如：controlPanel02
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.showNamedControlPanelPage = function(controlPanelName) {
        console.log("function:mdSmartios.bridge.showNamedControlPanelPage");
        var p = JSON.stringify({
            controlPanelName : controlPanelName + '.html'
        });
        return mdSmartios.bridge.po._execObjcMethod('showControlPanelPage', p);
    };

    /**
     * 向iOS写log(JS->WebView）
     * @param {String} logContent log内容
     */
    mdSmartios.bridge.logToIOS = function(logContent) {
        console.log("function:mdSmartios.bridge.logToIOS");
//        var s = '';
//        for (var i = 0; i < logContent.length; i++) {
//            s += logContent[i].toString(16) + ',';
//        }
        return mdSmartios.bridge.po._execObjcMethod('logToIOS', logContent);
    };
	
	/*
	* 取得网络类型
	* return LAN或WAN
	*/
	mdSmartios.bridge.getNetType = function() {
        console.log("function:mdSmartios.bridge.getNetType");
        return mdSmartios.bridge.po._execObjcMethod('getCommunicationMethod');
    };
	
	/*
	* 取得卡片页在同类卡片中的顺序
	* return 0:第1、3、5...，1:第2、4、6...
	*/
	mdSmartios.bridge.getCardOrder = function() {
        console.log("function:mdSmartios.bridge.getCardOrder");
        return mdSmartios.bridge.po._execObjcMethod('getCardOrder');
    };
    
    /*
    * 取得设备SN
    * return 设备SN
    */
    mdSmartios.bridge.getCurrentDevSN = function() {
        console.log("function:mdSmartios.bridge.getCurrentDevSN");
        return mdSmartios.bridge.po._execObjcMethod('getCurrentDevSN');
    };

    /**
     * 取家电协议版本(JS->WebView）
     * @return {Number} 家电协议版本
     */
    mdSmartios.bridge.getApplianceProtocolVersion = function() {
        console.log("function:mdSmartios.bridge.getApplianceProtocolVersion");
        return mdSmartios.bridge.po._execObjcMethod('getApplianceProtocolVersion');
    };

    /**
     * 显示家电信息入口页(JS->WebView）
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.showApplianceInfoEntryPage = function() {
        console.log("function:mdSmartios.bridge.showApplianceInfoEntryPage");
        return mdSmartios.bridge.po._execObjcMethod('showApplianceInfoEntryPage');
    };

    /**
     * 显示家电信息页(JS->WebView）
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.showApplianceInfoPage = function() {
        console.log("function:mdSmartios.bridge.showApplianceInfoPage");
        return mdSmartios.bridge.po._execObjcMethod('showApplianceInfoPage');
    };

    /**
     * 显示消息中心页(JS->WebView）
     * @return {Number} 処理結果
     *                    0 : 成功
     *                   -1 : 失败(无插件)
     *                   -2 : 失败(无文件)
     */
    mdSmartios.bridge.showInfoCenterPage = function() {
        console.log("function:mdSmartios.bridge.showInfoCenterPage");
        return mdSmartios.bridge.po._execObjcMethod('showInfoCenterPage');
    };

    /**
     * 开始异步处理的命令
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
    mdSmartios.bridge.startCmdProcess = function(messageBody, callback, callbackFail) {
        console.log('function:mdSmartios.bridge.startCmdProcess: messageBody=' + messageBody + ', callback=' + callback + ', callbackFail=' + callbackFail);
        var param = {};
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
 
        var commandId = mdSmartios.bridge.startCmdProcessGo(param);
 
        if ( typeof callback == "function") {
            mdSmartios.bridge.callbackFunctions[commandId] = callback;
        }
 
        var isQuery=true;
        switch(messageBody[2]){
            case 0xea:
            case 0xeb:
            case 0xec:
            case 0xed:
            case 0xef:
                if((messageBody[18]<<8|messageBody[17])==50002){
                    isQuery=true;
                }else{
                    isQuery=false;
                }
                break;
            default:
                if(messageBody[9]==3){
                    isQuery=true;
                }else{
                    isQuery=false;
                }
        }
 
        if(!isQuery){
            if(typeof callbackFail != "function"){
                callbackFail=function(){};
            }
        }
 
        if ( typeof callbackFail == "function") {
            mdSmartios.bridge.callbackFailFunctions[commandId] = callbackFail;
        }

 
        return commandId;
    };

    /**
     * 开始异步处理的命令 可自定义Loading是否显示
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @param {bool} isLoading 是否显示loading阻塞界面
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
    mdSmartios.bridge.startCmdProcessCustomLoading = function(messageBody,isLoading, callback, callbackFail) {
        console.log('function:mdSmartios.bridge.startCmdProcess: messageBody=' + messageBody + ', callback=' + callback + ', callbackFail=' + callbackFail);
        var param = {};
        if (messageBody != undefined) {
            param.messageBody = messageBody;
 
        }
 
        if(isLoading != undefined){
            param.isLoading = isLoading;
        }
 
        var commandId = mdSmartios.bridge.startCmdProcessGo(param);
 
        if ( typeof callback == "function") {
            mdSmartios.bridge.callbackFunctions[commandId] = callback;
        }
 

        if(typeof callbackFail != "function"){
            callbackFail=function(){};
        }
 
        if ( typeof callbackFail == "function") {
            mdSmartios.bridge.callbackFailFunctions[commandId] = callbackFail;
        }

        return commandId;
    };
 
    /**
     * 开始异步处理的命令 真实发送接口
     * @param {intArray} param 发送的数据
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 
    mdSmartios.bridge.startCmdProcessGo = function(param) {
        var p = JSON.stringify(param);
        var commandId = mdSmartios.bridge.po._execObjcMethod('startCmdProcess', p);
        return commandId;

    };
 
 
    /**
     * 针对管家插件 开始异步处理的命令
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} param 发送的数据
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 
    mdSmartios.bridge.startCmdProcessExt = function(messageBody, callback, callbackFail) {
        console.log('function:mdSmartios.bridge.startCmdProcessExt: messageBody=' + messageBody + ', callback=' + callback + ', callbackFail=' + callbackFail);
        var param = {};
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        var p = JSON.stringify(param);
        var commandId = mdSmartios.bridge.po._execObjcMethod('startCmdProcessExt', p);
        if ( typeof callback == "function") {
            mdSmartios.bridge.callbackFunctions[commandId] = callback;
        }
 
        if(typeof callbackFail != "function"){
            callbackFail=function(){};
        }
        mdSmartios.bridge.callbackFailFunctions[commandId] = callbackFail;
        return commandId;
    };
 

 
    /**
     * 取消命令执行
     * @param {Number} commandId 命令ID
     * @return void
     * @note 不是处理中的时候,忽略
     */
    mdSmartios.bridge.stopCmdProcess = function(commandId) {
        console.log('function:mdSmartios.bridge.stopCmdProcess: commandId=' + commandId);
        var p = JSON.stringify({
            commandId : commandId
        });
        mdSmartios.bridge.po._execObjcMethod('stopCmdProcess', p);
    };

    /**
     * 取得命令执行状态
     * @param {Number} commandId 命令ID
     * @return {JSONObject} 命令执行状态
     *         {Number} .status 命令执行状态
     *                     0 : 未开始
     *                     1 : 进行中
     *                     2 : 结束
     *                    -1 : 异常
     *                    -2 : 取消
     *         {String} .errMessage 异常信息
     */
    mdSmartios.bridge.getCmdProcessInfo = function(commandId) {
        console.log('function:mdSmartios.bridge.getCmdProcessInfo: commandId=' + commandId);
        var p = JSON.stringify({
            commandId : commandId
        });
        return mdSmartios.bridge.po._execObjcMethod('getCmdProcessInfo', p);
    };

    /**
     * 取得卡片头部Tilte信息
     * @param {String} callback 处理成功后的回调函数
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
    mdSmartios.bridge.getCardTitle = function(callback) {
        console.log('function:mdSmartios.bridge.getCardTitle: callback=' + callback);
        var param = {};
        var p = JSON.stringify(param);
        if ( typeof callback == "function") {
            mdSmartios.bridge.setCardTitleCBF = callback;
        }
        var commandId = mdSmartios.bridge.po._execObjcMethod('getCardTitle', p);
        return commandId;
    };
 
 
    //配置文件
    mdSmartios.bridge.getConfigInfo = function(param,callback) {
        console.log('function:mdSmartios.bridge.getConfigInfo: callback=' + callback);
        //var param = {"fileName":"0xDB"};
        var p = JSON.stringify(param);
        if ( typeof callback == "function") {
            mdSmartios.bridge.setConfigInfoCBF = callback;
        }
        var commandId = mdSmartios.bridge.po._execObjcMethod('getConfigInfo', p);
        return commandId;
 
    };
 
 
    mdSmartios.bridge.setConfigInfoCBF = undefined;
    mdSmartios.bridge.setConfigInfo = function(message) {
    // var jsonResult = JSON.parse(message);
        if ( typeof mdSmartios.bridge.setConfigInfoCBF == "function") {
            //mdSmartios.bridge.setConfigInfoCBF(jsonResult.messageBody);
            mdSmartios.bridge.setConfigInfoCBF(message);
        }
    };
 
    //配置文件排序
    mdSmartios.bridge.getSort = function(callback) {
        console.log('function:mdSmartios.bridge.getSort: callback=' + callback);
        var param = {
            "isWritestr":0,
            "fileName":"cycleArray"
        };
        var p = JSON.stringify(param);
        if ( typeof callback == "function") {
            mdSmartios.bridge.setSortCBF = callback;
        }
        var commandId = mdSmartios.bridge.po._execObjcMethod('getSort', p);
        return commandId;
    };
 
    mdSmartios.bridge.setSortCBF = undefined;
    mdSmartios.bridge.setSort = function(message) {
        if ( typeof mdSmartios.bridge.setSortCBF == "function") {
            mdSmartios.bridge.setSortCBF(message);
        }
    };


    /**
     * 取得语言Code
     * @return {String} 语言Code
     *                    zh : 中国语
     *                    en : 英语
     */
    mdSmartios.bridge.getLangCode = function() {
        console.log('function:mdSmartios.bridge.getLangCode');
        var param = {};
        var p = JSON.stringify(param);
        var langCode = mdSmartios.bridge.po._execObjcMethod('getLangCode', p);

        if (langCode == undefined || langCode == 0 || langCode.length == 0) {
            langCode = "zh";
        }
        return langCode;
    };
 
    /**
     * 取得当前家电id
     * @return {String}
     */
    mdSmartios.bridge.getCurrentApplianceID = function() {
        var currentApplicanceID = mdSmartios.bridge.po._execObjcMethod('getCurrentApplianceID');
        return currentApplicanceID;
    };

 
    /**
     * Clear WebView Cache
     * @return void
     */
    mdSmartios.bridge.clearWebViewCache = function() {
        console.log('function:mdSmartios.bridge.clearWebViewCache');
        mdSmartios.bridge.po._execObjcMethod('clearWebViewCache');
    };
    mdSmartios.bridge.callbackFunctions = {};
    mdSmartios.bridge.callbackFailFunctions = {};
    mdSmartios.bridge.setCardTitleCBF = undefined;
    //卡片的标题(IOS调用：回复getCardTitle)
    mdSmartios.bridge.setCardTitle = function(message) {
        var jsonResult = JSON.parse(message);
        if ( typeof mdSmartios.bridge.setCardTitleCBF == "function") {
            mdSmartios.bridge.setCardTitleCBF(jsonResult.messageBody);
        }
		$('#loadingPopup>span').html(jsonResult.messageBody);
    };
    //设备主动上报的消息(IOS调用：主动发起)
    mdSmartios.bridge.recieveMessage = function(message) {
        var jsonResult = JSON.parse(message);
        $.event.trigger("recieveMessage", [jsonResult.messageBody]);
    };
	
	//设备返回的消息(IOS调用：主动发起)
    mdSmartios.bridge.updateCard = function(message) {
        var jsonResult = JSON.parse(message);
        $.event.trigger("updateCard", [jsonResult.messageBody]);
    };
 
    //更新界面时机(针对管家插件 单品跳转后返回时机)
    mdSmartios.bridge.updatePlug = function() {
        $.event.trigger("updatePlug");
    };
	
    //直接返回值(IOS赋值：回复JS所有类型请求（startCmdProcess：命令id，getLangCode：语言code）)
    mdSmartios.bridge.retObjcValue = 0;
    /*
     *指定命令的回复电文(IOS调用：回复startCmdProcess)
     *@param (int) retObjcValue 命令id
     *       (String) result 回复
     *                result.messageBody 回复电文
     *                result.errCode 错误码
     *                             1 超时
     *                result.errMessage 错误信息
     */
    mdSmartios.bridge.callbackFunction = function(retObjcValue, result) {
        var jsonResult = JSON.parse(result);
        var cbf = mdSmartios.bridge.callbackFunctions[retObjcValue];
        var cbff = mdSmartios.bridge.callbackFailFunctions[retObjcValue];
        if (jsonResult.errCode !== undefined && jsonResult.errMessage == 'TimeOut') {
			if(jsonResult.errCode==-1){
				if(location.href.indexOf('card_')!=-1){
					bridge.logToIOS('Jump to cardDisconnect.html.');
					location.href='cardDisconnect.html';
				}
			}else{
				if (typeof cbff == "function") {
					cbff(-1);
                var functionParamers = {
                    title : "提示",
                    message : "网络繁忙，请重试",
                    btnText : "确定"
                };

                mdSmartios.bridge.showAlert(functionParamers);
            /*
					if(!document.getElementById("timeoutPopup")){
						var timeoutDiv = document.createElement("DIV");
						timeoutDiv.setAttribute('data-role', 'popup');
						timeoutDiv.id = 'timeoutPopup';
						var timeoutP = document.createElement("P");
						timeoutDiv.appendChild(timeoutP);
						document.documentElement.appendChild(timeoutDiv);
						$('#timeoutPopup').popup({
							afterclose: function( event, ui ) {
								$('body').unbind('touchstart');
							}
						});
					}
					if (mdSmartios.bridge.getLangCode() == 'en') {
						$('#timeoutPopup>p').html('Network timeout, please retry.');
					} else {
						$('#timeoutPopup>p').html('网络繁忙，请重试');
					}
					$('#timeoutPopup').popup('open');
					$('body').bind('touchstart',function(e){
						e.preventDefault();
					});
					mdSmartios.timeoutId=setTimeout(function(){
						$('#timeoutPopup').popup('close');
						clearTimeout(mdSmartios.timeoutId);
					},2000);
                */
				}
			}
		} else {
            if ( typeof cbf == "function") {
                cbf(jsonResult.messageBody);
            }
        }
        delete mdSmartios.bridge.callbackFunctions[retObjcValue];
        delete mdSmartios.bridge.callbackFailFunctions[retObjcValue];
    };
	
 

 

    var loadingDiv = document.createElement("DIV");
    loadingDiv.id = 'loadingPopup';
    var loadingSpan = document.createElement("SPAN");
    loadingDiv.appendChild(loadingSpan);
    var loadingP = document.createElement("P");
    loadingDiv.appendChild(loadingP);
    var rotateImg=document.createElement('IMG');
    rotateImg.src='../common/images/icon_loading.png';
    loadingDiv.appendChild(rotateImg);
    document.documentElement.appendChild(loadingDiv);
    $('#loadingPopup').hide();
 
 
	mdSmartios.bridge.openLoading = function() {
 
		if(location.href.indexOf('cardDisconnect.html')==-1){
			if (mdSmartios.bridge.getLangCode() == 'en') {
				$('#loadingPopup>p').html('Loading');
			} else {
				$('#loadingPopup>p').html('拼命为您连接中...');
			}
			$('#loadingPopup').show();
		}
    };

	mdSmartios.bridge.closeLoading = function() {
		$('#loadingPopup').hide();
    };
	
    mdSmartios.bridge.po = {
        _execObjcMethod : function(method, data) {
            try {
                var tmp = method;
                if (data != undefined && data != '') {
                    tmp = tmp + '?' + data;
                }
                var iframe = document.createElement("IFRAME");
                iframe.setAttribute("src", "iosbridge://" + tmp);
                document.documentElement.appendChild(iframe);
                iframe.parentNode.removeChild(iframe);
                iframe = null;
            } catch(e) {
                console.log(method + ' exception');
            }
            console.log('javaScript:mdSmartios.bridge.retObjcValue == ' + mdSmartios.bridge.retObjcValue);
            //alert(mdSmartios.bridge.retObjcValue);
            return mdSmartios.bridge.retObjcValue;
        }
    };

    /**
     * 输出日志
     */
    mdSmartios.bridge.jsWindowOnError = function(obj, arg1, arg2, arg3) {
        var param = {
            obj : obj,
            arg1 : arg1,
            arg2 : arg2,
            arg3 : arg3
        };
        var p = JSON.stringify(param);
        console.log('mdSmartios.bridge.jsWindowOnError():' + p);
    };
    //IOS主动上报的消息-设备连接状态(IOS调用：主动发起)
    //pIsConnect 1:连接成功 0:断开连接
    mdSmartios.bridge.setApplianceConnnectStatus = function(pIsConnect) {
        mdSmartios.bridge.isApplianceConnected = parseInt(pIsConnect);
        if (0x01 == mdSmartios.bridge.isApplianceConnected) {
            for (var index in mdSmartios.bridge.applianceConnectedEvents) {
                var item = mdSmartios.bridge.applianceConnectedEvents[index];
                if ( typeof item == "object") {
                    item.fire();
                }
            }
        } else {
            for (var index in mdSmartios.bridge.applianceDisconnectedEvents) {
                var item = mdSmartios.bridge.applianceDisconnectedEvents[index];
                if ( typeof item == "object") {
                    item.fire();
                }
            }
        }
    };
 
 
 /* 管家DEMO-------------------------------------------------------------------------------------------START*/
	mdSmartios.bridge.callbackUserInfo = undefined;
	mdSmartios.bridge.callbackUserApplianceList = undefined;
	mdSmartios.bridge.callbackUserHomeInfo = undefined;
 //	mdSmartios.bridge.callbackRequestDataTransmit = undefined;
 mdSmartios.bridge.callbackRequestDataTransmit = {};
 mdSmartios.bridge.callbackFailRequestDataTransmit = {};
 
 mdSmartios.bridge.callbackGPSInfo = undefined;
 mdSmartios.bridge.callbackQrCode = undefined;
 mdSmartios.bridge.callbackJumpPlugin = undefined;
 
 //GPS信息获取 JS－>iOS
 mdSmartios.bridge.getGPSInfo = function(callback) {
 console.log('function:mdSmartios.bridge.getGPSInfo: callback=' + callback);
 var param = {};
 var p = JSON.stringify(param);
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackGPSInfo = callback;
 }
 var commandId = mdSmartios.bridge.po._execObjcMethod('getGPSInfo', p);
 return commandId;
 };
	
	//GPS信息能力(IOS调用：回复getGPSInfo)
 mdSmartios.bridge.setGPSInfo = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackGPSInfo == "function") {
 mdSmartios.bridge.callbackGPSInfo(jsonResult.messageBody);
 }
 };
 
 //扫码功能 JS－>iOS
 mdSmartios.bridge.qrCodeScan = function(callback) {
 console.log('function:mdSmartios.bridge.qrCodeScan: callback=' + callback);
 var param = {};
 var p = JSON.stringify(param);
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackQrCode = callback;
 }
 var commandId = mdSmartios.bridge.po._execObjcMethod('qrCodeScan', p);
 return commandId;
 };
	
	//扫码功能(IOS调用：回复qrCodeScan)
 mdSmartios.bridge.setQrCode = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackQrCode == "function") {
 mdSmartios.bridge.callbackQrCode(jsonResult.messageBody);
 }
 };
 
 //跳转功能 JS－>iOS
 mdSmartios.bridge.jumpOtherPlugin = function(cmdParamers,callback) {
 console.log('function:mdSmartios.bridge.jumpOtherPlugin');
 var param = {};
 if (cmdParamers != undefined) {
 param.cmdParamers = cmdParamers;
 }
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackJumpPlugin = callback;
 }
 
 var p = JSON.stringify(param);
 var commandId = mdSmartios.bridge.po._execObjcMethod('jumpOtherPlugin', p);
 return commandId;
 };
	
	//跳转功能(IOS调用：回复jumpOtherPlugin)
 mdSmartios.bridge.jumpOtherPluginCB = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackJumpPlugin == "function") {
 mdSmartios.bridge.callbackJumpPlugin(jsonResult.messageBody);
 }
 };
 
	/**
     * #define GetUserInfo @"getUserInfo" 获取用户信息能力
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 mdSmartios.bridge.getUserInfo = function(callback) {
 console.log('function:mdSmartios.bridge.getUserInfo: callback=' + callback);
 var param = {};
 var p = JSON.stringify(param);
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackUserInfo = callback;
 }
 var commandId = mdSmartios.bridge.po._execObjcMethod('getUserInfo', p);
 return commandId;
 };
	
	//用户信息能力(IOS调用：回复getUserInfo)
 mdSmartios.bridge.setUserInfo = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackUserInfo == "function") {
 mdSmartios.bridge.callbackUserInfo(jsonResult.messageBody);
 }
 };
	
	/**
     * #define GetUserApplianceList @"getUserApplianceList" 获取用户家电列表
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 mdSmartios.bridge.getUserApplianceList = function(callback) {
 console.log('function:mdSmartios.bridge.getUserApplianceList: callback=' + callback);
 var param = {};
 var p = JSON.stringify(param);
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackUserApplianceList = callback;
 }
 var commandId = mdSmartios.bridge.po._execObjcMethod('getUserApplianceList', p);
 return commandId;
 };
	
	//用户家电列表(IOS调用：回复getUserApplianceList)
 mdSmartios.bridge.setUserApplianceList = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackUserApplianceList == "function") {
 mdSmartios.bridge.callbackUserApplianceList(jsonResult.messageBody);
 }
 };
	
	/**
     * #define GetUserHomeInfo @"getUserHomeInfo"  获取用户家庭信息
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 mdSmartios.bridge.getUserHomeInfo = function(callback) {
 console.log('function:mdSmartios.bridge.getUserHomeInfo:callback=' + callback);
 var param = {};
 var p = JSON.stringify(param);
 if ( typeof callback == "function") {
 mdSmartios.bridge.callbackUserHomeInfo = callback;
 }
 var commandId = mdSmartios.bridge.po._execObjcMethod('getUserHomeInfo', p);
 return commandId;
 };
 
 //用户家庭信息(IOS调用：回复getUserHomeInfo)
 mdSmartios.bridge.setUserHomeInfo = function(message) {
 var jsonResult = JSON.parse(message);
 if ( typeof mdSmartios.bridge.callbackUserHomeInfo == "function") {
 mdSmartios.bridge.callbackUserHomeInfo(jsonResult.messageBody);
 }
 };
	
	//用户家庭信息(IOS调用：回复getUserHomeInfo)
 mdSmartios.bridge.setDataTransmit = function(retObjcValue, result) {
    var jsonResult = JSON.parse(result);
    var cbf = mdSmartios.bridge.callbackRequestDataTransmit[retObjcValue];
    var cbff = mdSmartios.bridge.callbackFailRequestDataTransmit[retObjcValue];
//    if (jsonResult.errCode !== undefined && jsonResult.errCode == 1) {
//        if ( typeof cbff == "function") {
//            cbff(-1);
//            if(!document.getElementById("timeoutPopup")){
//                var timeoutDiv = document.createElement("DIV");
//                timeoutDiv.setAttribute('data-role', 'popup');
//                timeoutDiv.id = 'timeoutPopup';
//                var timeoutP = document.createElement("P");
//                timeoutDiv.appendChild(timeoutP);
//                document.documentElement.appendChild(timeoutDiv);
//                    $('#timeoutPopup').popup({
//                                        afterclose: function( event, ui ) {
//                                                    $('body').unbind('touchstart');
//                                                    }
//                                        });
//            }
// 
//            if (mdSmartios.bridge.getLangCode() == 'en') {
//                    $('#timeoutPopup>p').html('Operation timeout, please retry.');
//            } else {
//                $('#timeoutPopup>p').html('操作超时，请重试');
//            }
//            $('#timeoutPopup').popup('open');
//            $('body').bind('touchstart',function(e){
//                e.preventDefault();
//            });
// 
//            mdSmartios.timeoutId=setTimeout(function(){
//                                 $('#timeoutPopup').popup('close');
//                                 clearTimeout(mdSmartios.timeoutId);
//                                 },2000);
//        }
//    } else
    {
        if ( typeof cbf == "function") {
            cbf(jsonResult.messageBody);
        }
    }
    delete mdSmartios.bridge.callbackRequestDataTransmit[retObjcValue];
    delete mdSmartios.bridge.callbackFailRequestDataTransmit[retObjcValue];
 };
	
	/**
     * #define RequestDataTransmit @"requestDataTransmit" 请求通用数据接口能力
     * @param {String} callback 处理成功后的回调函数
     * @param {String} callbackFail 后续处理异常时的回调函数
     * @param {intArray} messageBody 命令的整数数组
     * @return {Number} 命令ID
     *                    0以上 : 处理成功
     *                   -1     : 处理失败
     */
 mdSmartios.bridge.requestDataTransmit = function(cmdParamers, callback, callbackFail) {
    var param = {};
    if (cmdParamers != undefined) {
        param.cmdParamers = cmdParamers;
    }
    var p = JSON.stringify(param);
    var commandId = mdSmartios.bridge.po._execObjcMethod('requestDataTransmit', p);
    if ( typeof callback == "function") {
        mdSmartios.bridge.callbackRequestDataTransmit[commandId] = callback;
    }
 
    callbackFail=function(){};
    // if ( typeof callbackFail == "function") {
    mdSmartios.bridge.callbackFailRequestDataTransmit[commandId] = callbackFail;
    // }
    return commandId;
 };
	
 
 
 //显示alert
 mdSmartios.bridge.showAlert = function(cmdParamers) {
    console.log('function:mdSmartios.bridge.showAlert');
    var param = {};
    if (cmdParamers != undefined) {
        param.cmdParamers = cmdParamers;
    }
 
    var p = JSON.stringify(param);
    var commandId = mdSmartios.bridge.po._execObjcMethod('showAlert', p);
    return commandId;
 };
 
 //loading 显示
 mdSmartios.bridge.showProgress = function() {
    console.log("function:mdSmartios.bridge.showProgress");
    return mdSmartios.bridge.po._execObjcMethod('showProgress');
 };
 
 //loading 取消
 mdSmartios.bridge.closeProgress = function() {
    console.log("function:mdSmartios.bridge.closeProgress");
    return mdSmartios.bridge.po._execObjcMethod('closeProgress');
 };
 

 
 
	/* 管家DEMO-------------------------------------------------------------------------------------------END*/
 
 
 
    //JS监听设备的连接状态
    //eventType   "connected"   :连接
    //            "disconnected":断开连接
    mdSmartios.bridge.isApplianceConnected = 0x01;
    mdSmartios.bridge.applianceConnectedEvents = [];
    mdSmartios.bridge.applianceDisconnectedEvents = [];
    mdSmartios.bridge.appliance = function() {
        function commonEvent() {
            this.handler
        };
        commonEvent.prototype = {
            addHandler : function(handler) {
                this.handler = handler;
            },
            fire : function() {
                this.handler();
            },
            removeHandler : function() {
                this.handler = null;
            }
        };
        //eventType-connected
        var _connectedEvent = new commonEvent();
        //eventType-disconnected
        var _disconnectedEvent = new commonEvent();
        return {
            bind : function(eventType, handler) {
                if (eventType == "connected") {
                    for (var i in mdSmartios.bridge.applianceConnectedEvents) {
                        if (mdSmartios.bridge.applianceConnectedEvents[i] == _connectedEvent) {
                            delete mdSmartios.bridge.applianceConnectedEvents[i];
                        }
                    }
                    _connectedEvent.addHandler(handler);
                    mdSmartios.bridge.applianceConnectedEvents.push(_connectedEvent);
                }
                if (eventType == "disconnected") {
                    for (var i in mdSmartios.bridge.applianceDisconnectedEvents) {
                        if (mdSmartios.bridge.applianceDisconnectedEvents[i] == _disconnectedEvent) {
                            delete mdSmartios.bridge.applianceDisconnectedEvents[i];
                        }
                    }
                    _disconnectedEvent.addHandler(handler);
                    mdSmartios.bridge.applianceDisconnectedEvents.push(_disconnectedEvent);
                }
            },
            unbind : function(eventType) {
                if (eventType == "connected" || eventType == undefined) {
                    for (var i in mdSmartios.bridge.applianceConnectedEvents) {
                        if (mdSmartios.bridge.applianceConnectedEvents[i] == _connectedEvent) {
                            delete mdSmartios.bridge.applianceConnectedEvents[i];
                        }
                    }
                }
                if (eventType == "disconnected" || eventType == undefined) {
                    for (var i in mdSmartios.bridge.applianceDisconnectedEvents) {
                        if (mdSmartios.bridge.applianceDisconnectedEvents[i] == _disconnectedEvent) {
                            delete mdSmartios.bridge.applianceDisconnectedEvents[i];
                        }
                    }
                }
            },
            request : function() {
                mdSmartios.bridge.setApplianceConnnectStatus(mdSmartios.bridge.isApplianceConnected);
            }
        };
    };
})(mdSmartios);

(function(window, undefined) {
    console.log('--iPhone bridge--');
    // iPhone log
    if (window.navigator.userAgent.indexOf('DEBUG_LOG') != -1) {
        console = new Object();
        console.log = function(log) {
            var iframe = document.createElement("IFRAME");
            iframe.setAttribute("src", "ios-log:#iOS#" + log);
            document.documentElement.appendChild(iframe);
            iframe.parentNode.removeChild(iframe);
            iframe = null;
        };
        console.warn = function(log) {
            console.log(log);
        };
        console.debug = function(log) {
            console.log(log);
        };
        console.error = function(log) {
            console.log(log);
        };
        console.info = function(log) {
            console.log(log);
        };
        console.trace = function(log) {
            console.log(log);
        };
    }
    bridge = mdSmartios.bridge;
})(window);
