
mui.init({
    swipeBack: false,
    pullRefresh: {
        container: '#pullrefresh',
        down: {
            contentdown : "下拉加载更多",
            contentover : "释放立即刷新",
            contentrefresh: '正在刷新...',
            callback: pullDownRefresh
        },
        up: {
            contentrefresh : "正在加载...",
            contentnomore:'没有更多数据了',
            callback: pullUpRefresh
        }
    }
});



