/**
 * Created on 15-4-19.
 */
var queryString = function (){
    var string = (location.search.length >0 ? location.search.substring(1) : "");
    var args = {};
    var items = string.length >0 ? string.split("&") :[];
    var item,key,value;
    for(var i =0;i < items.length; i++){
        item = items[i].split("=");
        key = decodeURIComponent(item[0]);
        value = decodeURIComponent(item[1]);
        if(key.length >0){
            args[key] = value;
        }
    }
    return args;
};
